<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$siswa = mysql_query("DELETE FROM tbl_siswa1 WHERE nis_lokal='$id'") or die(mysql_error());
	$ortu = mysql_query("DELETE FROM tbl_ortu WHERE no_induk ='$id'");
	$user = mysql_query("DELETE FROM tbl_user_login WHERE nip_nisn ='$id'");

	if($siswa && $ortu && $user){
		echo "<script>alert('Data Siswa Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_siswa.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_siswa.php')</script>";
	}
?>



