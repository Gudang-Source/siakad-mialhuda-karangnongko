<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$guru = mysql_query("DELETE FROM tbl_guru WHERE nomer_pegawai='$id'");
	$user = mysql_query("DELETE FROM tbl_user_login WHERE nip_nisn ='$id'");

	if($guru && $user ){
		echo "<script>alert('Data Guru Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_guru.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_guru.php')</script>";
	}
?>



