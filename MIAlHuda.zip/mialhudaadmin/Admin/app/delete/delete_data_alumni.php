<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$alumni = mysql_query("DELETE FROM tbl_alumni WHERE nis_lokal='$id'");

	if($alumni){
		echo "<script>alert('Data Alumni Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_alumni.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_alumni.php')</script>";
	}
?>



