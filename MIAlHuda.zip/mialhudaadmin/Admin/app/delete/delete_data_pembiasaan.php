<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$mapel = mysql_query("DELETE FROM tbl_pembiasaan WHERE id_pembiasaan='$id'");

	if($mapel){
		echo "<script>alert('Pembiasaan Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_pembiasaan.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_pembiasaan.php')</script>";
	}
?>



