<?php
	include('../../settings/config.php');

	$nip_nisn = $_GET['id'];
	$user = mysql_query("DELETE FROM tbl_user_login WHERE nip_nisn='$nip_nisn'");

	if($user){
		echo "<script>alert('Data Pengguna Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Pengguna/data_pengguna.php')</script>";;
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Pengguna/data_pengguna.php')</script>";
	}
?>



