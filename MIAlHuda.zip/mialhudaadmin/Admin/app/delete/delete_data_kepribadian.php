<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$kepribadian = mysql_query("DELETE FROM tbl_kepribadian WHERE id_kepribadian='$id'");

	if($kepribadian){
		echo "<script>alert('Kepribadian Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_kepribadian.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_kepribadian.php')</script>";
	}
?>



