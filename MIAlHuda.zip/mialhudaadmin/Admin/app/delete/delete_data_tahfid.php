<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$tahfid = mysql_query("DELETE FROM tbl_tahfid_doa WHERE id_tahfid_doa='$id'");

	if($tahfid){
		echo "<script>alert('Tahfid / Doa Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_tahfid_doa.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_tahfid_doa.php')</script>";
	}
?>



