<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$pengumuman = mysql_query("DELETE FROM tbl_artikel WHERE id_artikel='$id'") or die(mysql_error());

	if($pengumuman){
		echo "<script>alert('Pengumuman Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Artikel/pengumuman.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Artikel/pengumuman.php')</script>";
	}
?>



