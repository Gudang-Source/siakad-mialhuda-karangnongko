<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$berita = mysql_query("DELETE FROM tbl_artikel WHERE id_artikel='$id'") or die(mysql_error());

	if($berita){
		echo "<script>alert('Berita Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Artikel/berita.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Artikel/berita.php')</script>";
	}
?>



