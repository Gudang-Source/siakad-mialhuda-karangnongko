<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$unggulan = mysql_query("DELETE FROM tbl_program_unggulan WHERE id_program_unggulan='$id'");

	if($unggulan){
		echo "<script>alert('Program Unggulan Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_program_unggulan.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_program_unggulan.php')</script>";
	}
?>



