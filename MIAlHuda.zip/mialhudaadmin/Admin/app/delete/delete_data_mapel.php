<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$mapel = mysql_query("DELETE FROM tbl_mapel WHERE id_mapel='$id'") or die(mysql_error());

	if($mapel){
		echo "<script>alert('Data Mapel Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_mapel.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_mapel.php')</script>";
	}
?>



