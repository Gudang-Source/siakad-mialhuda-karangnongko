<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$kelas = mysql_query("DELETE FROM tbl_kelas WHERE id_kelas='$id'") or die(mysql_error());

	if($kelas){
		echo "<script>alert('Data Kelas Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_kelas.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_kelas.php')</script>";
	}
?>



