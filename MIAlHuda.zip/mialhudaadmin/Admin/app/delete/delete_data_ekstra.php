<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$mapel = mysql_query("DELETE FROM tbl_ekskul WHERE id_ekstra='$id'");

	if($mapel){
		echo "<script>alert('Ekstra Kulikuler Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_ekstra_kulikuler.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_ekstra_kulikuler.php')</script>";
	}
?>



