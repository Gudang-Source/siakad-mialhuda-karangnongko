<?php
	include('../../settings/config.php');

	$id_thn = $_GET['id'];
	$tahun = mysql_query("DELETE FROM tbl_thn_ajaran WHERE id='$id_thn'");

	if($tahun){
		echo "<script>alert('Data Tahun Ajaran Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/tahun_ajaran.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/tahun_ajaran.php')</script>";
	}
?>



