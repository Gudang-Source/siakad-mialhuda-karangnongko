<?php
	include('../../settings/config.php');

	$id = $_GET['id'];
	$Jadwal = mysql_query("DELETE FROM tbl_jadwal_pelajaran WHERE id_jdwl='$id'") or die(mysql_error());

	if($Jadwal){
		echo "<script>alert('Jadwal Pelajaran Berhasil diHapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_jadwal_pelajaran.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Dihapus');</script>";
		echo "<script>location.replace('../../pages/Master/data_jadwal_pelajaran.php')</script>";
	}
?>



