<?php
 
# MEMBUAT KONEKSI KE DATABASE
include('../../settings/config.php');

$pil_kls = $_POST['kelas'];
 
# MENGAMBIL DATA DARI DATABASE MYSQL
if ($pil_kls == 'semua') {
      $siswa = mysql_query("SELECT * FROM tbl_siswa1
                            INNER JOIN tbl_ortu ON tbl_ortu.no_induk = tbl_siswa1.nis_lokal
                            ORDER BY nis_lokal ASC");
}
else{
      $siswa = mysql_query("SELECT * FROM tbl_siswa1 
                            INNER JOIN tbl_ortu ON tbl_ortu.no_induk = tbl_siswa1.nis_lokal
                            WHERE kelas = '$pil_kls' ORDER BY nis_lokal ASC ");
}
 
 
/** Include PHPExcel */
require_once dirname(__FILE__) . '/PHPExcel/Classes/PHPExcel.php';
 
$objPHPExcel = new PHPExcel();
 
// Set document properties
$objPHPExcel->getProperties()->setCreator("Mastrayasa")
							->setLastModifiedBy("Mastrayasa")
							->setTitle("Data Siswa")
							->setSubject("Siswa")
							->setDescription("Data Siswa MI Al-Huda Karangnongko")
							->setKeywords("sibangStudio PHPExcel php")
							->setCategory("Umum");
// mulai dari baris ke 2
$row = 4;
 
// Tulis judul tabel
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, 'No')
            ->setCellValue('B'.$row, 'NIS Lokal')
            ->setCellValue('C'.$row, 'NSM MI')
            ->setCellValue('D'.$row, 'Madrasah')
            ->setCellValue('E'.$row, 'Alamat')
            ->setCellValue('F'.$row, 'Kecamatan')
            ->setCellValue('G'.$row, 'Nama Siswa')
            ->setCellValue('H'.$row, 'Jenis Kel')
            ->setCellValue('I'.$row, 'Tempat Lahir')
            ->setCellValue('J'.$row, 'Tanggal Lahir')
            ->setCellValue('K'.$row, 'NIS Nasional')
            ->setCellValue('L'.$row, 'Kelas')
            ->setCellValue('M'.$row, 'Alamat Siswa')
            ->setCellValue('N'.$row, 'Kecamatan')
            ->setCellValue('O'.$row, 'Kab / Kota')
            ->setCellValue('P'.$row, 'Provinsi')
            ->setCellValue('Q'.$row, 'Agama')
            ->setCellValue('R'.$row, 'Status Keluarga')
            ->setCellValue('S'.$row, 'Diterima Tanggal')
            ->setCellValue('T'.$row, 'Keterangan')
            ->setCellValue('U'.$row, 'Foto')
            ->setCellValue('V'.$row, 'No. Kartu Keluarga')
            ->setCellValue('W'.$row, 'Nama Ayah')
            ->setCellValue('X'.$row, 'Nama Ibu')
            ->setCellValue('Y'.$row, 'Tempat Lahir Ayah')
            ->setCellValue('Z'.$row, 'Tgl Lahir Ayah')
            ->setCellValue('AA'.$row, 'Tempat Lahir Ibu')
            ->setCellValue('AB'.$row, 'Tgl Lahir Ibu')
            ->setCellValue('AC'.$row, 'Alamat Orang Tua')
            ->setCellValue('AD'.$row, 'Pekerjaan Ayah')
            ->setCellValue('AE'.$row, 'Penghasilan Ayah')
            ->setCellValue('AF'.$row, 'Pekerjaan Ibu')
            ->setCellValue('AG'.$row, 'Penghasilan Ibu')
            ->setCellValue('AH'.$row, 'Ket Hidup Ayah')
            ->setCellValue('AI'.$row, 'Ket Hidup Ibu')
            ->setCellValue('AJ'.$row, 'No Telepon Ortu')
            ->setCellValue('AK'.$row, 'Nama Wali')
            ->setCellValue('AL'.$row, 'Tempat Lahir Wali')
            ->setCellValue('AM'.$row, 'Tanggal Lahir Wali')
            ->setCellValue('AN'.$row, 'Alamat Wali')
            ->setCellValue('AO'.$row, 'Jenis Kel Wali')
            ->setCellValue('AP'.$row, 'Agama')
            ->setCellValue('AQ'.$row, 'Pekerjaan Wali')
            ->setCellValue('AR'.$row, 'Penghasilan Wali')
            ->setCellValue('AS'.$row, 'No Tlp Wali');
 
$nomor 	= 1; // set nomor urut = 1;
 
$row++; // pindah ke row bawahnya. (ke row 2)
 
// lakukan perulangan untuk menuliskan data siswa
while( $data = mysql_fetch_array($siswa)){
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, $nomor )
            ->setCellValue('B'.$row, $data['nis_lokal'] )
            ->setCellValue('C'.$row, $data['nsm_mi'] )
            ->setCellValue('D'.$row, $data['madrasah'] )
            ->setCellValue('E'.$row, $data['alamat'] )
            ->setCellValue('F'.$row, $data['kecamatan'] )
            ->setCellValue('G'.$row, $data['nama_siswa'])
            ->setCellValue('H'.$row, $data['jk_siswa'])
            ->setCellValue('I'.$row, $data['tempat_lahir'])
            ->setCellValue('J'.$row, $data['tanggal_lahir'])
            ->setCellValue('K'.$row, $data['nis_nasional'])
            ->setCellValue('L'.$row, $data['kelas'])
            ->setCellValue('M'.$row, $data['alamat_siswa'])
            ->setCellValue('N'.$row, $data['kecamatan_siswa'])
            ->setCellValue('O'.$row, $data['kab_kota'])
            ->setCellValue('P'.$row, $data['propinsi'])
            ->setCellValue('Q'.$row, $data['agama'])
            ->setCellValue('R'.$row, $data['status_kel'])
            ->setCellValue('S'.$row, $data['terima_tgl'])
            ->setCellValue('T'.$row, $data['keterangan'])
            ->setCellValue('U'.$row, $data['foto'])
            ->setCellValue('V'.$row, $data['no_kartu_keluarga'])
            ->setCellValue('W'.$row, $data['nama_ayah'])
            ->setCellValue('X'.$row, $data['nama_ibu'])
            ->setCellValue('Y'.$row, $data['tempat_lahir_ayah'])
            ->setCellValue('Z'.$row, $data['tgl_lahir_ayah'])
            ->setCellValue('AA'.$row, $data['tempat_lahir_ibu'])
            ->setCellValue('AB'.$row, $data['tgl_lahir_ibu'])
            ->setCellValue('AC'.$row, $data['alamat_ortu'])
            ->setCellValue('AD'.$row, $data['pekerjaan_ayah'])
            ->setCellValue('AE'.$row, $data['penghasilan_ayah'])
            ->setCellValue('AF'.$row, $data['pekerjaan_ibu'])
            ->setCellValue('AG'.$row, $data['penghasilan_ibu'])
            ->setCellValue('AH'.$row, $data['ket_hidup_ayah'])
            ->setCellValue('AI'.$row, $data['ket_hidup_ibu'])
            ->setCellValue('AJ'.$row, $data['no_tlp_ortu'])
            ->setCellValue('AK'.$row, $data['nama_wali'])
            ->setCellValue('AL'.$row, $data['tempat_lahir_wali'])
            ->setCellValue('AM'.$row, $data['tgl_lahir_wali'])
            ->setCellValue('AN'.$row, $data['alamat_wali'])
            ->setCellValue('AO'.$row, $data['jenis_kel_wali'])
            ->setCellValue('AP'.$row, $data['agama_wali'])
            ->setCellValue('AQ'.$row, $data['pekerjaan_wali'])
            ->setCellValue('AR'.$row, $data['penghasilan_wali'])
            ->setCellValue('AS'.$row, $data['no_tlp_wali']);
			
	$row++; // pindah ke row bawahnya ($row + 1)
	$nomor++;
}
 
// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle('Siswa');
 
// Set sheet yang aktif adalah index pertama, jadi saat dibuka akan langsung fokus ke sheet pertama
$objPHPExcel->setActiveSheetIndex(0);
 
 
// Download (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="data_siswa.xls"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');
// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
 
$objWriter->save('php://output');
exit;
 
?>