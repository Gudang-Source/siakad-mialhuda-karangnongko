<?php
 
# MEMBUAT KONEKSI KE DATABASE
include('../../settings/config.php');
 
# MENGAMBIL DATA DARI DATABASE MYSQL
$guru = mysql_query("SELECT * FROM tbl_guru ORDER BY nomer_pegawai ASC");
 
 
/** Include PHPExcel */
require_once dirname(__FILE__) . '/PHPExcel/Classes/PHPExcel.php';
 
$objPHPExcel = new PHPExcel();
 
// Set document properties
$objPHPExcel->getProperties()->setCreator("Mastrayasa")
							->setLastModifiedBy("Mastrayasa")
							->setTitle("Data Guru")
							->setSubject("Guru")
							->setDescription("Data Guru MI Al-Huda Karangnongko")
							->setKeywords("sibangStudio PHPExcel php")
							->setCategory("Umum");
// mulai dari baris ke 2
$row = 2;
 
// Tulis judul tabel
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, 'Nopeg')
            ->setCellValue('B'.$row, 'NIP')
            ->setCellValue('C'.$row, 'Nama')
            ->setCellValue('D'.$row, 'Jenis Kelamin')
            ->setCellValue('E'.$row, 'Nama Ibu')
            ->setCellValue('F'.$row, 'Status')
            ->setCellValue('G'.$row, 'Agama')
            ->setCellValue('H'.$row, 'Tempat Lahir')
            ->setCellValue('I'.$row, 'Tgl Lahir')
            ->setCellValue('J'.$row, 'Thn Lulus Sertifikasi')
            ->setCellValue('K'.$row, 'NUPTK')
            ->setCellValue('L'.$row, 'NRG')
            ->setCellValue('M'.$row, 'Tmt Capeg Honor')
            ->setCellValue('N'.$row, 'Gol Ruang')
            ->setCellValue('O'.$row, 'Tmt Gol Ruang')
            ->setCellValue('P'.$row, 'Masa Kerja')
            ->setCellValue('Q'.$row, 'Pendidikan Akhir')
            ->setCellValue('R'.$row, 'Thn Pendidikan')
            ->setCellValue('S'.$row, 'Jurusan Pendidikan')
            ->setCellValue('T'.$row, 'Jabatan')
            ->setCellValue('U'.$row, 'Jml Jam')
            ->setCellValue('V'.$row, 'Alamat')
            ->setCellValue('W'.$row, 'No Telepon')
            ->setCellValue('X'.$row, 'Email')
            ->setCellValue('Y'.$row, 'Id Pegawai')
            ->setCellValue('Z'.$row, 'Foto');
 
$nomor 	= 1; // set nomor urut = 1;
 
$row++; // pindah ke row bawahnya. (ke row 2)
 
// lakukan perulangan untuk menuliskan data siswa
while( $data = mysql_fetch_array($guru)){
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, $data['nomer_pegawai'] )
            ->setCellValue('B'.$row, $data['nip'] )
            ->setCellValue('C'.$row, $data['nama'] )
            ->setCellValue('D'.$row, $data['jenis_kel'] )
            ->setCellValue('E'.$row, $data['nama_ibu'] )
            ->setCellValue('F'.$row, $data['status'] )
            ->setCellValue('G'.$row, $data['agama'])
            ->setCellValue('H'.$row, $data['tempat_lahir'])
            ->setCellValue('I'.$row, $data['tgl_lahir'])
            ->setCellValue('J'.$row, $data['thn_lulus_setifikasi'])
            ->setCellValue('K'.$row, $data['nuptk'])
            ->setCellValue('L'.$row, $data['nrg'])
            ->setCellValue('M'.$row, $data['tmt_capeg_honor'])
            ->setCellValue('N'.$row, $data['gol_ruang'])
            ->setCellValue('O'.$row, $data['tmt_gol_ruang'])
            ->setCellValue('P'.$row, $data['masa_kerja_sek'])
            ->setCellValue('Q'.$row, $data['pendidikan_akhir'])
            ->setCellValue('R'.$row, $data['thn_pendidikan'])
            ->setCellValue('S'.$row, $data['jurusan_pendidikan'])
            ->setCellValue('T'.$row, $data['jabatan'])
            ->setCellValue('U'.$row, $data['jml_jam'])
            ->setCellValue('V'.$row, $data['alamat'])
            ->setCellValue('W'.$row, $data['no_tlp'])
            ->setCellValue('X'.$row, $data['email'])
            ->setCellValue('Y'.$row, $data['id_peg'])
            ->setCellValue('Z'.$row, $data['foto']);
			
	$row++; // pindah ke row bawahnya ($row + 1)
	$nomor++;
}
 
// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle('Guru');
 
// Set sheet yang aktif adalah index pertama, jadi saat dibuka akan langsung fokus ke sheet pertama
$objPHPExcel->setActiveSheetIndex(0);
 
 
// Download (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="data_guru.xls"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');
// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
 
$objWriter->save('php://output');
exit;
 
?>