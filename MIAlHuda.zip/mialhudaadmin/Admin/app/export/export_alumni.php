<?php
 
# MEMBUAT KONEKSI KE DATABASE
include('../../settings/config.php');
 
# MENGAMBIL DATA DARI DATABASE MYSQL
$alumni = mysql_query("SELECT * FROM tbl_alumni ORDER BY nis_lokal ASC");
 
 
/** Include PHPExcel */
require_once dirname(__FILE__) . '/PHPExcel/Classes/PHPExcel.php';
 
$objPHPExcel = new PHPExcel();
 
// Set document properties
$objPHPExcel->getProperties()->setCreator("Mastrayasa")
							->setLastModifiedBy("Mastrayasa")
							->setTitle("Data Alumni")
							->setSubject("Alumni")
							->setDescription("Data Alumni MI Al-Huda Karangnongko")
							->setKeywords("sibangStudio PHPExcel php")
							->setCategory("Umum");
// mulai dari baris ke 2
$row = 2;
 
// Tulis judul tabel
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, 'No')
            ->setCellValue('B'.$row, 'NIS Lokal')
            ->setCellValue('C'.$row, 'Nama Siswa')
            ->setCellValue('D'.$row, 'Jenis Kelamin')
            ->setCellValue('E'.$row, 'Tempat Lahir')
            ->setCellValue('F'.$row, 'Tanggal Lahir')
            ->setCellValue('G'.$row, 'NIS Nasional')
            ->setCellValue('H'.$row, 'Alamat Siswa')
            ->setCellValue('I'.$row, 'Kecamatan Siswa')
            ->setCellValue('J'.$row, 'Kabupaten Siswa')
            ->setCellValue('K'.$row, 'Provinsi Siswa')
            ->setCellValue('L'.$row, 'Agama')
            ->setCellValue('M'.$row, 'Status Keluarga')
            ->setCellValue('N'.$row, 'Terima Tanggal')
            ->setCellValue('O'.$row, 'Keterangan')
            ->setCellValue('P'.$row, 'Foto');
 
$nomor 	= 1; // set nomor urut = 1;
 
$row++; // pindah ke row bawahnya. (ke row 2)
 
// lakukan perulangan untuk menuliskan data siswa
while( $data = mysql_fetch_array($alumni)){
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$row, $nomor )
            ->setCellValue('B'.$row, $data['nis_lokal'] )
            ->setCellValue('C'.$row, $data['nama_siswa'] )
            ->setCellValue('D'.$row, $data['jk_siswa'] )
            ->setCellValue('E'.$row, $data['tempat_lahir'] )
            ->setCellValue('F'.$row, $data['tanggal_lahir'] )
            ->setCellValue('G'.$row, $data['nis_nasional'])
            ->setCellValue('H'.$row, $data['alamat_siswa'])
            ->setCellValue('I'.$row, $data['kecamatan_siswa'])
            ->setCellValue('J'.$row, $data['kab_kota'])
            ->setCellValue('K'.$row, $data['propinsi'])
            ->setCellValue('L'.$row, $data['agama'])
            ->setCellValue('M'.$row, $data['status_kel'])
            ->setCellValue('N'.$row, $data['terima_tgl'])
            ->setCellValue('O'.$row, $data['keterangan'])
            ->setCellValue('P'.$row, $data['foto']);
			
	$row++; // pindah ke row bawahnya ($row + 1)
	$nomor++;
}
 
// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle('Alumni');
 
// Set sheet yang aktif adalah index pertama, jadi saat dibuka akan langsung fokus ke sheet pertama
$objPHPExcel->setActiveSheetIndex(0);
 
 
// Download (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="data_alumni.xls"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');
// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
 
$objWriter->save('php://output');
exit;
 
?>