-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2017 at 06:24 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mialhuda_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_alumni`
--

CREATE TABLE IF NOT EXISTS `tbl_alumni` (
`id_alumni` int(11) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `nama_siswa` varchar(40) NOT NULL,
  `jk_siswa` varchar(1) NOT NULL,
  `tempat_lahir` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `nis_nasional` varchar(10) NOT NULL,
  `alamat_siswa` text NOT NULL,
  `kecamatan_siswa` varchar(15) NOT NULL,
  `kab_kota` varchar(6) NOT NULL,
  `propinsi` varchar(13) NOT NULL,
  `agama` varchar(5) NOT NULL,
  `status_kel` varchar(2) NOT NULL,
  `terima_tgl` date NOT NULL,
  `keterangan` varchar(11) NOT NULL,
  `foto` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_artikel`
--

CREATE TABLE IF NOT EXISTS `tbl_artikel` (
`id_artikel` int(4) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `isi` text NOT NULL,
  `gambar` varchar(60) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `penerbit` varchar(5) NOT NULL,
  `keterangan` varchar(10) NOT NULL,
  `jml_view` int(5) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_artikel`
--

INSERT INTO `tbl_artikel` (`id_artikel`, `judul`, `isi`, `gambar`, `tanggal`, `jam`, `penerbit`, `keterangan`, `jml_view`) VALUES
(1, 'Pengumuman Jadwal UN 2016', '<p>Kementerian Pendidikan dan Kebudayaan merilis informasi bahwa pihaknya akan menyelenggarakan tiga kali ujian nasional (UN) di tahun pelajaran 2015/2016. Ujian nasional (UN) pertama merupakan ujian perbaikan bagi peserta UN tahun 2015 yang belum memenuhi standar kompetensi lulusan (SKL) pada satu atau lebih mata pelajaran, dan berkeinginan memperbaikinya.</p>\r\n\r\n<p>Ujian nasional yang kedua, merupakan ujian utama tahun 2016 dengan kisi-kisi baru, dan Ujian nasional ketiga merupakan perbaikan bagi peserta UN tahun 2016.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Rencana ujian nasional tersebut disampaikan oleh Kepala Badan Penelitian dan Pengembangan Kemendikbud, Totok Suprayitno, pada rapat koordinasi Mendikbud dengan Kepala Dinas Pendidikan Provinsi, Kepala LPMP, dan Kepala P4TK seluruh Indonesia, Jumat (10/07/2015) di Jakarta.</p>\r\n\r\n<p>Kepala Badan Penelitian dan Pengembangan Kemendikbud, Totok Suprayitno menyampaikan tanggal-tanggal penting untuk pelaksanaan ketiga UN tersebut adalah sebagai berikut :</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&ndash; UN pertama yang dijadwalkan adalah UN perbaikan 2015 yang akan dilaksanakan pada 22 Februari 2016.<br />\r\n&ndash; Untuk UN utama 2016 akan dilaksanakan mulai 4 April, dan<br />\r\n&ndash; UN perbaikan tahun 2016 akan dilaksanakan awal Juni/September tahun 2016.</p>\r\n\r\n<p>Untuk materi ujian, menurutnya akan disesuaikan dengan jenis ujian nasional. Ujian nasional (UN) perbaikan tahun 2015 materi ujiannya sesuai dengan kisi-kisi UN 2015. Untuk ujian nasional utama 2016 materi ujiannya ada tiga, yaitu irisan kurikulum KTSP dan K13, Kisi-kisi UN yang dikeluarkan BSNP (bersifat makro), dan sesuai dengan ketuntasan kurikulum. Sedangkan untuk UN perbaikan 2016, materinya sama dengan ujian nasional utama 2016, demikian seperti yang dijelaskan Totok Suprayitno.</p>\r\n\r\n<p>Dari sisi pelaksanaan, Ujian nasional (UN) perbaikan 2015 akan dilakukan dengan berbasis komputer. Ujian akan dilaksanakan di SMA/SMK di tempat berdomisili siswa saat ini dan siswa dapat mendaftar secara online ke dinas provinsi. Untuk UN utama di 2016 akan dilaksanakan di sekolah masing-masing dengan berbasis kertas dan komputer. Sedangkan untuk UN perbaikan 2016, mekanismenya sama dengan UN perbaikan 2015, yaitu berbasis komputer dan pendaftaran dilakukan secara online (daring) di dinas provinsi.</p>\r\n\r\n<p>Sumber:<br />\r\n&ndash; Kemdikbud</p>\r\n', '../insert/gambar/logo.png', '2016-03-18', '07:52:19', '0', 'pengumuman', 15),
(3, 'Pembagian Username dan Password Sistem Informasi MI Al-Huda Karangnongko ', '<p>Berhubungan dengan akan adanya Sistem Informasi Akademik Sekolah di MI Al Huda Karangnongko, maka pada tanggal 1 April 2016 setiap siswa dan guru akan di berikan username dan password untuk dapat masuk kedalam Sistem Informasi Akademik Sekolah MI Al Huda.</p>\r\n', '../insert/gambar/mi_alhuda.png', '2016-03-18', '08:16:29', '0', 'pengumuman', 5),
(4, 'Kerja Bakti Bersih-Bersi Sekolah', '<p>Diumumkan kepada seluruh siswa. Dalam rangka menjaga kebersihan sekolah, sekolah akan mengadakan kerja bakti. Kerja bakti dilaksankan pada hari Sabtu tanggal 22&nbsp;Mei 2016&nbsp;mulai pukul 08.30 - 10.30. Anak laki-laki diminta membawa sabit atau cangkul, sedangkan anak perempuan diminta membawa sapu lidi atau ijuk dan keranjang sampah.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Demikian pengumuman ini kami sampaikan, diharapkan semua siswa melaksanakan dengan sebaik-baiknya.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table border="0" cellpadding="0" cellspacing="0">\r\n	<tbody>\r\n		<tr>\r\n			<td style="text-align:left; width:139px">Kalimat pembuka</td>\r\n			<td style="text-align:left; width:11px">:</td>\r\n			<td style="text-align:left; width:402px">Dalam rangka menjaga kebersihan sekolah akan mengadakan kerja bakti</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="text-align:left; width:139px">Hari, tanggal</td>\r\n			<td style="text-align:left; width:11px">:</td>\r\n			<td style="text-align:left; width:402px">Sabtu, 22 Mei 2016.</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="text-align:left; width:139px">Waktu</td>\r\n			<td style="text-align:left; width:11px">:</td>\r\n			<td style="text-align:left; width:402px">Pukul 08.30 - 10.30</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="text-align:left; width:139px">Tempat</td>\r\n			<td style="text-align:left; width:11px">:</td>\r\n			<td style="text-align:left; width:402px">Lingkungan sekolah</td>\r\n		</tr>\r\n		<tr>\r\n			<td style="text-align:left; width:139px">Keperluan</td>\r\n			<td style="text-align:left; width:11px">:</td>\r\n			<td style="text-align:left; width:402px">Anak laki-laki diminta membawa sabit atau cangkul, sedangkan anak perempuan diminta membawa sapu lidi atau ijuk dan keranjang sampah.</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '../insert/gambar/mi_alhuda.png', '2016-03-18', '08:19:17', '0', 'pengumuman', 13),
(5, 'Agenda Ketiga', '<p>Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum.</p>\r\n', 'gambar/logo-kemenag.png', '2016-03-18', '07:00:00', '0', 'agenda', 0),
(7, 'Agenda Kedua', '<p>Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum.</p>\r\n', '../insert/gambar/logo-kemenag.png', '2016-03-18', '02:17:31', '0', 'agenda', 3),
(9, 'Agenda Pertama', '<p>Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum.</p>\r\n', '../insert/gambar/mi_alhuda.png', '2016-03-18', '03:51:30', '0', 'agenda', 1),
(10, 'Sekolah Rusak, Siswa SD di Sampang Ikuti UN di Teras Rumah Warga', '<p><strong>Liputan6.com, Sleman -</strong>&nbsp;Meski&nbsp;<a href="http://news.liputan6.com/read/2234251/14-penghuni-lapas-anak-tangerang-ikuti-un-tingkat-sd">Ujian Nasional</a>&nbsp;(UN) Sekolah Dasar (SD) baru dimulai pada jam 08.00 WIB, para siswa SDIT Salsabila Sleman, Daerah Istimewa Yogyakarta, diminta datang sejak pukul 06.30 WIB. Ini karena sebelum mengerjakan ujian, mereka mengikuti salat dhuha dan doa bersama, memohon dimudahkan dalam menjawab soal-soal ujian.&nbsp;<br />\r\n<br />\r\nSeperti ditayangkan&nbsp;<em>Liputan 6 Siang SCTV</em>, Senin (18/5/2015), usai doa bersama mereka diberi makanan tambahan dan susu, agar lebih berkonsentrasi melaksanakan UN.<br />\r\n<br />\r\nDi Sampang, Jawa Timur, karena gedung sekolah sudah diratakan dengan tanah akibat rusak parah, murid-murid SDN Kotah 2, Kecamatan Jrengik terpaksa mengerjakan UN di teras rumah warga. Meski ujian tidak di tempat semestinya, mereka optimistis bisa meraih nilai bagus sebagai bekal untuk melanjutkan pendidikan.<br />\r\n<br />\r\nDi Bogor, Jawa Barat, karena terjangkit demam berdarah, Sanum Khaleda, murid SDN Bantarjati 9, terpaksa mengikuti UN di ruang perawatan sebuah rumah sakit. Dengan tangan diinfus, Hanum tetap berusaha mengerjakan soal-soal ujian sebaik mungkin di bawah pengawasan petugas dari dinas pendidikan Kota Bogor.<br />\r\n<br />\r\nSementara di Solo, Jawa Tengah, siswa-siswi berkebutuhan khusus Sekolah Dasar Luar Biasa (SDLB) Yayasan Pendidikan Anak Cacat (YPAC) mengikuti&nbsp;<a href="http://news.liputan6.com/read/2234144/terserang-dbd-siswi-sd-di-bogor-jalani-un-di-rumah-sakit">UN SD&nbsp;</a>dengan perlakukan khusus. Mereka dibantu pengawas yang juga bertugas membantu mereka memahamai soal ujian.Ujian Nasional di YPAC dibagi menjadi dua kelompok. Yaitu bagi anak penyandang tunadaksa dengan intelejensi normal dan ujian untuk anak tunadaksa dengan intelejensi dibawah rata-rata</p>\r\n', '../insert/gambar/logo-kemenag.png', '2016-03-18', '03:58:04', '0', 'berita', 1),
(11, 'Peserta UN Diimbau Jangan Percaya Penjual Kunci Jawaban', '<p><strong>DEPOK</strong>&nbsp;- Wali Kota Depok Idris Abdul Somat meminta kepada peserta Ujian Nasional (UN) untuk tidak percaya kepada penjual kunci jawaban. Idris meminta agar siswa cukup percaya diri untuk mengerjakan soal UN.<br />\r\n<br />\r\n&quot;Soal bocoran kunci jawaban, kami minta siswa untuk lebih percaya kepada diri sendiri,&quot; kata Idris di SMAN 7 Tapos, Depok, Senin (4/4/2016).<br />\r\n<br />\r\nKebocoran soal atau kunci jawaban dikhawatirkan lebih rentan terjadi pada UN Paper atau tertulis. Karena itu Idris meminta agar siswa ataupun tenaga pendidik tidak percaya pada oknum yang sengaja menjual kunci jawaban.<br />\r\n<br />\r\n&quot;Jangan percaya pada orang yang jualan - jualan ilmu pengetahuan, itu orang - orang yang tak bertanggung jawab,&quot; tukasnya.<br />\r\n<br />\r\nKepala Dinas Pendidikan Kota Depok Herry Pansila menegaskan siswa lebih optimis dan mudah mengerjakan UN dengan didahului berbagai latihan soal atau try out. Ia juga meminta agar siswa menjunjung tinggi kejujuran dan nilai integritas saat mengerjakan soal.</p>\r\n\r\n<div>&nbsp;</div>\r\n', 'gambar/logo-kemenag.png', '2016-03-19', '02:32:10', '0', 'berita', 1),
(12, 'Kerjakan Soal UN, Siswa Diminta Tenang', '<p><strong>DEPOK</strong>&nbsp;- Hari ini siswa tingkat SMA/SMK di Depok menjalani Ujian Nasional. Sejumlah siswa mengaku grogi saat mengerjakan soal. Karena mereka masih menganggap UN sebagai hal yang menakutkan.&nbsp;<br />\r\n<br />\r\n&quot;Siswa peserta UN jangan tegang, dan panik dalam mengerjakan pelaksanaan soal-soal UN,&quot; kata anggota Komisi D DPRD Kota Depok Rezky M Noor, Senin (4/4/2016).<br />\r\n<br />\r\nDikatakan dia, UN jangan dianggap hal menakutkan karena bisa berdampak pada psikologis siswa. Diakui masih banyak yang menganggap UN sebagai penentu kelulusan.&nbsp;<br />\r\n<br />\r\nPadahal yang perlu diketahui bahwa kelulusan tidak hanya dari UN saja. &quot;Tapi ditentukan juga oleh hasil dari sekolah. UN bobotnya 40 persen, sisanya dari sekolah,&quot; katanya.<br />\r\n<br />\r\nKendati demikian dia tetap meminta siswa serius mengerjakan soal UN. Siswa jangan main-main saat ujian. &quot;Jadi semestinya UN jangan dikesankan menyeramkan bagi para siswa. Mereka harusnya bisa lebih tenang,&quot; ungkapnya.<br />\r\n<br />\r\nDinas Pendidikan Kota Depok mencatat total siswa SMA/SMK yang ikut UN sebanyak 16.036 siswa. Tercatat ada 19 SMA dan 24 SMK di Depok menjalankan UN berbasis komputer atau CBT.&nbsp;<br />\r\n<br />\r\nUntuk UN sendiri terdapat dua model, yakni berbasis paper dengan 8.072 siswa, atau 51 persen dari jumlah peserta dan untuk CBT, 7.964 siswa atau 49 persen dari jumlah peserta.&nbsp;<br />\r\n<br />\r\n&quot;Tahun ini&nbsp; ada kenaikkan jumlah sekolah yang menggunakan sistem CBT, tahun lalu ada 16 sekolah kini mencapai 19 sekolah, dan terbanyak di Jawa Barat,&quot; kata Kepala Dinas Pendidikan (Disdik) Kota Depok Herri Pansila.</p>\r\n', '../insert/gambar/mi_alhuda.png', '2016-03-19', '02:34:42', '0', 'berita', 10),
(14, 'Prestasi Bidang Kejuaraan Silat', '<p>Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum.</p>\r\n', '../insert/gambar/mi_alhuda.png', '2016-03-26', '03:38:06', '0', 'prestasi', 2),
(15, 'Prestasi Siswa MI Al Huda Karangnongko', '<p>Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum.</p>\r\n', 'gambar/mi_alhuda.png', '2016-04-15', '04:37:13', '0', 'prestasi', 0),
(16, 'Doa Bersama Menjelang Ujian Nasional', '<p>Sehubungan dengan akan berlangsungnya Ujian Nasional tingkat SD maupun MI pada tanggal 16 Mei 2016, maka MI Al Huda Karangnongko akan mengadakan doa bersama sebelum Ujian Nasional yang akan dilaksanakan pada tanggal 14 Mei 2016 bertempat di MI Al Huda Karagnongko.</p>\r\n', 'gambar/mi_alhuda.png', '2016-04-19', '05:45:15', '0', 'pengumuman', 6);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_catatan_wali`
--

CREATE TABLE IF NOT EXISTS `tbl_catatan_wali` (
`id` int(11) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `catatan` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `tbl_catatan_wali`
--

INSERT INTO `tbl_catatan_wali` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `thn_ajaran`, `semester`, `catatan`) VALUES
(3, '12346', '1B', '20160003', '2015/2016', 'Ganjil', 'Pertahankan Prestasinya (update admin)'),
(5, '12346', '1B', '20160003', '2015/2016', 'Genap', 'Pertahankan Prestasinya ya. Jangan lupa untuk selalu belajar (update)'),
(18, '111234040012141187', '2B', '20160005', '2015/2016', 'Ganjil', 'Tidak Ada'),
(20, '111234040012141187', '2B', '20160005', '2015/2016', 'Genap', ''),
(21, '111234040012141188', '2B', '20160005', '2015/2016', 'Genap', ''),
(26, '111234040012141189', '2B', '20160005', '2015/2016', 'Ganjil', ''),
(30, '111234040012141189', '2B', '20160005', '2015/2016', 'Genap', 'Tidak ada catatan'),
(34, '111234040012141191', '2B', '20160005', '2015/2016', 'Ganjil', ''),
(35, '111234040012141191', '2B', '20160005', '2015/2016', 'Genap', ''),
(36, '111234040012141192', '2B', '20160005', '2015/2016', 'Ganjil', ''),
(37, '111234040012141190', '2B', '20160005', '2015/2016', 'Ganjil', ''),
(38, '111234040012141194', '2B', '20160005', '2015/2016', 'Ganjil', ''),
(39, '111234040012141190', '2B', '20160005', '2015/2016', 'Ganjil', ''),
(40, '111234040012141191', '2B', '20160005', '2015/2016', 'Ganjil', ''),
(42, '111234040012141192', '2B', '20160005', '2015/2016', 'Ganjil', ''),
(43, '111234040012141191', '2B', '20160005', '2015/2016', 'Genap', ''),
(44, '111234040012141192', '2B', '20160005', '2015/2016', 'Genap', ''),
(55, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 'Tidak Ada'),
(56, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 'Tidak Ada :'),
(57, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 'Tidak ada cttn'),
(58, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 'Tidak Ada Catatan'),
(59, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 'Tidak Ada'),
(60, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 'Tidak Ada'),
(61, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 'Tidak Ada'),
(62, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 'Tidak Ada');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ekskul`
--

CREATE TABLE IF NOT EXISTS `tbl_ekskul` (
`id_ekstra` int(2) NOT NULL,
  `nama_ekstra` varchar(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_ekskul`
--

INSERT INTO `tbl_ekskul` (`id_ekstra`, `nama_ekstra`) VALUES
(1, 'Pildacil'),
(2, 'Qiro''ah  / Kaligrafi'),
(3, 'Pramuka'),
(4, 'Pencak Silat'),
(5, 'Hadroh');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_galeri`
--

CREATE TABLE IF NOT EXISTS `tbl_galeri` (
`id_galeri` int(11) NOT NULL,
  `nama_gambar` varchar(60) NOT NULL,
  `gambar` varchar(60) NOT NULL,
  `tgl_upload` date NOT NULL,
  `penerbit` varchar(5) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_galeri`
--

INSERT INTO `tbl_galeri` (`id_galeri`, `nama_gambar`, `gambar`, `tgl_upload`, `penerbit`) VALUES
(1, 'GridRecyclerView.png', 'galeri/GridRecyclerView.png', '0000-00-00', '0'),
(2, 'navdrawer-final.png', 'galeri/navdrawer-final.png', '2016-03-19', '0'),
(3, 'palette-android1.png', 'galeri/palette-android1.png', '2016-03-19', '0'),
(4, 'recyclerview.png', 'galeri/recyclerview.png', '2016-03-19', '0'),
(5, 'mi_alhuda.png', 'galeri/mi_alhuda.png', '2016-04-20', '0'),
(6, 'depag2.jpg', 'galeri/depag2.jpg', '2016-04-26', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guru`
--

CREATE TABLE IF NOT EXISTS `tbl_guru` (
  `nomer_pegawai` varchar(8) NOT NULL,
  `nip` varchar(21) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kel` varchar(1) NOT NULL,
  `nama_ibu` varchar(25) NOT NULL,
  `status` varchar(5) NOT NULL,
  `agama` varchar(10) NOT NULL,
  `tempat_lahir` varchar(15) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `sertifikasi` varchar(5) NOT NULL,
  `thn_lulus_setifikasi` int(4) NOT NULL,
  `nuptk` varchar(19) NOT NULL,
  `nrg` varchar(12) NOT NULL,
  `tmt_capeg_honor` date NOT NULL,
  `gol_ruang` varchar(4) NOT NULL,
  `tmt_gol_ruang` date NOT NULL,
  `masa_kerja_sek` int(2) NOT NULL,
  `pendidikan_akhir` varchar(4) NOT NULL,
  `thn_pendidikan` int(4) NOT NULL,
  `jurusan_pendidikan` varchar(20) NOT NULL,
  `jabatan` varchar(15) NOT NULL,
  `jml_jam` int(2) NOT NULL,
  `alamat` text NOT NULL,
  `no_tlp` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `id_peg` varchar(14) NOT NULL,
  `foto` varchar(60) NOT NULL,
  `status_guru` varchar(11) NOT NULL,
  `username` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_guru`
--

INSERT INTO `tbl_guru` (`nomer_pegawai`, `nip`, `nama`, `jenis_kel`, `nama_ibu`, `status`, `agama`, `tempat_lahir`, `tgl_lahir`, `sertifikasi`, `thn_lulus_setifikasi`, `nuptk`, `nrg`, `tmt_capeg_honor`, `gol_ruang`, `tmt_gol_ruang`, `masa_kerja_sek`, `pendidikan_akhir`, `thn_pendidikan`, `jurusan_pendidikan`, `jabatan`, `jml_jam`, `alamat`, `no_tlp`, `email`, `id_peg`, `foto`, `status_guru`, `username`) VALUES
('20160001', '19710419 199303 1 003', 'Suharyanto, S.Pd', 'L', 'Mujani', 'PNS', 'ISLAM', 'Ngaglik', '1971-04-19', 'Sudah', 2008, '2751-7496-5120-0012', '085112063001', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Kemad', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160001'),
('20160002', '19621012 198503 2 001', 'Nur Indaryani, S.Pd.I', 'P', 'Ruminah', 'PNS', 'ISLAM', 'Yogyakarta', '1962-10-12', 'Sudah', 2009, '0344-7406 4130 0043', '091839877044', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Guru Kelas', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160002'),
('20160003', '19650729 198503 2 001', 'Yuhanah, S.Ag', 'P', 'Waginem', 'PNS', 'ISLAM', 'Sleman', '1965-07-29', 'Sudah', 2008, '5061 7436 4430 0003', '092688392023', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Guru Kelas', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160003'),
('20160004', '19710131 199703 2 002', 'Sri Suryani, S.Ag', 'P', 'Surti', 'PNS', 'ISLAM', 'Sleman', '1971-07-31', 'Sudah', 2008, '1063 7496 5030 0013', '191487422016', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Guru Kelas', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160004'),
('20160005', '19710505 199703 2 003', 'Immawati M, S.Ag, M.Si', 'P', 'Sunik Wariyatik', 'PNS', 'ISLAM', 'Magetan', '1971-05-05', 'Sudah', 2008, '5837 7496 5130 0022', '083713063002', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Guru Kelas', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160005'),
('20160006', '19691212 199403 2 002', 'Isti Yumanah, S.Pd.I', 'P', 'Seneng', 'PNS', 'ISLAM', 'Sleman', '1969-12-12', 'Sudah', 2010, '2544 7476 5030 0033', '021840912018', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Guru Kelas', 0, '', '', '', '_', '../insert/foto/avatar3.png', 'AKTIF', '20160006'),
('20160007', '19720302 199703 2 002', 'Suprapti, S.Pd', 'P', 'Djaenah ', 'PNS', 'ISLAM', 'Yogyakarta', '0000-00-00', 'Sudah', 2013, '8634 7506 5230 0022', '130282124228', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Guru Kelas', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160007'),
('20160008', '19700705 199303 1 004', 'Susetya, S.Pd', 'L', 'Sri Hartini', 'PNS', 'ISLAM', 'Sleman', '1970-07-05', 'Belum', 0, '0839 7486 4920 0022', '_', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Guru Kelas', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160008'),
('20160009', '_', 'Sumarno', 'L', 'Jiman', 'GTY', 'ISLAM', 'Sleman', '1959-02-02', 'Sudah', 2011, '0534 7376 3920 0072', '110282136003', '0000-00-00', '', '0000-00-00', 0, 'SLTA', 0, '', 'Guru Kelas', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160009'),
('20160010', '19720608 200604 1 028', 'Sugito, S.Ag', 'L', 'Urip', 'PNS', 'ISLAM', 'Magelang', '1972-06-08', 'Sudah', 2013, '4940 7506 5220 0022', '_', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Guru Kelas', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160010'),
('20160011', '_', 'Fatimah, S.Pd', 'P', 'Romiyem', 'GTY', 'ISLAM', 'Sleman', '1981-04-26', 'Belum', 0, '0758759661300032', '_', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Guru Kelas', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160011'),
('20160012', '_', 'Indri Sulistyaningsih, S.Ag', 'P', 'Sainem Kholidiyah', 'GTY', 'ISLAM', 'Sleman', '1973-03-08', 'Belum', 0, '8640 7516 5221 0062', '_', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Guru Kelas', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160012'),
('20160013', '_', 'Puji Astuti, S.Pd', 'P', 'Syamijah', 'GTY', 'ISLAM', 'Boyolali', '1982-09-22', 'Belum', 0, '2254760662300013', '_', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Guru Kelas', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160013'),
('20160014', '_', 'Nuryani, S.Pd.Jas', 'P', 'Warsilah', 'GTY', 'ISLAM', 'Sleman', '1984-02-16', 'Belum', 0, '5548762663300002', '_', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Gr Bid Studi', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160014'),
('20160015', '_', 'Efrinda Neli Nur''aini, S.Pd.I', 'P', 'Rin Sulanjari', 'GTT', 'ISLAM', 'Magetan', '1991-09-21', 'Belum', 0, '_', '_', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Gr PAI', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160015'),
('20160016', '_', 'Mujib Asngari, S.Pd.I', 'L', 'Siti Fatonah', 'GTT', 'ISLAM', 'Bantul', '1986-12-01', 'Belum', 0, '_', '_', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Gr PAI', 0, '', '', '', '_', 'Belum Ada', 'AKTIF', '20160016'),
('20160017', '', 'Reni Kurniawati', 'P', '', 'GTT', 'ISLAM', 'Sleman', '0000-00-00', 'Belum', 0, '', '', '0000-00-00', '', '0000-00-00', 0, 'S1', 0, '', 'Gr TIK', 0, '', '', '', '', 'Belum Ada', 'AKTIF', '20160017'),
('20160018', '', 'Nur Hidayah', 'P', '', '', 'ISLAM', 'Sleman', '0000-00-00', '', 0, '', '', '0000-00-00', '', '0000-00-00', 0, '', 0, '', 'Guru Kelas', 0, '', '', '', '', 'Belum Ada', 'AKTIF', '20160018');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hari`
--

CREATE TABLE IF NOT EXISTS `tbl_hari` (
`id` int(1) NOT NULL,
  `hari` varchar(6) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_hari`
--

INSERT INTO `tbl_hari` (`id`, `hari`) VALUES
(1, 'SENIN'),
(2, 'SELASA'),
(3, 'RABU'),
(4, 'KAMIS'),
(5, 'JUM''AT'),
(6, 'SABTU');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_identitas_lembaga`
--

CREATE TABLE IF NOT EXISTS `tbl_identitas_lembaga` (
`id` int(1) NOT NULL,
  `nama_lembaga` varchar(25) NOT NULL,
  `nsm` varchar(12) NOT NULL,
  `alamat_lembaga` text NOT NULL,
  `desa` varchar(11) NOT NULL,
  `kecamatan` varchar(5) NOT NULL,
  `no_tlp` varchar(15) NOT NULL,
  `kabupaten` varchar(6) NOT NULL,
  `provinsi` varchar(15) NOT NULL,
  `website` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `kode_pos` varchar(5) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_identitas_lembaga`
--

INSERT INTO `tbl_identitas_lembaga` (`id`, `nama_lembaga`, `nsm`, `alamat_lembaga`, `desa`, `kecamatan`, `no_tlp`, `kabupaten`, `provinsi`, `website`, `email`, `kode_pos`) VALUES
(1, 'MI AL HUDA KARANGNONGKO', '111234040012', 'Karangnongko', 'Maguwoharjo', 'Depok', '0274 447 827', 'Sleman', 'DI. Yogyakarta', 'www.mialhuda.sch.id', 'mialhuda@mialhuda.sch.id', '55281');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_inbox_kontak`
--

CREATE TABLE IF NOT EXISTS `tbl_inbox_kontak` (
`id` int(3) NOT NULL,
  `nama_pengirim` varchar(30) NOT NULL,
  `email` varchar(25) NOT NULL,
  `subject` text NOT NULL,
  `pesan` text NOT NULL,
  `tanggal` date NOT NULL,
  `status` varchar(13) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_inbox_kontak`
--

INSERT INTO `tbl_inbox_kontak` (`id`, `nama_pengirim`, `email`, `subject`, `pesan`, `tanggal`, `status`) VALUES
(2, 'Yudhawan Arif Pratama', 'ypratama45@gmail.com', 'Mau Tanya MI Al Huda', 'Sehubungan dengan pembukaan pendaftaran di MI Al Huda Karangnongko, saya mau bertanya mengenai informasi pendaftaran di MI Al Huda Karangnongko.\r\nTerima Kasih :)', '2016-04-24', 'Sudah Terbaca'),
(3, 'Andi', 'aa@mm.mm', 'klklklkl', 'kkljlkjakjkldjakjkdjkajkjdakjkajkadjkjkjk', '2016-05-10', 'Sudah Terbaca'),
(4, 'Ahmad Kurniawan', 'agmad99@gmail.com', 'Mau Tanya MI Al Huda', 'bbuyeeeeeeeeeeeeeeeeeeeeeeeeeeabehbahbajbjb', '2016-05-16', 'Sudah Terbaca'),
(5, 'jkjjkj', 'jhjhjh@hkhkh.jjj', 'jjhjh', 'jkhkjkh', '2017-03-05', 'Sudah Terbaca');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_info`
--

CREATE TABLE IF NOT EXISTS `tbl_info` (
`id_info` int(3) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `penerbit` varchar(5) NOT NULL,
  `keterangan` varchar(15) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_info`
--

INSERT INTO `tbl_info` (`id_info`, `judul`, `isi`, `tanggal`, `jam`, `penerbit`, `keterangan`) VALUES
(1, 'Sejarah Singkat MI Al-Huda Karangnongko', '<p>Madrasah Ibtidaiyah Al Huda didirikan pada tahun 1971. Merupakan lembaga&nbsp;pendidikan yang setingkat dengan sekolah dasar dan berada di bawah naungan&nbsp;Lembaga Pendidikan Ma&rsquo;arif NU kabupaten Sleman, Daerah Istimewa&nbsp;Yogyakarta. Madrasah Ibtidaiyah Al Huda (MI Al Huda) beralamat di Jl. Nangka&nbsp;3 Karangnongko, desa Maguwoharjo, kecamatan Depok, kabupaten sleman DIY.&nbsp;Telp (0274)&nbsp;4478271</p>\r\n\r\n<p>Kurikulum yang dikembangkan di MI Al Huda adalah&nbsp;kurikulum tingkat satuan pendidikan (KTSP) dengan materi pelajaran umum&nbsp;meliputi Pkn, IPA, IPS, Bahasa Indonesia, Matematika, Penjas, dan SBK. Untuk&nbsp;pelajaran agama antara lain Al Qur&rsquo;an Hadits, Fiqih, Aqidah Akhlaq, Bahasa&nbsp;Arab, dan Sejarah Kebudayaan Islam. Untuk muatan lokal adalah TIK, NU,&nbsp;Bahasa Jawa dan Bahasa Inggris. Sedangkan kegiatan ekstrakurikulernya adalah&nbsp;Pramuka, dan Pencak silat.&nbsp;</p>\r\n', '2016-05-15', '02:46:31', 'Admin', 'sejarah_singkat'),
(2, 'Visi dan Misi MI Al-Huda Karangnongko', '<p><strong><em>VISI&nbsp;</em>Sekolah</strong></p>\r\n\r\n<p>Terwujudnya peserta didik yang beriman dan bertaqwa, cerdas, terampil, mandiri, berakhlak mulia dan berbudaya.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong><em>MISI </em></strong><strong>Sekolah</strong></p>\r\n\r\n<ol>\r\n	<li>Melaksanakan pembelajaran agama islam untuk meningkatkan keimanan dan ketaqwaan terhadap Allah SWT</li>\r\n	<li>Mengembangkan praktek ibadah</li>\r\n	<li>Melaksanakan pembelajaran yang menyenangkan, efektif dan efisien</li>\r\n	<li>Melaksanakan pembelajaran ekstrakulikuler untuk membina bakat dan minat siswa</li>\r\n	<li>Melaksanakan pembiasaan akhlakul karimah</li>\r\n	<li>Mengembangkan kemandirian dan budaya lingkungan setempat</li>\r\n	<li>Mengembangkan rasa cinta dan melestarikan lingkungan hidup</li>\r\n</ol>\r\n\r\n<p><strong>Tujuan MI Al Huda Karangnongko</strong></p>\r\n\r\n<ol>\r\n	<li>Mewujudkan peserta didik yang memiliki iman dan ketaqwaan yang tinggi kepada Allah SWT</li>\r\n	<li>Mencapai prestasi akademik dan non akademik yang tinggi</li>\r\n	<li>Mewujudkan peserta didik yang memiliki ketrampilan yang tinggi</li>\r\n	<li>Membentuk pribadi yang berakhlak mulia</li>\r\n	<li>Mencetak generasi yang terampil dan mandiri</li>\r\n	<li>Mencetak generasi yang mengembangkan budaya dan perduli terhadap lingkungan.</li>\r\n</ol>\r\n', '2016-05-09', '04:06:53', 'Admin', 'visi_misi'),
(3, 'Sarana dan Prasarana MI Al-Huda Karangnongko', '<p>Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum.</p>\r\n', '2016-04-15', '04:22:42', 'Admin', 'sarana'),
(4, 'Program Kerja MI Al-Huda Karangnongko', '<p>Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum. Mauris tempus lorem nec ex facilisis suscipit. Phasellus pretium rutrum augue, eu rutrum lacus lobortis rutrum. Etiam a sem et velit sollicitudin placerat. Maecenas tincidunt justo ligula, sit amet maximus dolor iaculis quis. Sed laoreet cursus posuere. Pellentesque commodo odio in luctus interdum.</p>\r\n', '2016-04-15', '04:22:56', 'Admin', 'proker');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jadwal_pelajaran`
--

CREATE TABLE IF NOT EXISTS `tbl_jadwal_pelajaran` (
`id_jdwl` int(3) NOT NULL,
  `id_mapel` varchar(5) NOT NULL,
  `id_guru` varchar(8) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `hari` varchar(6) NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `status_jadwal` varchar(8) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `tbl_jadwal_pelajaran`
--

INSERT INTO `tbl_jadwal_pelajaran` (`id_jdwl`, `id_mapel`, `id_guru`, `id_kelas`, `hari`, `jam_mulai`, `jam_selesai`, `status_jadwal`) VALUES
(4, 'BI', '20160002', '1A', '2', '07:00:00', '07:45:00', 'Pokok'),
(9, 'FQ', '20160014', '1B', '1', '07:00:00', '07:45:00', 'Pokok'),
(10, 'PJO', '20160015', '2A', '1', '07:00:00', '07:45:00', 'Pokok'),
(11, 'NU', '20160004', '2B', '1', '07:00:00', '07:45:00', 'Pokok'),
(12, 'IPA', '20160002', '1B', '2', '07:45:00', '08:45:00', 'Pokok'),
(14, 'PEUP', '20160010', '4A', '1', '07:00:00', '07:50:00', 'Tambahan'),
(15, 'MTK', '20160010', '4A', '1', '07:50:00', '09:00:00', 'Pokok'),
(16, 'IPS', '20160010', '4A', '1', '09:15:00', '11:00:00', 'Pokok'),
(17, 'KOM', '20160017', '4A', '1', '11:15:00', '12:25:00', 'Pokok'),
(18, '', '20160010', '4A', '2', '07:15:00', '08:25:00', 'Pokok'),
(19, 'PJO', '20160015', '4A', '2', '08:25:00', '09:50:00', 'Pokok'),
(20, 'BI', '20160010', '4A', '2', '09:50:00', '11:00:00', 'Pokok'),
(21, 'BJ', '20160010', '4A', '2', '11:15:00', '12:25:00', 'Pokok'),
(22, 'MTK', '20160010', '4A', '3', '07:15:00', '08:25:00', 'Pokok'),
(23, 'FQ', '20160010', '4A', '3', '08:25:00', '09:50:00', 'Pokok'),
(24, 'BI', '20160010', '4A', '3', '09:50:00', '11:00:00', 'Pokok'),
(25, 'AA', '20160010', '4A', '3', '11:15:00', '12:25:00', 'Pokok'),
(26, 'BI', '20160010', '4A', '4', '07:15:00', '08:25:00', 'Pokok'),
(27, 'MTK', '20160010', '4A', '4', '08:25:00', '09:50:00', 'Pokok'),
(28, 'IPA', '20160010', '4A', '4', '09:50:00', '11:00:00', 'Pokok'),
(29, 'NU', '20160010', '4A', '4', '11:50:00', '12:25:00', 'Pokok'),
(30, 'QH', '20160010', '4A', '5', '08:25:00', '09:00:00', 'Pokok'),
(31, 'BA', '20160010', '4A', '5', '09:50:00', '11:00:00', 'Pokok'),
(32, 'IPA', '20160010', '4A', '6', '07:15:00', '08:25:00', 'Pokok'),
(33, 'SBK', '20160010', '4A', '6', '08:25:00', '09:50:00', 'Pokok'),
(34, 'PKN', '20160010', '4A', '6', '09:50:00', '11:00:00', 'Pokok'),
(35, 'SKI', '20160010', '4A', '6', '10:00:00', '11:00:00', 'Pokok'),
(36, 'PEUP', '20160006', '1A', '1', '07:00:00', '07:50:00', 'Tambahan'),
(37, 'BI', '20160006', '1A', '1', '07:50:00', '09:00:00', 'Pokok'),
(38, 'KOM', '20160017', '1A', '1', '09:15:00', '09:50:00', 'Pokok'),
(39, 'AA', '20160006', '1A', '1', '10:25:00', '11:50:00', 'Pokok'),
(40, 'PJO', '20160014', '1A', '2', '07:15:00', '08:25:00', 'Pokok'),
(41, 'BI', '20160006', '1A', '2', '08:25:00', '09:50:00', 'Pokok'),
(42, 'MTK', '20160006', '1A', '2', '09:50:00', '11:50:00', 'Pokok'),
(43, 'MTK', '20160006', '1A', '3', '07:15:00', '08:25:00', 'Pokok'),
(44, 'BA', '20160006', '1A', '3', '08:25:00', '09:50:00', 'Pokok'),
(45, 'PKN', '20160006', '1A', '3', '09:50:00', '11:00:00', 'Pokok'),
(46, 'BI', '20160006', '1A', '4', '07:15:00', '08:25:00', 'Pokok'),
(47, 'FQ', '20160006', '1A', '4', '08:25:00', '09:50:00', 'Pokok'),
(48, 'SBK', '20160006', '1A', '4', '09:50:00', '11:00:00', 'Pokok'),
(49, 'IPA', '20160006', '1A', '5', '07:15:00', '08:25:00', 'Pokok'),
(50, 'QH', '20160006', '1A', '5', '08:25:00', '09:50:00', 'Pokok'),
(51, 'BJ', '20160006', '1A', '5', '09:50:00', '11:00:00', 'Pokok'),
(52, 'PCS', '20160006', '1A', '6', '07:15:00', '08:25:00', 'Tambahan'),
(53, 'IPS', '20160006', '1A', '6', '08:25:00', '09:50:00', 'Pokok'),
(54, 'EKT', '20160006', '1A', '6', '09:50:00', '11:00:00', 'Tambahan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kehadiran`
--

CREATE TABLE IF NOT EXISTS `tbl_kehadiran` (
`id` int(4) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `ijin` int(2) NOT NULL,
  `sakit` int(2) NOT NULL,
  `alpha` int(2) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_kehadiran`
--

INSERT INTO `tbl_kehadiran` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `thn_ajaran`, `semester`, `ijin`, `sakit`, `alpha`) VALUES
(1, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 1, 3, 0),
(2, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 1, 1, 1),
(3, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 0, 0, 0),
(4, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 0, 0, 2),
(5, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 0, 0, 2),
(6, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 1, 2, 3),
(7, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 0, 0, 2),
(8, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kelas`
--

CREATE TABLE IF NOT EXISTS `tbl_kelas` (
  `id_kelas` varchar(2) NOT NULL,
  `nama_kelas` varchar(5) NOT NULL,
  `wali_kelas` varchar(8) NOT NULL,
  `jumlah_siswa` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kelas`
--

INSERT INTO `tbl_kelas` (`id_kelas`, `nama_kelas`, `wali_kelas`, `jumlah_siswa`) VALUES
('1A', 'I A', '20160006', 25),
('1B', 'I B', '20160012', 22),
('2A', 'II A', '20160018', 30),
('2B', 'II B', '20160002', 31),
('3A', 'III A', '20160003', 23),
('3B', 'III B', '20160009', 25),
('4A', 'IV A', '20160010', 19),
('4B', 'IV B', '20160005', 20),
('5A', 'V A', '20160008', 19),
('5B', 'V B', '20160011', 19),
('6A', 'VI A', '20160004', 16),
('6B', 'VI B', '20160007', 18);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kenaikan_kls`
--

CREATE TABLE IF NOT EXISTS `tbl_kenaikan_kls` (
`id` int(4) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `naik_kelas` int(1) NOT NULL,
  `ket_huruf_kls` varchar(5) NOT NULL,
  `keterangan` varchar(13) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tbl_kenaikan_kls`
--

INSERT INTO `tbl_kenaikan_kls` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `thn_ajaran`, `semester`, `naik_kelas`, `ket_huruf_kls`, `keterangan`) VALUES
(1, '12346', '1B', '20160003', '2015/2016', 'Genap', 2, 'Dua', 'Naik Kelas'),
(4, '111234040012141187', '2B', '20160005', '2015/2016', 'Genap', 4, 'Empat', 'Naik Kelas'),
(5, '111234040012141188', '2B', '20160005', '2015/2016', 'Genap', 3, 'Tiga', 'Naik Kelas'),
(7, '111234040012141189', '2B', '20160005', '2015/2016', 'Genap', 5, 'Lima', 'Naik Kelas'),
(8, '111234040012141189', '2B', '20160005', '2015/2016', 'Genap', 5, 'Lima', 'Naik Kelas'),
(9, '111234040012141190', '2B', '20160005', '2015/2016', 'Genap', 3, 'Tiga', 'Naik Kelas'),
(10, '111234040012141189', '2B', '20160005', '2015/2016', 'Genap', 5, 'Lima', 'Naik Kelas'),
(12, '111234040012141191', '2B', '20160005', '2015/2016', 'Genap', 3, ' Tiga', 'Naik Kelas'),
(13, '111234040012141191', '2B', '20160005', '2015/2016', 'Genap', 3, ' Tiga', 'Naik Kelas'),
(14, '111234040012141192', '2B', '20160005', '2015/2016', 'Genap', 3, ' Tiga', 'Naik Kelas'),
(20, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 5, ' Lima', 'Naik Kelas'),
(21, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 5, ' Lima', 'Naik Kelas'),
(22, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 5, ' Lima', 'Naik Kelas');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kepribadian`
--

CREATE TABLE IF NOT EXISTS `tbl_kepribadian` (
`id_kepribadian` int(2) NOT NULL,
  `nama_kepribadian` varchar(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbl_kepribadian`
--

INSERT INTO `tbl_kepribadian` (`id_kepribadian`, `nama_kepribadian`) VALUES
(1, 'Religius'),
(2, 'Kejujuran'),
(3, 'Toleransi'),
(4, 'Disiplin'),
(5, 'Kerja Keras'),
(6, 'Kreativitas'),
(7, 'Kemandirian'),
(8, 'Demokratis'),
(9, 'Rasa Ingin Tahu'),
(10, 'Semangat Kebangsaan'),
(11, 'Cinta Tanah Air'),
(12, 'Menghargai Prestasi'),
(13, 'Komunikatif'),
(14, 'Cinta Damai'),
(15, 'Senang Membaca'),
(16, 'Peduli Lingkungan'),
(17, 'Perduli Sosial'),
(18, 'Tanggung Jawab');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_komentar`
--

CREATE TABLE IF NOT EXISTS `tbl_komentar` (
`id_komentar` int(5) NOT NULL,
  `id_artikel` int(4) NOT NULL,
  `nama_komentar` varchar(30) NOT NULL,
  `email_komentar` varchar(25) NOT NULL,
  `komentar` text NOT NULL,
  `tgl_komentar` date NOT NULL,
  `jam_komentar` time NOT NULL,
  `keterangan` varchar(10) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `tbl_komentar`
--

INSERT INTO `tbl_komentar` (`id_komentar`, `id_artikel`, `nama_komentar`, `email_komentar`, `komentar`, `tgl_komentar`, `jam_komentar`, `keterangan`) VALUES
(7, 6, 'Andi Kurniawan', 'abcdef@gmail.com', 'Liburnya tanggal berapa sampai tanggal berapa ?', '2016-03-17', '08:36:14', 'pengumuman'),
(8, 6, 'Ahmah Maulana', 'sulis@gmail.com', 'yuhuyy liburrr :v', '2016-03-17', '13:23:13', 'pengumuman'),
(9, 6, 'Susi Sulistyowati', 'ss457@yahoo.com', 'Test Komentar', '2016-03-17', '12:20:21', 'pengumuman'),
(12, 1, 'Ana Farenka', 'farenkana432@gmail.com', 'Coba komentar', '2016-03-18', '08:14:06', 'pengumuman'),
(13, 1, 'Andi Kurniawan', 'akur@gmail.com', 'Juga coba komentar :v', '2016-03-18', '08:15:07', 'pengumuman'),
(14, 4, 'Ahmah Maulana', 'abcdef@gmail.com', 'Bawa alat apa saja ?', '2016-03-18', '08:43:56', 'pengumuman'),
(15, 7, 'Doni Setyawan', 'doni90@gmail.com', 'Coba komen Agenda Coba 2', '2016-03-19', '02:42:18', 'agenda'),
(16, 11, 'Putri', 'putput@yahoo.co.id', 'Komen Coba Berita 1', '2016-03-19', '02:46:47', 'berita'),
(17, 3, 'Sandi Kurniawan', 'sanzan@yahoo.com', 'Joss !!!', '2016-03-20', '01:31:20', 'pengumuman'),
(18, 1, 'Ahmah Maulana', 'maulana@yahoo.com', 'Pengumuman yang sangat bermanfaat', '2016-04-09', '10:21:15', 'pengumuman'),
(19, 14, 'Ana Farenka', 'farenkana432@gmail.com', 'Juoooosssss !!', '2016-04-09', '10:41:57', 'prestasi'),
(20, 4, 'Andi Kurniawan', 'akur@gmail.com', 'Kapan ', '2016-05-09', '04:09:10', 'pengumuman'),
(21, 16, 'Ahmah Maulana', 'mamad@gmail.com', 'siap hadir', '2016-05-15', '03:05:22', 'pengumuman');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mapel`
--

CREATE TABLE IF NOT EXISTS `tbl_mapel` (
  `id_mapel` varchar(5) NOT NULL,
  `nama_mapel` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_mapel`
--

INSERT INTO `tbl_mapel` (`id_mapel`, `nama_mapel`) VALUES
('AA', 'Akidah Akhlak'),
('BA', 'Bahasa Arab'),
('BI', 'Bahasa Indonesia'),
('BJ', 'Bahasa Jawa'),
('EKT', 'Ekstrakulikuler'),
('FQ', 'Fiqih'),
('IPA', 'Ilmu Pengetahuan Alam'),
('IPS', 'Ilmu Pengetahuan Sosial'),
('KOM', 'Komputer'),
('MTK', 'Matematika'),
('NU', 'Ke-NU-an / Aswaja'),
('PCS', 'Pencak Silat'),
('PEUP', 'Persiapan & Upacara'),
('PJO', 'Pendidikan Jasmani dan Orkes'),
('PKN', 'Pendidikan Kewarganegaraan'),
('QH', 'Qur''an Hadis'),
('SBK', 'Seni Budaya dan Ketrampilan'),
('SKI', 'Sejarah Kebudayaan Islam');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai_kepribadian`
--

CREATE TABLE IF NOT EXISTS `tbl_nilai_kepribadian` (
`id` int(11) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `id_kepribadian` int(2) NOT NULL,
  `nilai_kepribadian` int(3) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=631 ;

--
-- Dumping data for table `tbl_nilai_kepribadian`
--

INSERT INTO `tbl_nilai_kepribadian` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `thn_ajaran`, `semester`, `id_kepribadian`, `nilai_kepribadian`) VALUES
(1, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80),
(2, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(3, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(4, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(5, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(6, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(7, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(8, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(9, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(10, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(11, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(12, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(13, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(14, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(15, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(16, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(17, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(18, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 18, 75),
(37, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(38, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(39, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 3, 70),
(40, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 4, 70),
(41, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 5, 70),
(42, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 6, 70),
(43, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 7, 70),
(44, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 8, 70),
(45, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 9, 70),
(46, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 10, 70),
(47, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 11, 70),
(48, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 12, 70),
(49, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 13, 70),
(50, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 14, 70),
(51, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 15, 70),
(52, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 16, 70),
(53, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 17, 70),
(54, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 18, 70),
(55, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80),
(56, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(57, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(58, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(59, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(60, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(61, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(62, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(63, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(64, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(65, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(66, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(67, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(68, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(69, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(70, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(71, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(72, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 18, 80),
(73, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80),
(74, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(75, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(76, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(77, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 5, 75),
(78, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 6, 75),
(79, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 7, 75),
(80, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 8, 75),
(81, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 9, 75),
(82, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 10, 75),
(83, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 11, 75),
(84, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 12, 75),
(85, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 13, 75),
(86, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 14, 75),
(87, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(88, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(89, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(90, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 18, 80),
(91, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(92, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 2, 90),
(93, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 3, 90),
(94, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(95, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(96, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(97, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(98, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(99, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(100, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(101, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(102, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(103, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(104, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(105, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(106, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(107, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(108, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 18, 80),
(109, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(110, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 2, 90),
(111, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(112, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 4, 70),
(113, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 5, 78),
(114, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(115, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(116, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(117, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(118, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(119, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(120, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(121, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(122, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(123, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(124, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(125, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(126, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 18, 75),
(127, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(128, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 2, 90),
(129, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(130, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(131, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(132, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(133, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(134, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(135, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(136, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(137, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(138, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(139, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(140, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(141, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(142, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(143, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(144, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 18, 80),
(145, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(146, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 2, 90),
(147, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 3, 90),
(148, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 4, 90),
(149, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 5, 90),
(150, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(151, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 7, 90),
(152, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 8, 90),
(153, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 9, 90),
(154, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 10, 90),
(155, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(156, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(157, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(158, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(159, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(160, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(161, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 17, 90),
(162, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 18, 90),
(163, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(164, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 2, 90),
(165, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(166, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(167, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(168, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(169, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(170, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(171, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(172, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(173, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(174, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(175, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(176, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(177, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(178, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(179, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(180, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 18, 80),
(181, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(182, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 2, 90),
(183, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 3, 70),
(184, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(185, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(186, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(187, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(188, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(189, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(190, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(191, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(192, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(193, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(194, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(195, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(196, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(197, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(198, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 18, 90),
(199, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(200, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(201, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(202, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 4, 75),
(203, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(204, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(205, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(206, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(207, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(208, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(209, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(210, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(211, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(212, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(213, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(214, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(215, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(216, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 18, 75),
(217, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(218, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 2, 90),
(219, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 3, 90),
(220, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 4, 90),
(221, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 5, 90),
(222, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(223, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(224, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(225, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(226, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(227, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(228, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(229, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(230, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(231, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 15, 90),
(232, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(233, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 17, 90),
(234, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 18, 90),
(235, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(236, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(237, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(238, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 4, 55),
(239, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 5, 78),
(240, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 6, 67),
(241, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 7, 75),
(242, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(243, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(244, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(245, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(246, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(247, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(248, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(249, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(250, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(251, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(252, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 18, 60),
(253, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(254, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 2, 90),
(255, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 3, 75),
(256, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 4, 78),
(257, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(258, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(259, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(260, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(261, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(262, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(263, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(264, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(265, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(266, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(267, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(268, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(269, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(270, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 18, 80),
(271, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80),
(272, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(273, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(274, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(275, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(276, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(277, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(278, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(279, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(280, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(281, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(282, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(283, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(284, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(285, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(286, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(287, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(288, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 18, 65),
(289, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(290, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 2, 90),
(291, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(292, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(293, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(294, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(295, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(296, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(297, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(298, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(299, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(300, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(301, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(302, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(303, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(304, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(305, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(306, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 18, 80),
(307, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80),
(308, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(309, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(310, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 4, 65),
(311, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 5, 65),
(312, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 6, 70),
(313, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(314, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(315, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(316, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 10, 70),
(317, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(318, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(319, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(320, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(321, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(322, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(323, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(324, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 18, 65),
(325, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80),
(326, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(327, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(328, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(329, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(330, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(331, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(332, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(333, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(334, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(335, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(336, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(337, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(338, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(339, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(340, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(341, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(342, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 18, 65),
(343, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(344, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(345, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(346, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 4, 80),
(347, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(348, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(349, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(350, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(351, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(352, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(353, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(354, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(355, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(356, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(357, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(358, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(359, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(360, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 18, 80),
(361, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 1, 90),
(362, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 2, 90),
(363, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 3, 90),
(364, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 4, 80),
(365, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(366, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(367, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(368, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(369, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(370, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(371, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(372, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(373, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(374, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(375, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(376, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(377, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(378, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 18, 80),
(379, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(380, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(381, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(382, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 4, 80),
(383, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(384, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(385, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(386, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(387, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(388, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(389, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(390, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(391, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(392, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(393, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(394, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(395, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(396, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 18, 80),
(397, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(398, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(399, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(400, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 4, 65),
(401, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(402, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(403, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(404, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(405, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(406, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(407, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(408, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(409, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(410, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(411, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(412, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(413, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(414, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 18, 80),
(415, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(416, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(417, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(418, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 4, 65),
(419, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(420, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(421, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(422, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(423, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(424, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(425, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(426, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(427, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(428, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(429, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 15, 65),
(430, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(431, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(432, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 18, 65),
(433, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(434, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(435, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(436, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 4, 80),
(437, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(438, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(439, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(440, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(441, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(442, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(443, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(444, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(445, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(446, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(447, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(448, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(449, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(450, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 18, 80),
(451, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(452, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(453, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(454, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 4, 55),
(455, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(456, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(457, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(458, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(459, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(460, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(461, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(462, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(463, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(464, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(465, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(466, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(467, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(468, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 18, 55),
(469, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 1, 90),
(470, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 2, 90),
(471, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 3, 90),
(472, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 4, 90),
(473, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 5, 90),
(474, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(475, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(476, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(477, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(478, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(479, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(480, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(481, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(482, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(483, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(484, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(485, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 17, 90),
(486, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 18, 90),
(487, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(488, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(489, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(490, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 4, 80),
(491, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(492, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(493, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(494, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(495, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(496, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(497, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(498, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(499, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(500, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(501, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(502, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(503, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(504, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 18, 80),
(505, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 1, 78),
(506, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(507, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(508, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 4, 57),
(509, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 5, 70),
(510, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(511, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(512, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(513, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(514, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(515, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(516, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(517, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(518, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(519, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(520, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(521, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(522, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 18, 55),
(523, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(524, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 2, 90),
(525, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(526, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 4, 55),
(527, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(528, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(529, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(530, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(531, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(532, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(533, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(534, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(535, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(536, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(537, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(538, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(539, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(540, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 18, 60),
(541, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 1, 78),
(542, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 2, 67),
(543, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(544, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 4, 55),
(545, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 5, 77),
(546, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(547, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(548, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(549, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(550, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(551, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(552, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(553, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(554, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(555, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(556, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(557, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(558, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 18, 65),
(559, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(560, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(561, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(562, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 4, 80),
(563, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(564, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(565, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(566, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(567, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(568, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(569, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(570, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(571, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(572, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(573, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(574, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(575, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(576, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 18, 65),
(577, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(578, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(579, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(580, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 4, 80),
(581, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(582, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(583, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(584, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(585, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(586, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(587, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(588, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(589, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(590, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(591, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(592, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(593, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(594, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 18, 80),
(595, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 1, 80),
(596, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 2, 80),
(597, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(598, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 4, 80),
(599, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 5, 80),
(600, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 6, 80),
(601, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(602, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 8, 80),
(603, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(604, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 10, 80),
(605, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 11, 80),
(606, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 12, 80),
(607, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 13, 80),
(608, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 14, 80),
(609, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 15, 80),
(610, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 16, 80),
(611, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 17, 80),
(612, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 18, 80),
(613, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80),
(614, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(615, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(616, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(617, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(618, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(619, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 7, 80),
(620, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(621, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(622, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(623, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(624, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(625, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(626, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(627, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(628, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(629, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(630, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 18, 80);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai_pembiasaan`
--

CREATE TABLE IF NOT EXISTS `tbl_nilai_pembiasaan` (
`id` int(11) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `id_pembiasaan` int(2) NOT NULL,
  `nilai` int(3) NOT NULL,
  `nilai_huruf` varchar(25) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=249 ;

--
-- Dumping data for table `tbl_nilai_pembiasaan`
--

INSERT INTO `tbl_nilai_pembiasaan` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `thn_ajaran`, `semester`, `id_pembiasaan`, `nilai`, `nilai_huruf`) VALUES
(9, '12346', '1B', '20160003', '2015/2016', 'Ganjil', 1, 81, 'Delapan Puluh Satu'),
(10, '12346', '1B', '20160003', '2015/2016', 'Ganjil', 2, 80, 'Delapan Puluh '),
(11, '12346', '1B', '20160003', '2015/2016', 'Ganjil', 3, 80, 'Delapan Puluh '),
(12, '12346', '1B', '20160003', '2015/2016', 'Ganjil', 4, 80, 'Delapan Puluh '),
(17, '12346', '1B', '20160003', '2015/2016', 'Genap', 1, 81, 'Delapan Puluh Satu'),
(18, '12346', '1B', '20160003', '2015/2016', 'Genap', 2, 80, 'Delapan Puluh '),
(19, '12346', '1B', '20160003', '2015/2016', 'Genap', 3, 80, 'Delapan Puluh '),
(20, '12346', '1B', '20160003', '2015/2016', 'Genap', 4, 80, 'Delapan Puluh '),
(69, '111234040012141187', '2B', '20160005', '2015/2016', 'Ganjil', 1, 80, 'Delapan Puluh '),
(70, '111234040012141187', '2B', '20160005', '2015/2016', 'Ganjil', 2, 80, 'Delapan Puluh '),
(71, '111234040012141187', '2B', '20160005', '2015/2016', 'Ganjil', 3, 80, 'Delapan Puluh '),
(72, '111234040012141187', '2B', '20160005', '2015/2016', 'Ganjil', 4, 80, 'Delapan Puluh '),
(77, '111234040012141187', '2B', '20160005', '2015/2016', 'Genap', 1, 80, 'Delapan Puluh '),
(78, '111234040012141187', '2B', '20160005', '2015/2016', 'Genap', 2, 80, 'Delapan Puluh '),
(79, '111234040012141187', '2B', '20160005', '2015/2016', 'Genap', 3, 80, 'Delapan Puluh '),
(80, '111234040012141187', '2B', '20160005', '2015/2016', 'Genap', 4, 80, 'Delapan Puluh '),
(81, '111234040012141188', '2B', '20160005', '2015/2016', 'Genap', 1, 85, 'Delapan Puluh Lima'),
(82, '111234040012141188', '2B', '20160005', '2015/2016', 'Genap', 2, 85, 'Delapan Puluh Lima'),
(83, '111234040012141188', '2B', '20160005', '2015/2016', 'Genap', 3, 85, 'Delapan Puluh Lima'),
(84, '111234040012141188', '2B', '20160005', '2015/2016', 'Genap', 4, 80, 'Delapan Puluh '),
(101, '111234040012141189', '2B', '20160005', '2015/2016', 'Ganjil', 1, 75, 'Tujuh Puluh Lima'),
(102, '111234040012141189', '2B', '20160005', '2015/2016', 'Ganjil', 2, 70, 'Tujuh Puluh '),
(103, '111234040012141189', '2B', '20160005', '2015/2016', 'Ganjil', 3, 70, 'Tujuh Puluh '),
(104, '111234040012141189', '2B', '20160005', '2015/2016', 'Ganjil', 4, 70, 'Tujuh Puluh '),
(117, '111234040012141189', '2B', '20160005', '2015/2016', 'Genap', 1, 80, 'Delapan Puluh '),
(118, '111234040012141189', '2B', '20160005', '2015/2016', 'Genap', 2, 80, 'Delapan Puluh '),
(119, '111234040012141189', '2B', '20160005', '2015/2016', 'Genap', 3, 85, 'Delapan Puluh Lima'),
(120, '111234040012141189', '2B', '20160005', '2015/2016', 'Genap', 4, 85, 'Delapan Puluh Lima'),
(153, '111234040012141190', '2B', '20160005', '2015/2016', 'Ganjil', 1, 90, ' Sembilan Puluh  '),
(154, '111234040012141190', '2B', '20160005', '2015/2016', 'Ganjil', 2, 90, ' Sembilan Puluh  '),
(155, '111234040012141190', '2B', '20160005', '2015/2016', 'Ganjil', 3, 80, ' Delapan Puluh  '),
(156, '111234040012141190', '2B', '20160005', '2015/2016', 'Ganjil', 4, 80, ' Delapan Puluh  '),
(157, '111234040012141191', '2B', '20160005', '2015/2016', 'Ganjil', 1, 80, ' Delapan Puluh  '),
(158, '111234040012141191', '2B', '20160005', '2015/2016', 'Ganjil', 2, 80, ' Delapan Puluh  '),
(159, '111234040012141191', '2B', '20160005', '2015/2016', 'Ganjil', 3, 80, ' Delapan Puluh  '),
(160, '111234040012141191', '2B', '20160005', '2015/2016', 'Ganjil', 4, 80, ' Delapan Puluh  '),
(165, '111234040012141192', '2B', '20160005', '2015/2016', 'Ganjil', 1, 80, ' Delapan Puluh  '),
(166, '111234040012141192', '2B', '20160005', '2015/2016', 'Ganjil', 2, 80, ' Delapan Puluh  '),
(167, '111234040012141192', '2B', '20160005', '2015/2016', 'Ganjil', 3, 80, ' Delapan Puluh  '),
(168, '111234040012141192', '2B', '20160005', '2015/2016', 'Ganjil', 4, 80, ' Delapan Puluh  '),
(169, '111234040012141191', '2B', '20160005', '2015/2016', 'Genap', 1, 80, ' Delapan Puluh  '),
(170, '111234040012141191', '2B', '20160005', '2015/2016', 'Genap', 2, 80, ' Delapan Puluh  '),
(171, '111234040012141191', '2B', '20160005', '2015/2016', 'Genap', 3, 80, ' Delapan Puluh  '),
(172, '111234040012141191', '2B', '20160005', '2015/2016', 'Genap', 4, 0, ' '),
(173, '111234040012141192', '2B', '20160005', '2015/2016', 'Genap', 1, 80, ' Delapan Puluh  '),
(174, '111234040012141192', '2B', '20160005', '2015/2016', 'Genap', 2, 80, ' Delapan Puluh  '),
(175, '111234040012141192', '2B', '20160005', '2015/2016', 'Genap', 3, 80, ' Delapan Puluh  '),
(176, '111234040012141192', '2B', '20160005', '2015/2016', 'Genap', 4, 80, ' Delapan Puluh  '),
(217, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80, 'Delapan Puluh '),
(218, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80, 'Delapan Puluh '),
(219, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80, 'Delapan Puluh '),
(220, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80, 'Delapan Puluh '),
(221, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 1, 79, 'Tujuh Puluh Sembilan'),
(222, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80, 'Delapan Puluh '),
(223, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80, 'Delapan Puluh '),
(224, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80, 'Delapan Puluh '),
(225, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 1, 79, 'Tujuh Puluh Sembilan'),
(226, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 2, 80, 'Delapan Puluh '),
(227, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 3, 85, 'Delapan Puluh Lima'),
(228, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 4, 85, 'Delapan Puluh Lima'),
(229, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80, ' Delapan Puluh  '),
(230, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80, ' Delapan Puluh  '),
(231, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 3, 75, ' Tujuh Puluh  Lima'),
(232, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 4, 75, ' Tujuh Puluh  Lima'),
(233, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80, ' Delapan Puluh  '),
(234, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80, ' Delapan Puluh  '),
(235, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80, ' Delapan Puluh  '),
(236, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80, ' Delapan Puluh  '),
(237, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90, ' Sembilan Puluh  '),
(238, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 2, 90, ' Sembilan Puluh  '),
(239, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80, ' Delapan Puluh  '),
(240, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80, ' Delapan Puluh  '),
(241, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 1, 80, ' Delapan Puluh  '),
(242, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 2, 80, ' Delapan Puluh  '),
(243, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 3, 80, ' Delapan Puluh  '),
(244, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 4, 80, ' Delapan Puluh  '),
(245, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 1, 90, ' Sembilan Puluh  '),
(246, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 2, 90, ' Sembilan Puluh  '),
(247, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 3, 80, ' Delapan Puluh  '),
(248, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 4, 80, ' Delapan Puluh  ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai_pengembangan_diri`
--

CREATE TABLE IF NOT EXISTS `tbl_nilai_pengembangan_diri` (
`id` int(11) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `id_guru` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `id_ekstra` int(2) NOT NULL,
  `nilai` int(3) NOT NULL,
  `nilai_huruf` varchar(25) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=311 ;

--
-- Dumping data for table `tbl_nilai_pengembangan_diri`
--

INSERT INTO `tbl_nilai_pengembangan_diri` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `id_guru`, `thn_ajaran`, `semester`, `id_ekstra`, `nilai`, `nilai_huruf`) VALUES
(11, '12346', '1B', '20160003', '20160002', '2015/2016', 'Ganjil', 1, 87, 'Delapan Puluh Tujuh'),
(12, '12346', '1B', '20160003', '20160002', '2015/2016', 'Ganjil', 2, 83, 'Delapan Puluh Tiga'),
(13, '12346', '1B', '20160003', '20160002', '2015/2016', 'Ganjil', 3, 84, 'Delapan Puluh Empat'),
(14, '12346', '1B', '20160003', '20160002', '2015/2016', 'Ganjil', 4, 85, 'Delapan Puluh Lima'),
(15, '12346', '1B', '20160003', '20160002', '2015/2016', 'Ganjil', 5, 86, 'Delapan Puluh Enam'),
(21, '12346', '1B', '20160003', '20160002', '2015/2016', 'Genap', 1, 83, 'Delapan Puluh Tiga'),
(22, '12346', '1B', '20160003', '20160002', '2015/2016', 'Genap', 2, 81, 'Delapan Puluh Satu'),
(23, '12346', '1B', '20160003', '20160002', '2015/2016', 'Genap', 3, 81, 'Delapan Puluh Satu'),
(24, '12346', '1B', '20160003', '20160002', '2015/2016', 'Genap', 4, 81, 'Delapan Puluh Satu'),
(25, '12346', '1B', '20160003', '20160002', '2015/2016', 'Genap', 5, 81, 'Delapan Puluh Satu'),
(86, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 1, 80, 'Delapan Puluh '),
(87, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 2, 80, 'Delapan Puluh '),
(88, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 3, 80, 'Delapan Puluh '),
(89, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 4, 80, 'Delapan Puluh '),
(90, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 5, 80, 'Delapan Puluh '),
(96, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Genap', 1, 85, 'Delapan Puluh Lima'),
(97, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Genap', 2, 0, ''),
(98, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Genap', 3, 80, 'Delapan Puluh '),
(99, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Genap', 4, 90, 'Sembilan Puluh '),
(100, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Genap', 5, 0, ''),
(101, '111234040012141188', '2B', '20160005', '20160004', '2015/2016', 'Genap', 1, 80, 'Delapan Puluh '),
(102, '111234040012141188', '2B', '20160005', '20160004', '2015/2016', 'Genap', 2, 80, 'Delapan Puluh '),
(103, '111234040012141188', '2B', '20160005', '20160004', '2015/2016', 'Genap', 3, 80, 'Delapan Puluh '),
(104, '111234040012141188', '2B', '20160005', '20160004', '2015/2016', 'Genap', 4, 80, 'Delapan Puluh '),
(105, '111234040012141188', '2B', '20160005', '20160004', '2015/2016', 'Genap', 5, 0, ''),
(126, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 1, 80, 'Delapan Puluh '),
(127, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 2, 80, 'Delapan Puluh '),
(128, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 3, 80, 'Delapan Puluh '),
(129, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 4, 80, 'Delapan Puluh '),
(130, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 5, 80, 'Delapan Puluh '),
(146, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Genap', 1, 80, 'Delapan Puluh '),
(147, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Genap', 2, 0, ''),
(148, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Genap', 3, 85, 'Delapan Puluh Lima'),
(149, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Genap', 4, 90, 'Sembilan Puluh '),
(150, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Genap', 5, 0, ''),
(191, '111234040012141190', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 1, 80, ' Delapan Puluh  '),
(192, '111234040012141190', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 2, 80, ' Delapan Puluh  '),
(193, '111234040012141190', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 3, 80, ' Delapan Puluh  '),
(194, '111234040012141190', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 4, 80, ' Delapan Puluh  '),
(195, '111234040012141190', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 5, 80, ' Delapan Puluh  '),
(196, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 1, 85, ' Delapan Puluh  Lima'),
(197, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 2, 85, ' Delapan Puluh  Lima'),
(198, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 3, 85, ' Delapan Puluh  Lima'),
(199, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 4, 0, ' '),
(200, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 5, 0, ' '),
(206, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 1, 80, ' Delapan Puluh  '),
(207, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 2, 80, ' Delapan Puluh  '),
(208, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 3, 80, ' Delapan Puluh  '),
(209, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 4, 80, ' Delapan Puluh  '),
(210, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 5, 80, ' Delapan Puluh  '),
(211, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Genap', 1, 80, ' Delapan Puluh  '),
(212, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Genap', 2, 90, ' Sembilan Puluh  '),
(213, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Genap', 3, 80, ' Delapan Puluh  '),
(214, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Genap', 4, 0, ' '),
(215, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Genap', 5, 0, ' '),
(216, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Genap', 1, 90, ' Sembilan Puluh  '),
(217, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Genap', 2, 80, ' Delapan Puluh  '),
(218, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Genap', 3, 88, ' Delapan Puluh  Delapan'),
(219, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Genap', 4, 89, ' Delapan Puluh  Sembilan'),
(220, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Genap', 5, 80, ' Delapan Puluh  '),
(271, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 1, 80, 'Delapan Puluh '),
(272, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 2, 80, 'Delapan Puluh '),
(273, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 3, 0, ''),
(274, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 4, 90, 'Sembilan Puluh '),
(275, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 5, 0, ''),
(276, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 1, 84, 'Delapan Puluh Empat'),
(277, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 2, 0, ''),
(278, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 3, 80, 'Delapan Puluh '),
(279, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 4, 90, 'Sembilan Puluh '),
(280, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 5, 0, ''),
(281, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 1, 79, 'Tujuh Puluh Sembilan'),
(282, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 2, 70, 'Tujuh Puluh '),
(283, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 3, 75, 'Tujuh Puluh Lima'),
(284, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 4, 0, ''),
(285, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 5, 0, ''),
(286, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 1, 80, ' Delapan Puluh  '),
(287, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 2, 0, ' '),
(288, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 3, 80, ' Delapan Puluh  '),
(289, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 4, 80, ' Delapan Puluh  '),
(290, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 5, 0, ' '),
(291, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 1, 80, ' Delapan Puluh  '),
(292, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 2, 80, ' Delapan Puluh  '),
(293, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 3, 0, ' '),
(294, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 4, 80, ' Delapan Puluh  '),
(295, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 5, 0, ' '),
(296, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 1, 80, ' Delapan Puluh  '),
(297, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 2, 0, ' '),
(298, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 3, 80, ' Delapan Puluh  '),
(299, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 4, 90, ' Sembilan Puluh  '),
(300, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 5, 0, ' '),
(301, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 1, 80, ' Delapan Puluh  '),
(302, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 2, 0, ' '),
(303, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 3, 80, ' Delapan Puluh  '),
(304, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 4, 90, ' Sembilan Puluh  '),
(305, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 5, 0, ' '),
(306, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 1, 90, ' Sembilan Puluh  '),
(307, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 2, 0, ' '),
(308, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 3, 90, ' Sembilan Puluh  '),
(309, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 4, 90, ' Sembilan Puluh  '),
(310, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 5, 0, ' ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai_raport`
--

CREATE TABLE IF NOT EXISTS `tbl_nilai_raport` (
`id` int(11) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `id_guru` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `id_mapel` varchar(5) NOT NULL,
  `kkm` int(3) NOT NULL,
  `nilai` int(3) NOT NULL,
  `nilai_huruf` varchar(25) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=259 ;

--
-- Dumping data for table `tbl_nilai_raport`
--

INSERT INTO `tbl_nilai_raport` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `id_guru`, `thn_ajaran`, `semester`, `id_mapel`, `kkm`, `nilai`, `nilai_huruf`) VALUES
(11, '12346', '1B', '20160003', '20160010', '2015/2016', 'Ganjil', 'FQ', 75, 80, 'Delapan Puluh '),
(12, '12346', '1B', '20160003', '20160002', '2015/2016', 'Ganjil', 'IPA', 75, 86, 'Delapan Puluh Enam'),
(15, '12346', '1B', '20160003', '20160010', '2015/2016', 'Genap', 'FQ', 75, 90, 'Sembilan Puluh '),
(16, '12346', '1B', '20160003', '20160002', '2015/2016', 'Genap', 'IPA', 75, 90, 'Sembilan Puluh '),
(36, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 'NU', 75, 85, 'Delapan Puluh Lima'),
(38, '111234040012141187', '2B', '20160005', '20160004', '2015/2016', 'Genap', 'NU', 75, 90, 'Sembilan Puluh '),
(39, '111234040012141188', '2B', '20160005', '20160004', '2015/2016', 'Genap', 'NU', 75, 85, 'Delapan Puluh Lima'),
(52, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 'NU', 75, 80, 'Delapan Puluh '),
(56, '111234040012141189', '2B', '20160005', '20160004', '2015/2016', 'Genap', 'NU', 75, 90, 'Sembilan Puluh '),
(73, '111234040012141190', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 'NU', 75, 90, ' Sembilan Puluh  '),
(74, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 'NU', 75, 80, ' Delapan Puluh  '),
(80, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Ganjil', 'NU', 75, 80, ' Delapan Puluh  '),
(81, '111234040012141191', '2B', '20160005', '20160004', '2015/2016', 'Genap', 'NU', 75, 80, ' Delapan Puluh  '),
(82, '111234040012141192', '2B', '20160005', '20160004', '2015/2016', 'Genap', 'NU', 80, 80, ' Delapan Puluh  '),
(139, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'AA', 75, 78, 'Tujuh Puluh Delapan'),
(140, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BA', 75, 78, 'Tujuh Puluh Delapan'),
(141, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BI', 75, 78, 'Tujuh Puluh Delapan'),
(142, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BJ', 75, 80, 'Delapan Puluh '),
(143, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'FQ', 75, 80, 'Delapan Puluh '),
(144, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'IPA', 75, 80, 'Delapan Puluh '),
(145, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'IPS', 75, 80, 'Delapan Puluh '),
(146, '111234040012121055', '4A', '20160010', '20160018', '2015/2016', 'Ganjil', 'KOM', 75, 80, 'Delapan Puluh '),
(147, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'MTK', 75, 75, 'Tujuh Puluh Lima'),
(148, '111234040012121055', '4A', '20160010', '', '2015/2016', 'Ganjil', 'NU', 75, 75, 'Tujuh Puluh Lima'),
(149, '111234040012121055', '4A', '20160010', '20160015', '2015/2016', 'Ganjil', 'PJO', 75, 75, 'Tujuh Puluh Lima'),
(150, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'PKN', 75, 75, 'Tujuh Puluh Lima'),
(151, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'QH', 75, 75, 'Tujuh Puluh Lima'),
(152, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'SBK', 75, 75, 'Tujuh Puluh Lima'),
(153, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'AA', 75, 79, 'Tujuh Puluh Sembilan'),
(154, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BA', 75, 80, 'Delapan Puluh '),
(155, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BI', 75, 80, 'Delapan Puluh '),
(156, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BJ', 75, 80, 'Delapan Puluh '),
(157, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'FQ', 75, 75, 'Tujuh Puluh Lima'),
(158, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'IPA', 75, 75, 'Tujuh Puluh Lima'),
(159, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'IPS', 75, 75, 'Tujuh Puluh Lima'),
(160, '111234040012111024', '4A', '20160010', '20160018', '2015/2016', 'Ganjil', 'KOM', 75, 75, 'Tujuh Puluh Lima'),
(161, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'MTK', 75, 75, 'Tujuh Puluh Lima'),
(162, '111234040012111024', '4A', '20160010', '', '2015/2016', 'Ganjil', 'NU', 75, 75, 'Tujuh Puluh Lima'),
(163, '111234040012111024', '4A', '20160010', '20160015', '2015/2016', 'Ganjil', 'PJO', 75, 75, 'Tujuh Puluh Lima'),
(164, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'PKN', 75, 75, 'Tujuh Puluh Lima'),
(165, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'QH', 75, 75, 'Tujuh Puluh Lima'),
(166, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'SBK', 75, 75, 'Tujuh Puluh Lima'),
(167, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'SKI', 75, 75, 'Tujuh Puluh Lima'),
(168, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'AA', 70, 76, 'Tujuh Puluh Enam'),
(169, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'BA', 75, 75, 'Tujuh Puluh Lima'),
(170, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'BI', 75, 75, 'Tujuh Puluh Lima'),
(171, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'BJ', 75, 80, 'Delapan Puluh '),
(172, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'FQ', 75, 80, 'Delapan Puluh '),
(173, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'IPA', 75, 80, 'Delapan Puluh '),
(174, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'IPS', 75, 80, 'Delapan Puluh '),
(175, '111234040012111024', '4A', '20160010', '20160018', '2015/2016', 'Genap', 'KOM', 75, 75, 'Tujuh Puluh Lima'),
(176, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'MTK', 70, 75, 'Tujuh Puluh Lima'),
(177, '111234040012111024', '4A', '20160010', '', '2015/2016', 'Genap', 'NU', 75, 80, 'Delapan Puluh '),
(178, '111234040012111024', '4A', '20160010', '20160015', '2015/2016', 'Genap', 'PJO', 75, 80, 'Delapan Puluh '),
(179, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'PKN', 75, 80, 'Delapan Puluh '),
(180, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'QH', 75, 75, 'Tujuh Puluh Lima'),
(181, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'SBK', 75, 80, 'Delapan Puluh '),
(182, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'SKI', 75, 80, 'Delapan Puluh '),
(183, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'SKI', 75, 80, 'Delapan Puluh'),
(184, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'AA', 75, 80, ' Delapan Puluh  '),
(185, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BA', 75, 80, ' Delapan Puluh  '),
(186, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BI', 75, 80, ' Delapan Puluh  '),
(187, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BJ', 75, 80, ' Delapan Puluh  '),
(188, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'FQ', 75, 80, ' Delapan Puluh  '),
(189, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'IPA', 75, 80, ' Delapan Puluh  '),
(190, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'IPS', 75, 80, ' Delapan Puluh  '),
(191, '111234040012121060', '4A', '20160010', '20160018', '2015/2016', 'Ganjil', 'KOM', 75, 80, ' Delapan Puluh  '),
(192, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'MTK', 75, 80, ' Delapan Puluh  '),
(193, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'NU', 75, 80, ' Delapan Puluh  '),
(194, '111234040012121060', '4A', '20160010', '20160015', '2015/2016', 'Ganjil', 'PJO', 75, 80, ' Delapan Puluh  '),
(195, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'PKN', 75, 80, ' Delapan Puluh  '),
(196, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'QH', 75, 80, ' Delapan Puluh  '),
(197, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'SBK', 75, 80, ' Delapan Puluh  '),
(198, '111234040012121060', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'SKI', 75, 80, ' Delapan Puluh  '),
(199, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'AA', 75, 80, ' Delapan Puluh  '),
(200, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BA', 75, 80, ' Delapan Puluh  '),
(201, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BI', 75, 78, ' Tujuh Puluh  Delapan'),
(202, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BJ', 75, 78, ' Tujuh Puluh  Delapan'),
(203, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'FQ', 75, 78, ' Tujuh Puluh  Delapan'),
(204, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'IPA', 75, 78, ' Tujuh Puluh  Delapan'),
(205, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'IPS', 75, 78, ' Tujuh Puluh  Delapan'),
(206, '111234040012121043', '4A', '20160010', '20160017', '2015/2016', 'Ganjil', 'KOM', 75, 80, ' Delapan Puluh  '),
(207, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'MTK', 70, 75, ' Tujuh Puluh  Lima'),
(208, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'NU', 75, 76, ' Tujuh Puluh  Enam'),
(209, '111234040012121043', '4A', '20160010', '20160015', '2015/2016', 'Ganjil', 'PJO', 75, 80, ' Delapan Puluh  '),
(210, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'PKN', 75, 78, ' Tujuh Puluh  Delapan'),
(211, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'QH', 75, 75, ' Tujuh Puluh  Lima'),
(212, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'SBK', 75, 80, ' Delapan Puluh  '),
(213, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'SKI', 75, 85, ' Delapan Puluh  Lima'),
(214, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'AA', 75, 75, ' Tujuh Puluh  Lima'),
(215, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BA', 75, 75, ' Tujuh Puluh  Lima'),
(216, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BI', 75, 78, ' Tujuh Puluh  Delapan'),
(217, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'BJ', 75, 78, ' Tujuh Puluh  Delapan'),
(218, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'FQ', 75, 78, ' Tujuh Puluh  Delapan'),
(219, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'IPA', 75, 78, ' Tujuh Puluh  Delapan'),
(220, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'IPS', 75, 78, ' Tujuh Puluh  Delapan'),
(221, '111234040012121054', '4A', '20160010', '20160017', '2015/2016', 'Ganjil', 'KOM', 75, 85, ' Delapan Puluh  Lima'),
(222, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'MTK', 70, 80, ' Delapan Puluh  '),
(223, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'NU', 75, 75, ' Tujuh Puluh  Lima'),
(224, '111234040012121054', '4A', '20160010', '20160015', '2015/2016', 'Ganjil', 'PJO', 75, 78, ' Tujuh Puluh  Delapan'),
(225, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'PKN', 75, 78, ' Tujuh Puluh  Delapan'),
(226, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'QH', 75, 78, ' Tujuh Puluh  Delapan'),
(227, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'SBK', 75, 78, ' Tujuh Puluh  Delapan'),
(228, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'SKI', 75, 78, ' Tujuh Puluh  Delapan'),
(229, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'AA', 75, 80, ' Delapan Puluh  '),
(230, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'BA', 75, 80, ' Delapan Puluh  '),
(231, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'BI', 75, 75, ' Tujuh Puluh  Lima'),
(232, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'BJ', 75, 75, ' Tujuh Puluh  Lima'),
(233, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'FQ', 75, 75, ' Tujuh Puluh  Lima'),
(234, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'IPA', 75, 76, ' Tujuh Puluh  Enam'),
(235, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'IPS', 75, 76, ' Tujuh Puluh  Enam'),
(236, '111234040012121043', '4A', '20160010', '20160017', '2015/2016', 'Genap', 'KOM', 75, 76, ' Tujuh Puluh  Enam'),
(237, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'MTK', 70, 76, ' Tujuh Puluh  Enam'),
(238, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'NU', 76, 76, ' Tujuh Puluh  Enam'),
(239, '111234040012121043', '4A', '20160010', '20160015', '2015/2016', 'Genap', 'PJO', 75, 80, ' Delapan Puluh  '),
(240, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'PKN', 75, 85, ' Delapan Puluh  Lima'),
(241, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'QH', 75, 85, ' Delapan Puluh  Lima'),
(242, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'SBK', 75, 85, ' Delapan Puluh  Lima'),
(243, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'SKI', 75, 85, ' Delapan Puluh  Lima'),
(244, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'AA', 75, 80, ' Delapan Puluh  '),
(245, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'BA', 75, 80, ' Delapan Puluh  '),
(246, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'BI', 75, 80, ' Delapan Puluh  '),
(247, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'BJ', 75, 85, ' Delapan Puluh  Lima'),
(248, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'FQ', 75, 85, ' Delapan Puluh  Lima'),
(249, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'IPA', 75, 85, ' Delapan Puluh  Lima'),
(250, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'IPS', 75, 80, ' Delapan Puluh  '),
(251, '111234040012121054', '4A', '20160010', '20160017', '2015/2016', 'Genap', 'KOM', 75, 80, ' Delapan Puluh  '),
(252, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'MTK', 75, 80, ' Delapan Puluh  '),
(253, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'NU', 75, 80, ' Delapan Puluh  '),
(254, '111234040012121054', '4A', '20160010', '20160015', '2015/2016', 'Genap', 'PJO', 75, 77, ' Tujuh Puluh  Tujuh'),
(255, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'PKN', 75, 77, ' Tujuh Puluh  Tujuh'),
(256, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'QH', 75, 77, ' Tujuh Puluh  Tujuh'),
(257, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'SBK', 75, 77, ' Tujuh Puluh  Tujuh'),
(258, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Genap', 'SKI', 75, 76, ' Tujuh Puluh  Enam');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai_raport_rata`
--

CREATE TABLE IF NOT EXISTS `tbl_nilai_raport_rata` (
`id` int(11) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `jumlah_nilai` float NOT NULL,
  `nilai_rata` float NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `tbl_nilai_raport_rata`
--

INSERT INTO `tbl_nilai_raport_rata` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `thn_ajaran`, `semester`, `jumlah_nilai`, `nilai_rata`) VALUES
(1, '111234040012151247', '1B', '20160003', '2015/2016', 'Ganjil', 356, 59.3333),
(3, '111234040012141187', '2B', '20160005', '2015/2016', 'Ganjil', 405, 81),
(4, '111234040012141187', '2B', '20160005', '2015/2016', 'Genap', 415, 83),
(5, '111234040012141188', '2B', '20160005', '2015/2016', 'Genap', 418.75, 83.75),
(10, '111234040012141189', '2B', '20160005', '2015/2016', 'Ganjil', 391.25, 78.25),
(14, '111234040012141189', '2B', '20160005', '2015/2016', 'Genap', 412.5, 82.5),
(23, '111234040012141190', '2B', '20160005', '2015/2016', 'Ganjil', 415, 83),
(24, '111234040012141191', '2B', '20160005', '2015/2016', 'Ganjil', 405, 81),
(26, '111234040012141192', '2B', '20160005', '2015/2016', 'Ganjil', 400, 80),
(27, '111234040012141191', '2B', '20160005', '2015/2016', 'Genap', 393.333, 78.6667),
(28, '111234040012141192', '2B', '20160005', '2015/2016', 'Genap', 405.4, 81.08),
(39, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 1487.33, 78.2807),
(40, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 1463.42, 77.0219),
(41, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 1472.92, 77.5219),
(42, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 1357.5, 71.4474),
(43, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 1491, 78.4737),
(44, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 1500.33, 78.9649),
(45, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 1509.33, 79.4386),
(46, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 1534, 80.7368);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai_rata_kepribadian`
--

CREATE TABLE IF NOT EXISTS `tbl_nilai_rata_kepribadian` (
`id` int(11) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `jml_nilai_kp` float NOT NULL,
  `nilai_rata_kp` float NOT NULL,
  `keterangan_kp` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `tbl_nilai_rata_kepribadian`
--

INSERT INTO `tbl_nilai_rata_kepribadian` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `thn_ajaran`, `semester`, `jml_nilai_kp`, `nilai_rata_kp`, `keterangan_kp`) VALUES
(1, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 1435, 79.7222, 'Baik dalam hal :'),
(3, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 1280, 71.1111, 'Sangat Baik Dalam hal :'),
(4, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 1440, 80, 'Sangat Baik'),
(5, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 1390, 77.2222, 'Sangat baik dalam hal :!'),
(6, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 1470, 81.6667, 'Tidak Ada'),
(7, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 1443, 80.1667, 'Tidak Ada'),
(8, '111234040012121058', '4A', '20160010', '2015/2016', 'Ganjil', 1460, 81.1111, 'Tidak Ada'),
(9, '111234040012121059', '4A', '20160010', '2015/2016', 'Ganjil', 1550, 86.1111, 'Tidak Ada'),
(10, '111234040012121060', '4A', '20160010', '2015/2016', 'Ganjil', 1460, 81.1111, 'Tidak Ada'),
(11, '111234040012121062', '4A', '20160010', '2015/2016', 'Ganjil', 1460, 81.1111, 'Tidak ada'),
(12, '111234040012121063', '4A', '20160010', '2015/2016', 'Ganjil', 1440, 80, 'Tidak Ada'),
(13, '111234040012121064', '4A', '20160010', '2015/2016', 'Ganjil', 1520, 84.4444, 'Tidak Ada'),
(14, '111234040012121066', '4A', '20160010', '2015/2016', 'Ganjil', 1385, 76.9444, 'Tidak Ada'),
(15, '111234040012121068', '4A', '20160010', '2015/2016', 'Ganjil', 1453, 80.7222, 'Tidak Ada'),
(16, '111234040012121069', '4A', '20160010', '2015/2016', 'Ganjil', 1425, 79.1667, 'Tidak Ada'),
(17, '111234040012121070', '4A', '20160010', '2015/2016', 'Ganjil', 1460, 81.1111, 'Tidak Ada'),
(18, '111234040012121071', '4A', '20160010', '2015/2016', 'Ganjil', 1375, 76.3889, 'Tidak Ada'),
(19, '111234040012121072', '4A', '20160010', '2015/2016', 'Ganjil', 1425, 79.1667, 'Tidak Ada'),
(20, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 1440, 80, 'Tidak Ada\r\n'),
(21, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 1470, 81.6667, 'Tidak Ada'),
(22, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 1440, 80, 'Tidak Ada'),
(23, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 1425, 79.1667, 'Tidak Ada'),
(24, '111234040012121058', '4A', '20160010', '2015/2016', 'Genap', 1395, 77.5, 'Tidak Ada'),
(25, '111234040012121059', '4A', '20160010', '2015/2016', 'Genap', 1440, 80, 'Tidak Ada'),
(26, '111234040012121060', '4A', '20160010', '2015/2016', 'Genap', 1390, 77.2222, 'Tidak Ada'),
(27, '111234040012121062', '4A', '20160010', '2015/2016', 'Genap', 1510, 83.8889, 'Tidak Ada'),
(28, '111234040012121063', '4A', '20160010', '2015/2016', 'Genap', 1440, 80, 'Tidak Ada'),
(29, '111234040012121064', '4A', '20160010', '2015/2016', 'Genap', 1380, 76.6667, 'Tidak Ada'),
(30, '111234040012121066', '4A', '20160010', '2015/2016', 'Genap', 1405, 78.0556, 'Tidak Ada'),
(31, '111234040012121068', '4A', '20160010', '2015/2016', 'Genap', 1382, 76.7778, 'Tidak Ada'),
(32, '111234040012121069', '4A', '20160010', '2015/2016', 'Genap', 1425, 79.1667, 'Tidak Ada'),
(33, '111234040012121071', '4A', '20160010', '2015/2016', 'Genap', 1440, 80, 'Tidak Ada'),
(34, '111234040012121072', '4A', '20160010', '2015/2016', 'Genap', 1440, 80, 'Tidak Ada'),
(35, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 1440, 80, 'Tidak Ada');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai_rata_tid`
--

CREATE TABLE IF NOT EXISTS `tbl_nilai_rata_tid` (
`id` int(11) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `jml_nilai_tid` float NOT NULL,
  `nilai_rata_tid` float NOT NULL,
  `keterangan_tid` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_nilai_rata_tid`
--

INSERT INTO `tbl_nilai_rata_tid` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `thn_ajaran`, `semester`, `jml_nilai_tid`, `nilai_rata_tid`, `keterangan_tid`) VALUES
(1, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 2065, 76.4815, 'Sangat baik dalam penguasaan hafalan'),
(3, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 2025, 75, 'Sangat baik dalam penguasaaan hafalan'),
(4, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 2170, 80.3704, 'Baik'),
(5, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 2045, 75.7407, 'Baik dalam pnguasaan hafalan!'),
(6, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 2213, 81.963, 'Tidak Ada'),
(7, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 2337, 86.5556, 'Tidak Ada'),
(8, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 2190, 81.1111, 'Tidak Ada'),
(9, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 2133, 79, 'Tidak ada'),
(10, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 1437, 53.2222, 'Tidak Ada'),
(11, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 1402, 51.9259, 'Tidak Ada'),
(12, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 1890, 70, 'Tidak Ada');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai_semester`
--

CREATE TABLE IF NOT EXISTS `tbl_nilai_semester` (
`id` int(11) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `id_guru` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `keterangan` varchar(3) NOT NULL,
  `id_mapel` varchar(5) NOT NULL,
  `nilai` int(3) NOT NULL,
  `nilai_huruf` varchar(25) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=249 ;

--
-- Dumping data for table `tbl_nilai_semester`
--

INSERT INTO `tbl_nilai_semester` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `id_guru`, `thn_ajaran`, `semester`, `keterangan`, `id_mapel`, `nilai`, `nilai_huruf`) VALUES
(14, '12346', '1B', '20160003', '20160010', '2015/2016', 'Ganjil', 'UTS', 'FQ', 89, 'Delapan Puluh Sembilan'),
(16, '12346', '1B', '20160003', '20160002', '2015/2016', 'Ganjil', 'UTS', 'IPA', 62, 'Enam Puluh Dua'),
(22, '111234040012151247', '1B', '20160003', '20160014', '2015/2016', 'Ganjil', 'UTS', 'FQ', 81, 'Delapan Puluh Satu'),
(23, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'AA', 75, 'Tujuh Puluh Lima'),
(24, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BA', 78, 'Tujuh Puluh Delapan'),
(25, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BI', 76, 'Tujuh Puluh Enam'),
(26, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BJ', 80, 'Delapan Puluh '),
(27, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'FQ', 82, 'Delapan Puluh Dua'),
(28, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPA', 79, 'Tujuh Puluh Sembilan'),
(29, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPS', 79, 'Tujuh Puluh Sembilan'),
(30, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'MTK', 75, 'Tujuh Puluh Lima'),
(31, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'PKN', 85, 'Delapan Puluh Lima'),
(32, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'QH', 69, 'Enam Puluh Sembilan'),
(33, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SBK', 89, 'Delapan Puluh Sembilan'),
(34, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'AA', 87, 'Delapan Puluh Tujuh'),
(35, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BA', 79, 'Tujuh Puluh Sembilan'),
(36, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BI', 79, 'Tujuh Puluh Sembilan'),
(37, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BJ', 75, 'Tujuh Puluh Lima'),
(38, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'FQ', 74, 'Tujuh Puluh Empat'),
(39, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPA', 75, 'Tujuh Puluh Lima'),
(40, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPS', 75, 'Tujuh Puluh Lima'),
(41, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'MTK', 72, 'Tujuh Puluh Dua'),
(42, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'PKN', 80, 'Delapan Puluh '),
(43, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'QH', 78, 'Tujuh Puluh Delapan'),
(44, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SBK', 80, 'Delapan Puluh '),
(47, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'NU', 80, 'Delapan Puluh '),
(48, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SKI', 80, 'Delapan Puluh '),
(101, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'AA', 80, 'Delapan Puluh '),
(102, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BA', 80, 'Delapan Puluh '),
(103, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BI', 80, 'Delapan Puluh '),
(104, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BJ', 80, 'Delapan Puluh '),
(105, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'FQ', 80, 'Delapan Puluh '),
(106, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPA', 80, 'Delapan Puluh '),
(107, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPS', 80, 'Delapan Puluh '),
(108, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'MTK', 80, 'Delapan Puluh '),
(109, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'NU', 80, 'Delapan Puluh '),
(110, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'PKN', 80, 'Delapan Puluh '),
(111, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'QH', 80, 'Delapan Puluh '),
(112, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SBK', 80, 'Delapan Puluh '),
(113, '111234040012121058', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SKI', 80, 'Delapan Puluh '),
(129, '111234040012151222', '1A', '20160006', '20160017', '2015/2016', 'Ganjil', 'UTS', 'KOM', 85, 'Delapan Puluh Lima'),
(130, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SKI', 80, 'Delapan Puluh'),
(131, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'NU', 79, 'Tujuh Puluh Sembilan'),
(132, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'AA', 78, 'Tujuh Puluh Delapan'),
(133, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BA', 78, 'Tujuh Puluh Delapan'),
(134, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BI', 78, 'Tujuh Puluh Delapan'),
(135, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BJ', 78, 'Tujuh Puluh Delapan'),
(136, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'FQ', 78, 'Tujuh Puluh Delapan'),
(137, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPA', 78, 'Tujuh Puluh Delapan'),
(138, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPS', 80, 'Delapan Puluh '),
(139, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'MTK', 80, 'Delapan Puluh '),
(140, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'NU', 80, 'Delapan Puluh '),
(141, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'PKN', 80, 'Delapan Puluh '),
(142, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'QH', 80, 'Delapan Puluh '),
(143, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SBK', 80, 'Delapan Puluh '),
(144, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SKI', 80, 'Delapan Puluh '),
(145, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'AA', 80, 'Delapan Puluh '),
(146, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BA', 80, 'Delapan Puluh '),
(147, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BI', 80, 'Delapan Puluh '),
(148, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BJ', 80, 'Delapan Puluh '),
(149, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'FQ', 80, 'Delapan Puluh '),
(150, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPA', 80, 'Delapan Puluh '),
(151, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPS', 80, 'Delapan Puluh '),
(152, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'MTK', 80, 'Delapan Puluh '),
(153, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'NU', 80, 'Delapan Puluh '),
(154, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'PKN', 80, 'Delapan Puluh '),
(155, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'QH', 80, 'Delapan Puluh '),
(156, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SBK', 85, 'Delapan Puluh Lima'),
(157, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SKI', 85, 'Delapan Puluh Lima'),
(158, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'AA', 80, 'Delapan Puluh '),
(159, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BA', 80, 'Delapan Puluh '),
(160, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BI', 80, 'Delapan Puluh '),
(161, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BJ', 80, 'Delapan Puluh '),
(162, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'FQ', 80, 'Delapan Puluh '),
(163, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'IPA', 80, 'Delapan Puluh '),
(164, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'IPS', 85, 'Delapan Puluh Lima'),
(165, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'MTK', 85, 'Delapan Puluh Lima'),
(166, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'NU', 85, 'Delapan Puluh Lima'),
(167, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'PKN', 85, 'Delapan Puluh Lima'),
(168, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'QH', 80, 'Delapan Puluh '),
(169, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'SBK', 80, 'Delapan Puluh '),
(170, '111234040012111024', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'SKI', 80, 'Delapan Puluh '),
(184, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'AA', 80, 'Delapan Puluh '),
(185, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BA', 75, 'Tujuh Puluh Lima'),
(186, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BI', 80, 'Delapan Puluh '),
(187, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BJ', 80, 'Delapan Puluh '),
(188, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'FQ', 75, 'Tujuh Puluh Lima'),
(189, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'IPA', 78, 'Tujuh Puluh Delapan'),
(190, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'IPS', 78, 'Tujuh Puluh Delapan'),
(191, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'MTK', 78, 'Tujuh Puluh Delapan'),
(192, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'NU', 80, 'Delapan Puluh '),
(193, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'PKN', 80, 'Delapan Puluh '),
(194, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'QH', 80, 'Delapan Puluh '),
(195, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'SBK', 85, 'Delapan Puluh Lima'),
(196, '111234040012121043', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'SKI', 85, 'Delapan Puluh Lima'),
(197, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'AA', 85, 'Delapan Puluh Lima'),
(198, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BA', 85, 'Delapan Puluh Lima'),
(199, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BI', 85, 'Delapan Puluh Lima'),
(200, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BJ', 85, 'Delapan Puluh Lima'),
(201, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'FQ', 85, 'Delapan Puluh Lima'),
(202, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'IPA', 78, 'Tujuh Puluh Delapan'),
(203, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'IPS', 78, 'Tujuh Puluh Delapan'),
(204, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'MTK', 75, 'Tujuh Puluh Lima'),
(205, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'NU', 80, 'Delapan Puluh '),
(206, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'PKN', 80, 'Delapan Puluh '),
(207, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'QH', 85, 'Delapan Puluh Lima'),
(208, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'SBK', 86, 'Delapan Puluh Enam'),
(209, '111234040012121054', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'SKI', 86, 'Delapan Puluh Enam'),
(210, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'AA', 88, 'Delapan Puluh Delapan'),
(211, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BA', 88, 'Delapan Puluh Delapan'),
(212, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BI', 88, 'Delapan Puluh Delapan'),
(213, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BJ', 88, 'Delapan Puluh Delapan'),
(214, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'FQ', 88, 'Delapan Puluh Delapan'),
(215, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'IPA', 78, 'Tujuh Puluh Delapan'),
(216, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'IPS', 78, 'Tujuh Puluh Delapan'),
(217, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'MTK', 78, 'Tujuh Puluh Delapan'),
(218, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'NU', 78, 'Tujuh Puluh Delapan'),
(219, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'PKN', 78, 'Tujuh Puluh Delapan'),
(220, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'QH', 78, 'Tujuh Puluh Delapan'),
(221, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'SBK', 80, 'Delapan Puluh '),
(222, '111234040012121055', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'SKI', 80, 'Delapan Puluh '),
(223, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'AA', 80, 'Delapan Puluh '),
(224, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BA', 80, 'Delapan Puluh '),
(225, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BI', 80, 'Delapan Puluh '),
(226, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'BJ', 80, 'Delapan Puluh '),
(227, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'FQ', 80, 'Delapan Puluh '),
(228, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'IPA', 80, 'Delapan Puluh '),
(229, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'IPS', 80, 'Delapan Puluh '),
(230, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'MTK', 80, 'Delapan Puluh '),
(231, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'NU', 80, 'Delapan Puluh '),
(232, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'PKN', 80, 'Delapan Puluh '),
(233, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'QH', 80, 'Delapan Puluh '),
(234, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'SBK', 80, 'Delapan Puluh '),
(235, '111234040012121056', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UAS', 'SKI', 80, 'Delapan Puluh '),
(236, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'AA', 80, 'Delapan Puluh '),
(237, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BA', 88, 'Delapan Puluh Delapan'),
(238, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BI', 85, 'Delapan Puluh Lima'),
(239, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'BJ', 85, 'Delapan Puluh Lima'),
(240, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'FQ', 85, 'Delapan Puluh Lima'),
(241, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPA', 75, 'Tujuh Puluh Lima'),
(242, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'IPS', 75, 'Tujuh Puluh Lima'),
(243, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'MTK', 80, 'Delapan Puluh '),
(244, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'NU', 80, 'Delapan Puluh '),
(245, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'PKN', 80, 'Delapan Puluh '),
(246, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'QH', 80, 'Delapan Puluh '),
(247, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SBK', 85, 'Delapan Puluh Lima'),
(248, '111234040012121074', '4A', '20160010', '20160010', '2015/2016', 'Ganjil', 'UTS', 'SKI', 86, 'Delapan Puluh Enam');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai_tahfid_doa`
--

CREATE TABLE IF NOT EXISTS `tbl_nilai_tahfid_doa` (
`id` int(11) NOT NULL,
  `nis_lokal` varchar(18) NOT NULL,
  `id_kelas` varchar(2) NOT NULL,
  `id_wali` varchar(8) NOT NULL,
  `thn_ajaran` varchar(9) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `id_tahfid_doa` int(3) NOT NULL,
  `nilai_tahfid` int(3) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=352 ;

--
-- Dumping data for table `tbl_nilai_tahfid_doa`
--

INSERT INTO `tbl_nilai_tahfid_doa` (`id`, `nis_lokal`, `id_kelas`, `id_wali`, `thn_ajaran`, `semester`, `id_tahfid_doa`, `nilai_tahfid`) VALUES
(28, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80),
(29, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(30, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(31, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(32, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 5, 75),
(33, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 6, 75),
(34, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 7, 75),
(35, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 8, 75),
(36, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 9, 75),
(37, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 10, 75),
(38, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 11, 75),
(39, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 12, 75),
(40, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 13, 75),
(41, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 14, 75),
(42, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 15, 75),
(43, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 16, 75),
(44, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 17, 75),
(45, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 18, 75),
(46, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 19, 75),
(47, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 20, 75),
(48, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 21, 75),
(49, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 22, 75),
(50, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 23, 75),
(51, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 24, 80),
(52, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 25, 80),
(53, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 26, 80),
(54, '111234040012111024', '4A', '20160010', '2015/2016', 'Ganjil', 27, 80),
(82, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 1, 75),
(83, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 2, 75),
(84, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 3, 75),
(85, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 4, 75),
(86, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 5, 75),
(87, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 6, 75),
(88, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 7, 75),
(89, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 8, 75),
(90, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 9, 75),
(91, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 10, 75),
(92, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 11, 75),
(93, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 12, 75),
(94, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 13, 75),
(95, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 14, 75),
(96, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 15, 75),
(97, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 16, 75),
(98, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 17, 75),
(99, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 18, 75),
(100, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 19, 75),
(101, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 20, 75),
(102, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 21, 75),
(103, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 22, 75),
(104, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 23, 75),
(105, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 24, 75),
(106, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 25, 75),
(107, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 26, 75),
(108, '111234040012111024', '4A', '20160010', '2015/2016', 'Genap', 27, 75),
(109, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80),
(110, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(111, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(112, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 4, 80),
(113, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 5, 80),
(114, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 6, 80),
(115, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 7, 90),
(116, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 8, 80),
(117, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 9, 80),
(118, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 10, 80),
(119, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 11, 80),
(120, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 12, 80),
(121, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 13, 80),
(122, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 14, 80),
(123, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 15, 80),
(124, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 16, 80),
(125, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 17, 80),
(126, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 18, 80),
(127, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 19, 80),
(128, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 20, 80),
(129, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 21, 80),
(130, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 22, 80),
(131, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 23, 80),
(132, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 24, 80),
(133, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 25, 80),
(134, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 26, 80),
(135, '111234040012121055', '4A', '20160010', '2015/2016', 'Ganjil', 27, 80),
(136, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 1, 80),
(137, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 2, 80),
(138, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 3, 75),
(139, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 4, 75),
(140, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 5, 75),
(141, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 6, 75),
(142, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 7, 75),
(143, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 8, 75),
(144, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 9, 75),
(145, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 10, 75),
(146, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 11, 75),
(147, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 12, 75),
(148, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 13, 75),
(149, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 14, 75),
(150, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 15, 75),
(151, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 16, 75),
(152, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 17, 75),
(153, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 18, 75),
(154, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 19, 75),
(155, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 20, 75),
(156, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 21, 75),
(157, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 22, 75),
(158, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 23, 75),
(159, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 24, 75),
(160, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 25, 75),
(161, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 26, 80),
(162, '111234040012121043', '4A', '20160010', '2015/2016', 'Ganjil', 27, 80),
(163, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(164, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 2, 65),
(165, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 3, 80),
(166, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 4, 90),
(167, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 5, 90),
(168, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 6, 90),
(169, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 7, 90),
(170, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 8, 90),
(171, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 9, 90),
(172, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 10, 90),
(173, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 11, 90),
(174, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 12, 90),
(175, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 13, 90),
(176, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 14, 90),
(177, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 15, 90),
(178, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 16, 90),
(179, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 17, 90),
(180, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 18, 80),
(181, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 19, 90),
(182, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 20, 78),
(183, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 21, 90),
(184, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 22, 90),
(185, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 23, 90),
(186, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 24, 70),
(187, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 25, 70),
(188, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 26, 30),
(189, '111234040012121054', '4A', '20160010', '2015/2016', 'Ganjil', 27, 30),
(190, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 1, 90),
(191, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 2, 90),
(192, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 3, 90),
(193, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 4, 90),
(194, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 5, 90),
(195, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 6, 90),
(196, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 7, 89),
(197, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 8, 90),
(198, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 9, 88),
(199, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 10, 85),
(200, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 11, 85),
(201, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 12, 85),
(202, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 13, 85),
(203, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 14, 85),
(204, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 15, 85),
(205, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 16, 85),
(206, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 17, 85),
(207, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 18, 85),
(208, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 19, 85),
(209, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 20, 85),
(210, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 21, 85),
(211, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 22, 85),
(212, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 23, 85),
(213, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 24, 85),
(214, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 25, 85),
(215, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 26, 85),
(216, '111234040012121056', '4A', '20160010', '2015/2016', 'Ganjil', 27, 85),
(217, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 1, 90),
(218, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 2, 90),
(219, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 3, 90),
(220, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 4, 90),
(221, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 5, 90),
(222, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 6, 90),
(223, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 7, 90),
(224, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 8, 90),
(225, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 9, 90),
(226, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 10, 90),
(227, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 11, 90),
(228, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 12, 90),
(229, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 13, 90),
(230, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 14, 90),
(231, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 15, 90),
(232, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 16, 90),
(233, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 17, 90),
(234, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 18, 90),
(235, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 19, 90),
(236, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 20, 90),
(237, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 21, 90),
(238, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 22, 90),
(239, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 23, 90),
(240, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 24, 30),
(241, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 25, 30),
(242, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 26, 30),
(243, '111234040012121043', '4A', '20160010', '2015/2016', 'Genap', 27, 30),
(244, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 1, 90),
(245, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 2, 65),
(246, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 3, 80),
(247, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 4, 90),
(248, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 5, 90),
(249, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 6, 90),
(250, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 7, 90),
(251, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 8, 90),
(252, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 9, 90),
(253, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 10, 90),
(254, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 11, 90),
(255, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 12, 90),
(256, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 13, 90),
(257, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 14, 90),
(258, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 15, 90),
(259, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 16, 90),
(260, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 17, 90),
(261, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 18, 80),
(262, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 19, 90),
(263, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 20, 78),
(264, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 21, 90),
(265, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 22, 90),
(266, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 23, 90),
(267, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 24, 30),
(268, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 25, 30),
(269, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 26, 30),
(270, '111234040012121054', '4A', '20160010', '2015/2016', 'Genap', 27, 30),
(271, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 1, 90),
(272, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 2, 90),
(273, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 3, 90),
(274, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 4, 90),
(275, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 5, 90),
(276, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 6, 89),
(277, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 7, 80),
(278, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 8, 90),
(279, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 9, 80),
(280, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 10, 78),
(281, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 11, 45),
(282, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 12, 45),
(283, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 13, 45),
(284, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 14, 45),
(285, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 15, 30),
(286, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 16, 30),
(287, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 17, 30),
(288, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 18, 30),
(289, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 19, 30),
(290, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 20, 30),
(291, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 21, 30),
(292, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 22, 30),
(293, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 23, 30),
(294, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 24, 30),
(295, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 25, 30),
(296, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 26, 30),
(297, '111234040012121055', '4A', '20160010', '2015/2016', 'Genap', 27, 30),
(298, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 1, 90),
(299, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 2, 90),
(300, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 3, 90),
(301, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 4, 90),
(302, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 5, 90),
(303, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 6, 89),
(304, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 7, 90),
(305, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 8, 88),
(306, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 9, 85),
(307, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 10, 90),
(308, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 11, 30),
(309, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 12, 30),
(310, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 13, 30),
(311, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 14, 30),
(312, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 15, 30),
(313, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 16, 30),
(314, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 17, 30),
(315, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 18, 30),
(316, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 19, 30),
(317, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 20, 30),
(318, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 21, 30),
(319, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 22, 30),
(320, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 23, 30),
(321, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 24, 30),
(322, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 25, 30),
(323, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 26, 30),
(324, '111234040012121056', '4A', '20160010', '2015/2016', 'Genap', 27, 30),
(325, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 1, 70),
(326, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 2, 70),
(327, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 3, 70),
(328, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 4, 70),
(329, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 5, 70),
(330, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 6, 70),
(331, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 7, 70),
(332, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 8, 70),
(333, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 9, 70),
(334, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 10, 70),
(335, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 11, 70),
(336, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 12, 70),
(337, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 13, 70),
(338, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 14, 70),
(339, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 15, 70),
(340, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 16, 70),
(341, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 17, 70),
(342, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 18, 70),
(343, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 19, 70),
(344, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 20, 70),
(345, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 21, 70),
(346, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 22, 70),
(347, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 23, 70),
(348, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 24, 70),
(349, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 25, 70),
(350, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 26, 70),
(351, '111234040012121074', '4A', '20160010', '2015/2016', 'Ganjil', 27, 70);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ortu`
--

CREATE TABLE IF NOT EXISTS `tbl_ortu` (
`id_ortu` int(4) NOT NULL,
  `no_induk` varchar(18) NOT NULL,
  `no_kartu_keluarga` varchar(16) NOT NULL,
  `nama_ayah` varchar(25) NOT NULL,
  `nama_ibu` varchar(25) NOT NULL,
  `tempat_lahir_ayah` varchar(15) NOT NULL,
  `tgl_lahir_ayah` date NOT NULL,
  `tempat_lahir_ibu` varchar(15) NOT NULL,
  `tgl_lahir_ibu` date NOT NULL,
  `alamat_ortu` text NOT NULL,
  `pekerjaan_ayah` varchar(25) NOT NULL,
  `penghasilan_ayah` int(11) NOT NULL,
  `pekerjaan_ibu` varchar(25) NOT NULL,
  `penghasilan_ibu` int(11) NOT NULL,
  `ket_hidup_ayah` varchar(2) NOT NULL,
  `ket_hidup_ibu` varchar(2) NOT NULL,
  `no_tlp_ortu` varchar(12) NOT NULL,
  `nama_wali` varchar(25) NOT NULL,
  `tempat_lahir_wali` varchar(15) NOT NULL,
  `tgl_lahir_wali` date NOT NULL,
  `alamat_wali` text NOT NULL,
  `jenis_kel_wali` varchar(1) NOT NULL,
  `agama_wali` varchar(10) NOT NULL,
  `pekerjaan_wali` varchar(15) NOT NULL,
  `penghasilan_wali` int(11) NOT NULL,
  `no_tlp_wali` varchar(12) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=268 ;

--
-- Dumping data for table `tbl_ortu`
--

INSERT INTO `tbl_ortu` (`id_ortu`, `no_induk`, `no_kartu_keluarga`, `nama_ayah`, `nama_ibu`, `tempat_lahir_ayah`, `tgl_lahir_ayah`, `tempat_lahir_ibu`, `tgl_lahir_ibu`, `alamat_ortu`, `pekerjaan_ayah`, `penghasilan_ayah`, `pekerjaan_ibu`, `penghasilan_ibu`, `ket_hidup_ayah`, `ket_hidup_ibu`, `no_tlp_ortu`, `nama_wali`, `tempat_lahir_wali`, `tgl_lahir_wali`, `alamat_wali`, `jenis_kel_wali`, `agama_wali`, `pekerjaan_wali`, `penghasilan_wali`, `no_tlp_wali`) VALUES
(1, '111234040012151222', '', 'Wawan Affandi', 'Fitri Sri Lestari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(2, '111234040012151223', '', 'Wardiyana', 'Karmini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(3, '111234040012151224', '3404070602055348', 'Wiji Sihono', 'Susanna', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(4, '111234040012151225', '340407809120002', 'Muhammad Bejo Lukito', 'Siri Dewi Khoiriyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(5, '111234040012151226', '3404072305070012', 'Nafi Riawan', 'Isti Nafingah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(6, '111234040012151227', '', 'Wagiran', 'Wahyuningsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(7, '111234040012151228', '', 'Erfin Susanta', 'Siti Komariyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(8, '111234040012151229', '', 'Jati Iswardoyo,ST,M.Eng', 'Ernawati (Almh)/ Rahmadia', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(9, '111234040012151230', '', 'Susito', 'Ensiana Triermi', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(10, '111234040012151231', '3527093010120009', 'Pudali', 'Rumsiya', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(11, '111234040012151232', '', 'Nanang Ubaidillah Nasir', 'Siti Uswatun Khasanah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(12, '111234040012151233', '3404070506070036', 'Supriyadi', 'Siti Alfiah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(13, '111234040012151234', '340407052090005', 'Rokhmat Taufik', 'SekarSuminingsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(14, '111234040012151235', '3404071303070031', 'Supriyono', 'Rumanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(15, '111234040012151236', '34040â€¦', 'Drs. Sutaryana', 'Sriatun', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(16, '111234040012151237', '', 'Sigit', 'Subinah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(17, '111234040012151238', '3402092009110002', 'Nur Widodo Riyadi', 'Mukaromah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(18, '111234040012151239', '', 'M. Mufid', 'Siti Muslimah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(19, '111234040012151240', '', 'Warno', 'Kasriyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(20, '111234040012151241', '3404070202056353', 'Rujito', 'Anna Astuti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(21, '111234040012151242', '', 'Yohanes Yonkob Wasa', 'wiwik winarti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(22, '111234040012151243', '', 'Baharudin Nasir', 'Walmiyati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(23, '111234040012151244', '3404073105130007', 'Budi Sugiarto', 'Aria Yusniati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(24, '111234040012151245', '', 'Marsudi', 'Istinganah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(25, '111234040012151246', '', 'Dwi Joko Santoso', 'Muji Rahayu', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(26, '111234040012151247', '', 'Zahid', 'Tumiyem', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(27, '111234040012151248', '', 'Harno', 'Sulati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(28, '111234040012151249', '3404122702080001', 'Retno Triono', 'Titik Ambarsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(29, '111234040012151250', '3671090503080224', 'Pargiono', 'Sulis Setyawati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(30, '111234040012151251', '', 'Mamat Sobandi', 'Salimah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(31, '111234040012151252', '', 'Dedi Purnomo', 'Rofiqoh A Syam', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(32, '111234040012151253', '', 'Abdurrahman', 'Yuli Permana', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(33, '111234040012151254', '', 'Dani Irawan', 'Rita Kristanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(34, '111234040012151255', '3404070502055112', 'Jumiran', 'Minarsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(35, '111234040012151256', '', 'Muhammad Sa''dun', 'Ena Ristiyani', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(36, '111234040012151257', '', 'Akhmad Amsori', 'Wina Triyasanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(37, '111234040012151258', '3404071010090008', 'Munir', 'Ngatinem', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(38, '111234040012151259', '3404072707080007', 'Zainal Abidin', 'Ponirah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(39, '111234040012151260', '', 'Darsono', 'Aliyah Rohmah Hamid', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(40, '111234040012151261', '', 'Budiyanto', 'Rubiniyati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(41, '111234040012151262', '', 'Suparman', 'Sri Wijayanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(42, '111234040012151263', '', 'Nur Hardiyanto', 'Titik Setyaningsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(43, '111234040012151264', '', 'Faliq Tyagara', 'Yuni Ariska Dewi', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(44, '111234040012151265', '', 'Tasripin', 'Titin', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(45, '111234040012151266', '3671053007100007', 'Priyono', 'Ganik Prihatin', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(46, '111234040012151267', '3404070602054897', 'Yasin Yusuf', 'Sunarti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(47, '111234040012151268', '3404115502056020', 'Rokhimin Bahrun Damawi', 'Ipuk Tri Utami', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(48, '111234040012141158', '3308190307106507', 'Amin Ainul Yakin', 'Yulia Dritawati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(49, '111234040012141159', '3403072611070024', 'Suranto', 'Berta Tri Astuti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(50, '111234040012141160', '3404072302080175', 'Alm. Slamet', 'Asih Mugiasih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(51, '111234040012141161', '3404070709110006', 'Fajar (cerai)', 'Ni Made Prita Pitaloka', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(52, '111234040012141162', '3404070804110003', 'Kuwatno', 'Partiyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(53, '111234040012141164', '3311120702120003', 'Kusworo Tri Nugroho', 'Budi Setyaningsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(54, '111234040012141165', '3404171206070005', 'Sigit Haryanta', 'Zuhriatun', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(55, '111234040012141166', '3404070412070022', 'Wendra Hengky', 'Asmarita', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(56, '111234040012151269', '3308121011140002', 'Hari Suprapto', 'Maulin Nikmah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(57, '111234040012141167', '3404072210130004', 'Surasa', 'Welasati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(58, '111234040012141168', '3404113101080011', 'Suprihatin', 'Sutami', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(59, '111234040012141169', '3404070109080003', 'M. Habibul Rahmat', 'Kumalasari Candraningrum', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(60, '111234040012141170', '3404101002053201', 'Muh. Nuryasin', 'Wahyu Sri Lestari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(61, '111234040012141171', '3404110107100006', 'Muhammad Burhanudin', 'Tri Lestari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(62, '111234040012141172', '3505110303110001', 'Nasik', 'Evania Rahmawati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(63, '111234040012141173', '3404101902060003', 'Hadi Purwanto', 'Ida Rosanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(64, '111234040012141174', '3404070702051305', 'Wartono', 'Karmiyati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(65, '111234040012141175', '3404072211110001', 'Edi Purwanto', 'Fitri Yunita (cerai)', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(66, '111234040012141176', '3521091505080050', 'Saheri', 'Riska Puspitasari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(67, '111234040012141177', '3404112504080003', 'Rohyichin', 'Sartini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(68, '111234040012141178', '3404071007080012', 'Mulyadi', 'Irma Wati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(69, '111234040012141179', '3404072008070007', 'Umar Arifin', 'Sri Mugiasih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(70, '111234040012141180', '3404070605140014', 'Ali Nugroho', 'Dewi Neni', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(71, '111234040012141181', '3404070502057583', 'Saryono', 'Ira Rahmawati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(72, '111234040012141182', '3404122901080048', 'Moch Taufiq', 'Reni Suryatati P', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(73, '111234040012141183', '3404070906080001', 'Subagyo', 'Dwi Setyorini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(74, '111234040012141184', '3404071311070019', 'Muh. Jari', 'Sunarsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(75, '111234040012141185', '3404070502058374', 'Alm Wahono', 'Sukarni', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(76, '111234040012141186', '3404070212100001', 'Joko Istianto', 'Siti Suparni', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(77, '111234040012151270', '', 'Simuh', 'Ita Zusanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(78, '111234040012141187', '3404111211130001', 'Hendri Istanto', 'Widya Hestiningrum', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(79, '111234040012141188', '3404071402080133', 'Nugroho Nurdiyanto', 'Maya Sulistyowati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(80, '111234040012141189', '3404072010080016', 'Suwanto', 'Lestari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(81, '111234040012141190', '3404070602055112', 'Jumari', 'Sri Maryanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(82, '111234040012141191', '3404072811070014', 'M. Dzamrodin', 'Marjanah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(83, '111234040012141192', '3404072605080001', 'Fendy Prastya Putra', 'Ria Sartika Kusuma Dewi', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(84, '111234040012141193', '3404072301080010', 'Pramono', 'Sukismi', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(85, '111234040012141194', '3404112510100006', 'Nurdiantoro', 'Eni Pujirahayu', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(86, '111234040012141195', '3313081610120002', 'Sunarto', 'Lilis Setyowati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(87, '111234040012141196', '3404072611080004', 'Purnama', 'Yatini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(88, '111234040012141197', '3404101201080009', 'Sugiyanto', 'Indri Sulistyaningsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(89, '111234040012141198', '3404071606110006', 'Taufiqur Rohman', 'Sukaesi', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(90, '111234040012141199', '3404071802070012', 'Suratman', 'Sri Utami', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(91, '111234040012141200', '3403112604110006', 'Kuswanta', 'Wiyuniarti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(92, '111234040012141202', '3403063112090009', 'Wahidahmadi', 'Sunarti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(93, '111234040012141201', '4304070602050933', 'Arief Setiawan ', 'Imro Atus Sholichah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(94, '111234040012141203', '3578280101088183', 'Nasuri', 'Djuna', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(95, '111234040012141204', '3404072306100008', 'Agus Susanto', 'Marni', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(96, '111234040012141205', '3404070904080002', 'Sunarjo', 'Sulastri', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(97, '111234040012141206', '3404120309070011', 'Mukholid Hidayat', 'Fatmawati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(98, '111234040012141207', '', 'Muhk Rosyid', 'Isti Nurjanah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(99, '111234040012141208', '3404102308130005', 'Alihasan ', 'Sirnikah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(100, '111234040012141209', '3402142604050002', 'Alm Eko Wahyudi', 'Lis Artini ', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(101, '111234040012141210', '3404071011070011', 'Wijiasih', 'Sartiyem', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(102, '111234040012141211', '3404070402052609', 'Karindi', 'Partini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(103, '111234040012141212', '3471110409020074', 'Mantono', 'Yusfita Handayani', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(104, '111234040012141213', '3507181210050009', 'Ali Faisal', 'Lindayati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(105, '111234040012141214', '3404071802080126', 'Aswandi', 'Suliastin', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(106, '111234040012141215', '3404070407070004', 'Doni Aryadi', 'Yunila Sari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(107, '111234040012141216', '3404080802056718', 'Giyo', 'Sukinem', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(108, '111234040012151273', '', 'Suratmin', 'Jumirah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(109, '111234040012131107', '3404070602056401', 'Tarji', 'Nur Asiah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(110, '111234040012131108', '3522102001077062', 'Martono', 'Utapiyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(111, '111234040012131109', '3404111102057056', 'Jumadi', 'Nining Siswati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(112, '111234040012131110', '3209250804110006', 'Bedi', 'Sofiyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(113, '111234040012131111', '3404102801100004', 'Komarudin', 'Istijabah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(114, '111234040012151271', '', 'Heri Surya Purnomo', 'Mesni Sigira', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(115, '111234040012131113', '3404071304070018', 'Fais Priyono', 'Siti Rosyidah Ahmad', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(116, '111234040012131114', '3404101303080012', 'Muhsin Amin', 'Sakdiyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(117, '111234040012131115', '3404072801080016', 'Imam Hambali', 'Siti Saodah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(118, '111234040012131116', '3404073010070006', 'Marsuadi', 'Istinganah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(119, '111234040012131117', '3404072809070002', 'Imadi', 'Tri Dwi Astuti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(120, '111234040012131119', '3404072304070004', 'Zukro', 'Kustanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(121, '111234040012131121', '3520490800192', 'Mustakim', 'Erna Nur Afiyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(122, '111234040012131122', '3404070602054609', 'Ngabdullah ', 'Murniyati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(123, '111234040012131123', '3404070602054721', 'Slamet Riyanto', 'Purwanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(124, '111234040012141217', '3404070706080013', 'Warno', 'Kasaiyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(125, '111234040012131124', '3313160506120011', 'Ayi Ma''ruf', 'Suwarti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(126, '111234040012131125', '3404072502090014', 'Saridi', 'Sumarti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(127, '111234040012131126', '3404071608110007', 'Rochmatji', 'Mintarsih Setiyarini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(128, '111234040012131128', '3404071302080093', 'Dedi Koswara', 'Sri Sumarni', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(129, '111234040012131129', '3208080602065898', 'Juned', 'Mamah Salmah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(130, '111234040012131130', '3309160212069679', 'Jumeri Husen', 'Sudarti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(131, '111234040012121076', '3404070907070023', 'Tri Wahyudi', 'Sugiyarti Hartini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(132, '111234040012131131', '340411260410002', 'Ir. Woeryanto', 'Imelda', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(133, '111234040012131132', '1119020817812', 'Saifudin', 'Tri Handayani', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(134, '111234040012131133', '3404073003070020', 'Ismurdijana', 'Septiana Puspitasari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(135, '111234040012131134', '3404071609060027', 'Sumadi', 'Eko Suryanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(136, '111234040012131135', '3520042507120007', 'Parjiyanto', 'Vira Andriasna N', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(137, '111234040012131136', '3505151411120001', 'Sarmin', 'Tumini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(138, '111234040012131137', '3404071602080088', 'Tri Widodo', 'Nur Wahyuni Agustina', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(139, '111234040012131138', '3308190307106507', 'Amin Ainul Yakin', 'Yulia Dritawati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(140, '111234040012131139', '3310190407070006', 'Mahsun Musthofa, S.Ag.', 'Evy Marlina', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(141, '111234040012131141', '3403111511078626', 'Sulisno', 'Rustini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(142, '111234040012131142', '3520081303120012', 'Subiyono', 'Supatmi', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(143, '111234040012131143', '3404072006060006', 'Saiful Bahri', 'Sulastri', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(144, '111234040012131144', '3404071609060006', 'Wagino', 'Karsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(145, '111234040012151272', '', 'Tukimin (alm)', 'Musyarofah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(146, '111234040012131145', '3404071310110009', 'Sukardiman', 'Suratmi', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(147, '111234040012131146', '3404110911060005', 'Samsul Hidayat', 'Sarjinem', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(148, '111234040012131147', '3404070602050786', 'Pardiono', 'Ruswitaningsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(149, '111234040012131148', '3471042906050175', 'Kieke Akbar ', 'Farida', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(150, '111234040012131149', '3404101902060003', 'Hadi Purwanto', 'Ida Rosanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(151, '111234040012131150', '3404113005120002', 'Purwanto', 'Budiyanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(152, '111234040012131151', '3404070402057002', 'Ponirin', 'Sulastri Wahyuningsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(153, '111234040012151221', '', '', 'Wartiyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(154, '111234040012121095', '3404071311070019', 'Muh Jari', 'Sunarsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(155, '111234040012131153', '3404071802080113', 'Ngatori', 'Nurul Khabibah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(156, '111234040012131154', '3404111102058039', 'Sugiyanto', 'Sunar Martiniatun', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(157, '111234040012121054', '3401111102057954', 'Mujiyono', 'Sri Sumartini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(158, '111234040012121055', '3404072407060001', 'Danang S', 'Yuli K', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(159, '111234040012121056', '3404070602055067', 'Sugeng', 'Nur Hayati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(160, '111234040012121058', '3404070502057197', 'Saragung M', 'Purwaningrum', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(161, '111234040012121059', '3404070502057850', 'Aris Murwanto', 'Irmina Sari S', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(162, '111234040012121060', '3404070602050499', 'Poniman', 'Sri Lestari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(163, '111234040012121062', '3404070502080046', 'Andi Kusmantoro', 'Yati Kusrini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(164, '111234040012121063', '340407081100002', 'Jumadi', 'Sugiyem', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(165, '111234040012121064', '3404072709070005', 'Haryanto', 'Ngimronah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(166, '111234040012121066', '3404070602055066', 'Miftakurohman', 'Siti Zayinatun', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(167, '111234040012121068', '3404072302080169', 'Semiyono', 'Mujiyati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(168, '111234040012121043', '3404072202080068', 'Muh Harowi', 'Siti Warifah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(169, '111234040012121069', '3404070502057877', 'Marjono', 'Parmiyatun', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(170, '111234040012121070', '3404111202050501', 'Sutarmin', 'Sumiasih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(171, '111234040012121071', '3404072211080003', 'Agus Al Hakim B', 'Sumaryastuti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(172, '111234040012121072', '3404071310110009', 'Sukardiman', 'Hapsari Ningrum', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(173, '111234040012121074', '3404070203060006', 'H Sarjono', 'Minarsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(174, '111234040012111024', '3404100201130008', 'Purwanto', 'Eni Rubiastuti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(175, '111234040012121075', '3404101002053021', 'Muh Nur Yasin', 'Wahyu Sri L', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(176, '111234040012121077', '3404070502059744', 'M Anwar', 'Asfinah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(177, '111234040012121078', '3404102806080004', 'Arnis Adnan', 'Armis', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(178, '111234040012121079', '3404070502059710', 'Winaryo', 'Erni Sulistyanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(179, '111234040012121080', '3404070602055018', 'M Anas', 'Sri Rahayu', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(180, '111234040012121082', '3404070202080026', 'M Ali Ma''sum', 'Lutfie Fauzana', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(181, '111234040012121081', '3404072808070024', 'Mustofa Ngaripin', 'Supartiyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(182, '111234040012121083', '3310212801110004', 'Mas''ud', 'Muryani', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(183, '111234040012121084', '3404070602055487', 'Ibnu Muhamad', 'Sri Hartini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(184, '111234040012121105', '1112042902120005', 'Pril Huseno', 'Sartika Fitrianti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(185, '111234040012121085', '3404070312080010', 'Untung Sulistiyono', 'Wanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(186, '111234040012121086', '3403081910090002', 'Bejo Susanto', 'Lasmini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(187, '111234040012121087', '3404072211080003', 'Agus Al Hakim', 'Sumaryastuti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(188, '111234040012121088', '3404072907060003', 'Suroso', 'Welasati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(189, '111234040012121090', '3471110409020074', 'Mantono', 'Yuffita Handayani', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(190, '111234040012121093', '3404070402057002', 'Ponirin', 'Sulastri Wahyuningsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(191, '111234040012121094', '3404071507060003', 'Sujono', 'Isyuwanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(192, '111234040012121096', '3404070502080046', 'Suteja Wibowo', 'Rini Listyaningrum', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(193, '111234040012121097', '3404070606060035', 'Aris Sugiyana', 'Erni  ', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(194, '111234040012121098', '3404102801100004', 'Komarudin', 'Isti Jabah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(195, '111234040012121099', '3404070502058317', 'Sutaryana', 'Sri Yatun', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(196, '111234040012111031', '3471122706090250', 'Bialva Wisnu', 'Fadhlun', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(197, '111234040012111032', '3404071001120012', 'Tri Haryanto', 'Jazilah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(198, '111234040012111008', '3404072910070029', 'Sarjiyono', 'Tumiasih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(199, '111234040012111036', '3404070602053913', 'Windu Haryadi', 'Nurjayanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(200, '111234040012111012', '3404111102058039', 'Sugiyanto', 'Sunar Martiniatun', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(201, '111234040012111013', '3404112102080003', 'Komari', 'Heni M', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(202, '111234040012111039', '3404070802054997', 'Musiyana', 'Suharni', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(203, '111234040012111034', '3403081301100068', 'Adhi Pramono', 'Sumiyatun', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(204, '111234040012111016', '3404070502057627', 'Wakidi', 'Tuminah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(205, '111234040012111045', '3404071601080020', 'Darma Raharja', 'Munasor', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(206, '111234040012111042', '3404120706070016', 'Tohari', 'Khalimah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(207, '111234040012111103', '3404070602050812', 'Andriyana', 'Mulyani', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(208, '111234040012141219', '3404070107080001', 'M. Agus Muchib A', 'Zaefakhatun', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(209, '111234040012111048', '3404072406090013', 'Hari Jumanto', 'Memik Tri Indiarti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(210, '111234040012111022', '3303160503050022', 'Sobar', 'Miswati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(211, '111234040012111023', '3404072202080036', 'Sunarno', 'Marsiti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(212, '111234040012111025', '3404072002080105', 'Suwandiyanto', 'Wiji Lestari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(213, '111234040012111050', '3404071802080126', 'Aswandi', 'Suliastin', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(214, '111234040012111051', '3404072911110008', 'Suratmin', 'Yuni Fandilah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(215, '111234040012111030', '3404071502030051', 'Ponijo', 'Ining Hayati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(216, '111234040012111029', '3404072305070012', 'Navi Riawan', 'Isti Nafingah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(217, '111234040012111035', '3404071507060003', 'Antory', 'Dwi Seipah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(218, '111234040012111010', '3404070602052857', 'Slamet Riyadi', 'Indri Yani', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(219, '111234040012111038', '', 'Jalal', 'Ririn Setyaningsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(220, '111234040012111040', '3404071902080161', 'Mardiyono', 'Fitri Lestari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(221, '111234040012111044', '3404070502056175', 'Legimin', 'Eni Yunita', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(222, '111234040012111019', '3404070602054939', 'Agus Setiyono', 'Rumiyati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(223, '111234040012111018', '3404071609060006', 'Wagino', 'Karsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(224, '111234040012111041', '3404070602056515', 'Madiyana', 'Heni Sukarelawati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(225, '111234040012111046', '3404102110080001', 'Mujtahid', 'Sri Utami', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(226, '111234040012111047', '3404102110080001', 'Muchamad Zaki', 'Nur Alifach', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(227, '111234040012111020', '3404070311100014', 'Yugonoto', 'Siti Chotijah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(228, '111234040012111100', '3404071802080109', 'Nurkholis', 'Sri Waginah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(229, '111234040012111021', '3404072505070028', 'Joko Tri Susanto', 'Suryani', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(230, '111234040012111049', '3404070109070008', 'Ahmad Syafik', 'Sri Puji Astuti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(231, '111234040012111026', '3404070602056158', 'Sugiman', 'Hartini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(232, '111234040012111027', '3404072410080003', 'Sardiyono', 'Sri Sulastri', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(233, '111234040012111028', '3404071506070015', 'Sugeng Riyadi', 'Sri Muryani', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(234, '111234040012100987', '3404072808070035', 'Syamsuddin', 'Muchlisoh', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(235, '111234040012100966', '3404070602054768', 'Pardi', 'Sumini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(236, '111234040012100988', '3404110511070003', 'Slamet', 'Martini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(237, '111234040012100967', '3404070602055153', 'Muh Ma''shum', 'Waridah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(238, '111234040012101157', '', 'Simon Paris', 'Ria Virmala Dewi', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(239, '111234040012100990', '3404071807080031', 'Pantes Bambang Riyanto', 'Pipit Andriyanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(240, '111234040012100969', '3403111101110017', 'Riyanto', 'Sulastri', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(241, '111234040012100974', '3404070208110016', ' Amroini', 'Budiyatmi', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(242, '111234040012100975', '3404072907060003', 'Abdurrohman', 'Rahayu', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(243, '111234040012100977', '3404070502057197', 'Abdul Salam', 'Nur Silah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(244, '111234040012100976', '3404071011070029', 'Jumadi', 'Tri Budiyati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(245, '111234040012100994', '3404070602054579', 'Sugiyanto', 'Nita Lestari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(246, '111234040012100980', '3404070804090001', 'Asep Saepudin', 'Sri Pujilestari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(247, '111234040012100999', '3404112509070005', '', 'Tri Hesti Pertiwi', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(248, '111234040012100983', '3403151511079882', 'Wasno', 'Darsini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(249, '111234040012101003', '3404072601100005', 'Watino', 'Sri Sukanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(250, '111234040012100989', '3404072704060005', 'Wardiyono', 'Muryati', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(251, '111234040012100968', '3404070502057941', 'Ngadiran', 'Sriningsih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(252, '111234040012100991', '3404070602055018', 'Sukarja', 'Yatini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(253, '111234040012100970', '3404111202050501', 'Sutarmin', 'Sumiasih', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(254, '111234040012100971', '3404112002080116', 'Harianto', 'Sri Wahyuni', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(255, '111234040012100972', '3404071201120013', 'Heri Sulistiyo', 'Siti Fatimah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(256, '111234040012100973', '3404072010080016', 'Suwarto', 'Lestari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(257, '111234040012101004', '3404071403080011', 'Rofik', 'Hadiyah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(258, '111234040012100978', '3404071609080005', 'Sujono', 'Sukarni', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(259, '111234040012100995', '3404070602055112', 'Jumari', 'Sri Maryanti', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(260, '111234040012100996', '3471110409020074', 'Mantono', 'Yusfita Handayani', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(261, '111234040012100997', '3404070602054713', 'Sugimin', 'Surani', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(262, '111234040012100982', '3404111208100002', 'Parwoto', 'Samini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(263, '111234040012100984', '3404070602054715', 'Haryanto', 'Siti Fatmah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(264, '111234040012101000', '3404070502055105', 'Muh Muslim', 'Partini', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(265, '111234040012101001', '3404071604070013', 'Suroto ', 'Umi Fajizah', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(266, '111234040012101002', '3404070407070004', 'Dony Aryadi P', 'Yunila Sari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, ''),
(267, '111234040012100986', '3404102411080005', 'Sriyanto', 'Srilestari', '', '0000-00-00', '', '0000-00-00', '', '', 0, '', 0, '', '', '', '', '', '0000-00-00', '', '', '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pembiasaan`
--

CREATE TABLE IF NOT EXISTS `tbl_pembiasaan` (
`id_pembiasaan` int(2) NOT NULL,
  `nama_pembiasaan` varchar(25) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_pembiasaan`
--

INSERT INTO `tbl_pembiasaan` (`id_pembiasaan`, `nama_pembiasaan`) VALUES
(1, 'Shalat Dhuha'),
(2, 'Shalat Berjamaah'),
(3, 'Tadarus Al-Qur''an & BTAQ'),
(4, 'Infaq / Shodaqoh');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_siswa1`
--

CREATE TABLE IF NOT EXISTS `tbl_siswa1` (
  `nis_lokal` varchar(18) NOT NULL,
  `nsm_mi` varchar(12) NOT NULL,
  `madrasah` varchar(10) NOT NULL,
  `alamat` varchar(24) NOT NULL,
  `kecamatan` varchar(5) NOT NULL,
  `nama_siswa` varchar(50) NOT NULL,
  `jk_siswa` varchar(1) NOT NULL,
  `tempat_lahir` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `nis_nasional` varchar(10) NOT NULL,
  `kelas` varchar(2) NOT NULL,
  `alamat_siswa` text NOT NULL,
  `kecamatan_siswa` varchar(15) NOT NULL,
  `kab_kota` varchar(12) NOT NULL,
  `propinsi` varchar(13) NOT NULL,
  `agama` varchar(5) NOT NULL,
  `status_kel` varchar(10) NOT NULL,
  `terima_tgl` date NOT NULL,
  `keterangan` varchar(11) NOT NULL,
  `foto` varchar(60) NOT NULL,
  `username` varchar(18) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_siswa1`
--

INSERT INTO `tbl_siswa1` (`nis_lokal`, `nsm_mi`, `madrasah`, `alamat`, `kecamatan`, `nama_siswa`, `jk_siswa`, `tempat_lahir`, `tanggal_lahir`, `nis_nasional`, `kelas`, `alamat_siswa`, `kecamatan_siswa`, `kab_kota`, `propinsi`, `agama`, `status_kel`, `terima_tgl`, `keterangan`, `foto`, `username`) VALUES
('111234040012100966', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Alfian Dwi Saputra', 'L', 'Sleman', '2003-11-03', '0038237058', '6A', 'Tapanrejo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100966'),
('111234040012100967', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Atiqoh Shofiyatul Chusnaya''in', 'P', 'Sleman', '2004-04-18', '0044514209', '6A', 'Denokan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100967'),
('111234040012100968', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Bima Ray Nur Arya Putra', 'L', 'Sleman', '2004-04-22', '0044514212', '6B', 'Demangan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100968'),
('111234040012100969', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Dian Fery Kurniawan', 'L', 'Klaten', '2003-11-04', '0038237059', '6A', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100969'),
('111234040012100970', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Faizal Ahmad Fadhilah', 'L', 'Sleman', '2003-08-21', '0038237049', '6B', 'Karangsari', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100970'),
('111234040012100971', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Galuh Dhesta Harianto', 'P', 'Sleman', '2004-06-27', '0044514219', '6B', 'Nglarang', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100971'),
('111234040012100972', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ichasia Putri Elita', 'P', 'Sleman', '2003-04-21', '0038237040', '6B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100972'),
('111234040012100973', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ikhwanudien', 'L', 'Klaten', '2004-09-18', '0044514221', '6B', 'Pasekan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100973'),
('111234040012100974', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Isma Syalsa Billa', 'P', 'Sleman', '2003-08-11', '0038237051', '6A', 'Tajem', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100974'),
('111234040012100975', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Khansa Nashafa Salsa Bila', 'P', 'Sleman', '2003-11-17', '0038237060', '6A', 'Denokan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100975'),
('111234040012100976', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Rafli Wahyu', 'L', 'Sleman', '2004-02-05', '0047974216', '6A', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100976'),
('111234040012100977', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Ghufron', 'L', 'Sleman', '2004-03-10', '0044514205', '6A', 'Dewan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100977'),
('111234040012100978', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muh Jibril Maulana', 'L', 'Sleman', '2004-07-24', '0044514220', '6B', 'Gorongan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100978'),
('111234040012100980', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nadia Adelia Novita Sari', 'P', 'Sleman', '2003-11-30', '0044514223', '6A', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100980'),
('111234040012100982', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Putri Aprilia Hapsari', 'P', 'Klaten', '2004-04-02', '0044514208', '6B', 'Niten', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100982'),
('111234040012100983', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ressa Adi Nugroho', 'L', 'Gunungkidul', '2003-12-16', '0038237062', '6A', 'Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100983'),
('111234040012100984', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Sabrina Mutia Kaffa', 'P', 'Sleman', '2004-05-16', '0044514214', '6B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100984'),
('111234040012100986', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Yusuf Rangga Aji Satria', 'L', 'Sleman', '2004-03-05', '0044514204', '6B', 'Puluhdadi', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100986'),
('111234040012100987', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ahmad Muchlishoddin Zainal Musthofa', 'L', 'Sleman', '2004-03-18', '0044514206', '6A', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100987'),
('111234040012100988', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Arif Nuur Hidayat', 'L', 'Sleman', '2003-10-29', '0038237057', '6A', 'Karangsari', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100988'),
('111234040012100989', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Bagas Nur Rohmad', 'L', 'Sleman', '2003-08-26', '0038237050', '6B', 'Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100989'),
('111234040012100990', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Dela Ayu Oktavia', 'P', 'Sleman', '2003-10-03', '0038237054', '6A', 'Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100990'),
('111234040012100991', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Evita Septyarini', 'P', 'Sleman', '2004-09-24', '0044514222', '6B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100991'),
('111234040012100994', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muh Raihan Hidayat', 'L', 'Sleman', '2004-05-25', '0044514216', '6A', 'Jenengan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100994'),
('111234040012100995', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muh Zaenal Akhwan', 'L', 'Sleman', '2003-04-20', '0044514211', '6B', 'Denokan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100995'),
('111234040012100996', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Musa Asadullah', 'L', 'Yogyakarta', '2004-03-24', '0044514207', '6B', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100996'),
('111234040012100997', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nauval Ega Prabaswara', 'L', 'Sleman', '2004-05-23', '0044514215', '6B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100997'),
('111234040012100999', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nurohman Aldika', 'L', 'Yogyakarta', '2003-12-18', '0038237063', '6A', 'Perum Upn', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012100999'),
('111234040012101000', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Salisa Salsabila Muslim', 'P', 'Sleman', '2003-07-15', '0038237048', '6B', 'Onggomerten', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012101000'),
('111234040012101001', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Sofie Nur Alisha', 'P', 'Sleman', '2004-01-06', '0044514200', '6B', 'Singosutan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012101001'),
('111234040012101002', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Vanya Maheswary Yuniar', 'P', 'Yogyakarta', '2004-06-22', '0044514218', '6B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012101002'),
('111234040012101003', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Wredi Egamalia', 'P', 'Sleman', '2004-06-17', '0044514217', '6A', 'Depok', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012101003'),
('111234040012101004', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muh Choharudin', 'L', 'Sleman', '2003-10-18', '0038237056', '6B', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012101004'),
('111234040012101157', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Brian Akbar Putra Aria', 'L', 'Sleman', '2004-03-06', '0045393032', '6A', 'Sopalan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012101157'),
('111234040012111008', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Annisa Nurhanifah', 'P', 'Sleman', '2004-11-12', '0045391121', '5A', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111008'),
('111234040012111010', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Esaka Riyadana', 'L', 'Sleman', '2005-03-11', '0054975843', '5B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111010'),
('111234040012111012', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Fuaz Ahmad Adjar', 'L', 'Sleman', '2005-05-05', '0057430320', '5A', 'Tegalsari', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111012'),
('111234040012111013', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Helen Amellia Madha Ariyani', 'P', 'Sleman', '2005-07-05', '0051625758', '5A', 'Talangrejo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111013'),
('111234040012111016', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Mahendra Wandy Pradana', 'L', 'Sleman', '2005-01-05', '0055393489', '5A', 'Sanggrahan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111016'),
('111234040012111018', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Jafar Sodiq', 'L', 'Sleman', '2005-09-18', '0055735886', '5B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111018'),
('111234040012111019', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad David Setiawan', 'L', 'Sleman', '2005-04-29', '0057442924', '5B', 'Jenengan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111019'),
('111234040012111020', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nia Santika', 'P', 'Yogyakarta', '2005-06-21', '0048915489', '5B', 'Sopalan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111020'),
('111234040012111021', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Raka Rizkisusanto', 'L', 'Sleman', '2005-04-08', '0056920276', '5B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111021'),
('111234040012111022', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rani Gusti Wulan Dari', 'P', 'Purbalingga', '2005-08-01', '0053306105', '5A', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111022'),
('111234040012111023', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ruli Kurniawan', 'L', 'Sleman', '2004-12-23', '0041321147', '5A', 'Corongan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111023'),
('111234040012111024', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rumiati Dyah SP', 'P', 'Sleman', '2004-12-11', '0044586133', '4A', 'Puluhdadi', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111024'),
('111234040012111025', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Shafira Eka Putri', 'P', 'Sleman', '2004-11-18', '0048743849', '5A', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111025'),
('111234040012111026', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Triana Rahmawati', 'P', 'Sleman', '2004-10-07', '0049517418', '5B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111026'),
('111234040012111027', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Velisa Ayu Safitri', 'P', 'Sleman', '2005-06-27', '0057551923', '5B', 'Onggomertan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111027'),
('111234040012111028', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Yoffi Firman Ferdiansyah', 'L', 'Sleman', '2004-09-25', '0046080820', '5B', 'Jenengan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111028'),
('111234040012111029', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ahmad Fikri Fadhillah Romadhon', 'L', 'Sleman', '2004-11-12', '0049937602', '5B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111029'),
('111234040012111030', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Adelia Sinta Deni', 'P', 'Sleman', '2005-04-21', '0052131158', '5B', 'Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111030'),
('111234040012111031', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Adinda Nurdani Elavaldi', 'P', 'Palembang', '2004-09-09', '0045859849', '5A', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111031'),
('111234040012111032', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Annisa Cahya Nabila', 'P', 'Sleman', '2004-11-24', '0045387797', '5A', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111032'),
('111234040012111034', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Litia Sekar Ayu Nindita', 'P', 'Sleman', '2005-07-05', '0059879151', '5A', 'Stan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111034'),
('111234040012111035', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Diva Aditya Eka Ramadhan', 'L', 'Sleman', '2004-10-31', '0042065854', '5B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111035'),
('111234040012111036', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Dhimas Apryza Haryadi', 'L', 'Sleman', '2004-04-18', '0044272750', '5A', 'Sopalan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111036'),
('111234040012111038', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Hafida Fatima Azahra', 'P', 'Sleman', '2005-02-03', '', '5B', 'Paingan, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111038'),
('111234040012111039', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ilham Arief Rachman', 'L', 'Sleman', '2005-01-20', '0054591781', '5A', 'Gorongan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111039'),
('111234040012111040', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Mardiva Putra Kurnia', 'L', 'Boyolali', '2004-09-30', '0047485495', '5B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111040'),
('111234040012111041', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Khamim Satriadhi', 'L', 'Sleman', '2005-04-15', '0058198985', '5B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111041'),
('111234040012111042', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Nur Imam', 'L', 'Sleman', '2004-03-26', '0043320555', '5A', 'Plosokuning V', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111042'),
('111234040012111044', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Akbar Fansyuri', 'L', 'Sleman', '2006-05-27', '0051167256', '5B', 'Nayan Maguwo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111044'),
('111234040012111045', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Hafid A', 'L', 'Sleman', '2005-04-28', '0052481305', '5A', 'Nggorongan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111045'),
('111234040012111046', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nahdiya Laila Nur', 'P', 'Sleman', '2005-06-09', '0053988660', '5B', 'Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111046'),
('111234040012111047', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nayla Shahira', 'P', 'Sleman', '2005-01-14', '0057010081', '5B', 'Mustokorejo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111047'),
('111234040012111048', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Putri Pandan Wangi', 'P', 'Yogjakarta', '2005-04-21', '0058954528', '5A', 'Maguwo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111048'),
('111234040012111049', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Salma Salsabila', 'P', 'Yogyakarta', '2005-02-18', '0052703898', '5B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111049'),
('111234040012111050', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Titis Ayu Rahmadhiani', 'P', 'Sleman', '2004-10-18', '0044245317', '5A', 'Sanggrahan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111050'),
('111234040012111051', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Wahyu Fatiatis Sholikah', 'P', 'Klaten', '2005-09-22', '0056211965', '5A', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111051'),
('111234040012111100', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Putri Sonia', 'P', 'Sleman', '2002-06-23', '0023563369', '5B', 'Sopalan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111100'),
('111234040012111103', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ninda Putri Aiswara', 'L', 'Sleman', '2004-12-11', '0044631355', '5A', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012111103'),
('111234040012121043', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Waafidurrohman', 'L', 'Sleman', '2005-10-23', '0059901302', '4A', 'Pomahan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121043'),
('111234040012121054', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Akbar Qurniawan', 'L', 'Sleman', '2006-03-03', '0065862126', '4A', 'Karangsari', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121054'),
('111234040012121055', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Allea Zahva', 'P', 'Sleman', '2006-06-15', '0064637759', '4A', 'Manisrejo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121055'),
('111234040012121056', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Alya Aurelia Azzahra', 'P', 'Sleman', '2006-01-13', '0066859071', '4A', 'Denokan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121056'),
('111234040012121058', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Aulia Rahmadani', 'P', 'Sleman', '2006-09-27', '0065365107', '4A', 'Corongan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121058'),
('111234040012121059', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ghiska Arna Ramadani', 'P', 'Sleman', '2005-10-15', '0053896074', '4A', 'Sombomerten', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121059'),
('111234040012121060', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Iin Laila Zakiyatunisa', 'P', 'Sleman', '2006-01-23', '0066148420', '4A', 'Nanggulan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121060'),
('111234040012121062', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Inno Centya Ashshabrina', 'P', 'Sleman', '2005-07-17', '0051228135', '4A', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121062'),
('111234040012121063', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Melda Indriya Eka P', 'P', 'Sleman', '2006-04-29', '0064629251', '4A', 'Kradenan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121063'),
('111234040012121064', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Irsyadul Faqih', 'L', 'Sleman', '2006-02-20', '0066512592', '4A', 'Kregan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121064'),
('111234040012121066', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Isnan Rizqy M.', 'L', 'Sleman', '2005-12-01', '0053707510', '4A', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121066'),
('111234040012121068', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Rizky Mardiono', 'L', 'Sleman', '2006-03-25', '0069224181', '4A', 'Maguwo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121068'),
('111234040012121069', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Narra Satya Ramadhani', 'P', 'Sleman', '2005-11-22', '0058427074', '4A', 'Sombomerten', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121069'),
('111234040012121070', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nazula Choirunnisa R', 'P', 'Sleman', '2005-10-09', '0053187260', '4A', 'Karangsari', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121070'),
('111234040012121071', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nurul Hanifah Widyastuti', 'P', 'Sleman', '2005-05-23', '0054924649', '4A', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121071'),
('111234040012121072', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rahmat Munnadi Nur H.', 'L', 'Sleman', '2005-12-02', '0053718652', '4A', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121072'),
('111234040012121074', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rino Febrian', 'L', 'Sleman', '2006-02-18', '0063712376', '4A', 'Sanggrahan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121074'),
('111234040012121075', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Syarifah', 'P', 'Sleman', '2005-07-26', '0058228998', '4A', 'Tapan', 'kalasan', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121075'),
('111234040012121076', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Zidna Halim Ramadhan', 'L', 'Sleman', '2006-10-11', '0062570149', '3A', 'Corongan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121076'),
('111234040012121077', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Alisya Putri Arvina', 'P', 'Sleman', '2006-06-20', '0069912582', '4B', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121077'),
('111234040012121078', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ardian Kelvin Saputra', 'L', 'Jakarta', '2006-03-27', '0063687316', '4B', 'Tapan', 'kalasan', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121078'),
('111234040012121079', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Daud Satria Winasis', 'L', 'Sleman', '2006-03-30', '0069451944', '4B', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121079'),
('111234040012121080', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Deni Amran Saputra', 'L', 'Sleman', '2006-01-21', '0068068895', '4B', 'Nglarang', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121080'),
('111234040012121081', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Dewi Aulia Rahmawati', 'P', 'Sleman', '2006-09-17', '0062560160', '4B', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121081'),
('111234040012121082', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Dina Nafisa', 'P', 'Yogya', '2006-01-05', '0052953311', '4B', 'Babadan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121082'),
('111234040012121083', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Eka Afianti', 'P', 'Klaten', '2006-12-13', '0062753736', '4B', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121083'),
('111234040012121084', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Fadhillah Ramadani', 'P', 'Sleman', '2006-07-29', '0062892006', '4B', 'Garan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121084'),
('111234040012121085', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Fanika Agra Famelia Putri', 'P', 'Sleman', '2005-08-10', '0054456315', '4B', 'Sopalan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121085'),
('111234040012121086', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ferlita Alesya Susanto', 'P', 'Gunungkidul', '2005-10-15', '0052757345', '4B', 'Krodan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121086'),
('111234040012121087', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Hana Lutfiah Dewi Asyastuti', 'P', 'Sleman', '2005-05-23', '0051182767', '4B', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121087'),
('111234040012121088', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Hanis Ragita Cahyani', 'P', 'Sleman', '2006-06-07', '0062568481', '4B', 'Rejosari', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121088'),
('111234040012121090', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Husam Perwira Syaddad', 'L', 'Sleman', '2006-02-16', '0063417523', '4B', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121090'),
('111234040012121093', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Yossi Saputra', 'L', 'Sleman', '2004-04-28', '0046661335', '4B', 'Maguwo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121093'),
('111234040012121094', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Novita Yunia Sari', 'P', 'Sleman', '2006-06-30', '0066777445', '4B', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121094'),
('111234040012121095', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nur Layli Shy Shya Jari', 'P', 'Sleman', '2005-11-19', '0057161336', '3B', 'Pugeran', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121095'),
('111234040012121096', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Putra Wibowo', 'L', 'Sleman', '2006-11-09', '0058474336', '4B', 'Mancasan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121096'),
('111234040012121097', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Reza Putra Darmawan', 'L', 'Sleman', '2006-04-12', '0061060368', '4B', 'Gandekan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121097'),
('111234040012121098', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rifaul Mahmudah', 'P', 'Sleman', '2006-03-19', '0067236542', '4B', 'Kepuhsari', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121098'),
('111234040012121099', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Sofia Adilla Hibana Yusuf', 'P', 'Sleman', '2006-02-03', '0061917049', '4B', 'Sanggrahan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121099'),
('111234040012121105', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Fadzli Alghifari', 'L', 'Jakarta', '2006-02-14', '0068570857', '4B', 'Jl Babarsari TB 17 20 C', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012121105'),
('111234040012131107', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Afif Multazamah', 'P', 'Sleman', '2006-08-03', '0066640934', '3A', 'Pomahan Krodan RT 9 RW 6 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131107'),
('111234040012131108', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ahmad Khozin', 'L', 'Bojonegoro', '2006-05-05', '0069805621', '3A', 'Kepuhsari Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131108'),
('111234040012131109', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Barron Vicholas', 'L', 'Sleman', '2006-12-20', '0068431572', '3A', 'Nglarang Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131109'),
('111234040012131110', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Dheni Ramadhani', 'L', 'Cirebon', '2006-09-30', '0062138612', '3A', 'Karangsari Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131110'),
('111234040012131111', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Dwi Nur Atika Sari', 'P', 'Sleman', '2007-09-20', '0077383063', '3A', 'Kepuhsari Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131111'),
('111234040012131113', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Farah Faida Fais', 'P', 'Sleman', '2007-03-13', '0071949925', '3A', 'Sembego, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131113'),
('111234040012131114', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Fawwazul Amin', 'L', 'Sleman', '2007-01-19', '0072874930', '3A', 'Tegalrejo RT 5 RW 2 Tamanmartani', 'Kalasan', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131114'),
('111234040012131115', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Hurun`in', 'P', 'Kediri', '2006-12-02', '0064768985', '3A', 'Dewan RT 1 RW 22', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131115'),
('111234040012131116', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Intan Ayu Amin Azzahra', 'P', 'Sleman', '2006-10-31', '0065284935', '3A', 'Pomahan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131116'),
('111234040012131117', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Kaila Aulia Lathifa', 'P', 'Sleman', '2007-08-24', '0073532161', '3A', 'Pomahan RT 8 RW 6 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131117'),
('111234040012131119', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Mezula Ceria Agasta', 'P', 'Sleman', '2007-08-22', '0078148672', '3A', 'Karangnongko RT 10 RW 12 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131119'),
('111234040012131121', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Ar Robbi`u', 'L', 'Lamongan', '2007-04-08', '0079576875', '3A', 'Pugeran Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131121'),
('111234040012131122', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Faiz Pasya Fitrawan', 'L', 'Sleman', '2006-10-25', '0062184842', '3A', 'Jenengan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131122'),
('111234040012131123', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Farel Kurniawan', 'L', 'Sleman', '2007-04-29', '0071442430', '3A', 'Jenengan RT 3 RW 8 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131123'),
('111234040012131124', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Rifa`i', 'L', 'Karanganyar', '2006-08-15', '0061346636', '3A', 'Karangsari RT 6 RW 31 Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131124'),
('111234040012131125', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Rifki Pratama', 'L', 'Bojonegoro', '2006-05-05', '0062355754', '3A', 'Depok RT 5 RW 47 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131125'),
('111234040012131126', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nur Ramadhani Saputra', 'L', 'Sleman', '2006-10-20', '0069566967', '3A', 'Maguwo RT 2 RW 45', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131126'),
('111234040012131128', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rafli Surya Pratama', 'L', 'Sleman', '2006-06-12', '0063413564', '3A', 'Gandekan Nayan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131128'),
('111234040012131129', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Revalino Yulian', 'L', 'Kuningan', '2007-07-30', '0079651494', '3A', 'Karangnongko Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131129'),
('111234040012131130', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Surya Eksanudin', 'L', 'Sleman', '2006-06-19', '0062890649', '3A', 'Karangnongko RT 8 RW 13 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131130'),
('111234040012131131', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Aditya Pamungkas', 'L', 'Sleman', '2007-04-07', '0077957540', '3B', 'Jl. Tajem Perum Taman Anggrek Tajem', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131131'),
('111234040012131132', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ahmad Ferdi Aji Saputra', 'L', 'Magelang', '2007-01-20', '0074200330', '3B', 'Perum Cassa grande Kluster Andaluasi No 228', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131132'),
('111234040012131133', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Akbar Risky Faturrahman Suseno', 'L', 'Sleman', '2007-01-28', '0078782573', '3B', 'Sarirejo RT 6 RW 47 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131133'),
('111234040012131134', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Alfian Ghani Saputra', 'L', 'Sleman', '2007-02-10', '0079670206', '3B', 'Karangnongko RT 6 RW 13, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131134'),
('111234040012131135', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Alvino Shevara Alfaruqi', 'L', 'Surakarta', '2007-01-31', '0078728269', '3B', 'Jl. Nangka gg. Mlati RT 2 RW 11 Sanggrahan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131135'),
('111234040012131136', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Andre Setiawan', 'L', 'Blitar', '2007-06-11', '0078935700', '3B', 'Taman Cemara G-12 Krodan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131136'),
('111234040012131137', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Annisa Wahyu Prastiwi', 'P', 'Sleman', '2007-01-28', '0074575909', '3B', 'Jl.Nangka 1 No 167 RT 9 RW 14 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131137'),
('111234040012131138', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Augus Atoillah Siddiq', 'L', 'Magelang', '2005-08-28', '0058966025', '3B', 'Puluhdadi RT 9RW 2 Seturan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131138'),
('111234040012131139', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Auzi''ni Hilyata Firdausy', 'P', 'Klaten', '2007-04-26', '0071201650', '3B', 'Dabag, Condongcatur', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131139'),
('111234040012131141', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Choirul Aziz Ramadhani', 'P', 'Gunungkidul', '2007-09-25', '0071684744', '3B', 'Jl. Nangka 2 No 9 Karangnongko, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131141'),
('111234040012131142', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Dedek Agus Wicaksono', 'L', 'Magetan', '2006-08-10', '0064939084', '3B', 'Jl.Puri Permata No 19 Condongcatur', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131142'),
('111234040012131143', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Dinda Ramadani Syahfitri', 'P', 'Sleman', '2006-10-06', '0067717436', '3B', 'Pugeran Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131143'),
('111234040012131144', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Fatimah Nur Hidayah', 'P', 'Sleman', '2007-04-12', '0079660329', '3B', 'Karangnongko RT 8 RW 13 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131144'),
('111234040012131145', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Halimah Fitri Cahyani', 'P', 'Gunungkidul', '2007-07-09', '0077538177', '3B', 'Pugeran lor Jl. Tasura RT 11 RW 10', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131145'),
('111234040012131146', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Izdihar Muna Hidayat ', 'P', 'Sleman', '2007-04-06', '0077937450', '3B', 'Perum Sinar Surya Idaman No 30 Gandok 03/24 Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131146'),
('111234040012131147', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Karunia Salsa Fadhila', 'P', 'Sleman', '2008-03-10', '0081040669', '3B', 'Karangnongko Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131147'),
('111234040012131148', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Furqon Kamil Gibran', 'L', 'Sleman', '2007-11-03', '0073184373', '3B', 'Bedrek RT 9 RW 41 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131148'),
('111234040012131149', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Rafi Anshory', 'L', 'Sleman', '2006-04-25', '0061573480', '3B', 'Perum Pertamina Blok R-02 Purwomartani', 'kalasan', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131149'),
('111234040012131150', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Wahyu Bima Saputra', 'L', 'Sleman', '2007-04-09', '0077180597', '3B', 'Pengarep, Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131150'),
('111234040012131151', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Mustafa Alanshory', 'L', 'Sleman', '2006-01-17', '0065965685', '3B', 'Maguwo Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131151'),
('111234040012131153', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rifa`i Arbiyansyah', 'L', 'Sleman', '2006-06-14', '0062410796', '3B', 'Sanggrahan RT 4 RW 12 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131153'),
('111234040012131154', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Uyyun Khifti Adjar', 'P', 'Sleman', '2007-08-14', '0076914965', '3B', 'Tegalsari Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012131154'),
('111234040012141158', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Amey Visnu Dhea', 'P', 'Magelang', '2007-04-05', '0074579446', '2A', 'Puluhdadi RT. 12 RW. 9 Seturan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141158'),
('111234040012141159', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Arlita Ramadhani', 'P', 'Sleman', '2007-10-02', '0076458738', '2A', 'Sarirejo, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141159'),
('111234040012141160', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Arsela Azzahra Hidayati', 'P', 'Sleman', '2007-06-07', '0072236665', '2A', 'Maguwo, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141160'),
('111234040012141161', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Attan Satria Wicaksana', 'L', 'Yogyakarta', '2008-04-18', '0082100701', '2A', 'Karangnongko, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141161'),
('111234040012141162', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Boshevie Faiz Nastiti', 'P', 'Yogyakarta', '2008-04-24', '0083091195', '2A', 'Nayan RT. 3 RW. 25 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141162'),
('111234040012141164', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Dzikrina Nurul Qolbi', 'P', 'Surakarta', '2007-10-08', '0072650408', '2A', 'Jl. Nangka IV No. 141 RT. 8/13 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141164'),
('111234040012141165', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Faidah Hidayah Riskayaning Fitri', 'P', 'Sleman', '2007-10-14', '0077478698', '2A', 'Cawisan, Banaran RT. 3 RW. 34 Argomulyo', 'Cangkringan', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141165'),
('111234040012141166', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Fauziah Salsabila', 'P', 'Yogyakarta', '2007-11-19', '0077232141', '2A', 'Denokan, Garan RT. 5 RW. 2 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141166'),
('111234040012141167', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Hendra Dwi Pamungkas', 'L', 'Sleman', '2008-03-24', '0086569203', '2A', 'Rejosari Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141167'),
('111234040012141168', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ibnu Wahyu Nugroho', 'L', 'Sleman', '2007-12-22', '0079518404', '2A', 'Malangrejo RT. 22 RW. 33 Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141168'),
('111234040012141169', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ika Indah Agustin Rahma Nur Anisa', 'P', 'Sleman', '2008-08-26', '0081691172', '2A', 'Jl. Paingan I RT.6/05 No. 117 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141169'),
('111234040012141170', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Luk Luk Mutmainah', 'P', 'Sleman', '2007-09-03', '0078347286', '2A', 'Tapan RT 1 RW 1 karanglo Purwomartani', 'Kalasan', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141170');
INSERT INTO `tbl_siswa1` (`nis_lokal`, `nsm_mi`, `madrasah`, `alamat`, `kecamatan`, `nama_siswa`, `jk_siswa`, `tempat_lahir`, `tanggal_lahir`, `nis_nasional`, `kelas`, `alamat_siswa`, `kecamatan_siswa`, `kab_kota`, `propinsi`, `agama`, `status_kel`, `terima_tgl`, `keterangan`, `foto`, `username`) VALUES
('111234040012141171', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Malik Abdul Aziz', 'L', 'Gunungkidul', '2007-12-29', '0073027163', '2A', 'Karangsari RT. 3 RW 32 Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141171'),
('111234040012141172', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Achsin Qubailal Fajri', 'L', 'Blitar', '2007-04-26', '0071996327', '2A', 'Demangan RT.2 RW. 20 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141172'),
('111234040012141173', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Ahsan Sanadi', 'L', 'Sleman', '2008-01-20', '0084591155', '2A', 'Perum Pertamina Blok R-2 Purwomartani', 'Kalasan ', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141173'),
('111234040012141174', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Fahmi Amruloh', 'L', 'Sleman', '2007-06-13', '0079672961', '2A', 'Jl. Nangka No. 23 Ngringin Condongcatur', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141174'),
('111234040012141175', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Mirza Rafiq Ramadhan Purwanto', 'L', 'Sleman', '2008-06-30', '0088187195', '2A', 'Tajem RW. 2 RW. 30 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141175'),
('111234040012141176', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Restu Aji', 'L', 'NGAWI', '2008-04-03', '0083867448', '2A', 'Karangnongko RT. 10 RW 14 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141176'),
('111234040012141177', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Risqi Nurrochim', 'L', 'Sleman', '2008-05-24', '0082838607', '2A', 'Karanganyar, Widodomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141177'),
('111234040012141178', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rahmatia Fadila', 'P', 'Sleman', '2007-08-12', '0073567233', '2A', 'Karangnongko, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141178'),
('111234040012141179', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rakha Adhinata Irhab', 'L', 'Sleman', '2008-05-19', '0085013608', '2A', 'Sanggrahan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141179'),
('111234040012141180', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rhayhana Yattusyifa', 'L', 'Yogyakarta', '2008-04-28', '0089007787', '2A', 'Sanggrahan RT 2 RW 11 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141180'),
('111234040012141181', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Sarah Khoirunisa Latifa Zahra', 'P', 'Sleman', '2007-10-03', '0077750891', '2A', 'Sombomerten Demangan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141181'),
('111234040012141182', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Saskia Rafa Fadhilla', 'P', 'Sleman', '2008-03-15', '0089559408', '2A', 'Surirejo Sukoharjo Ngaglik', 'Ngaglik', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141182'),
('111234040012141183', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Syifa Setyo Putri', 'P', 'Sleman', '2008-04-29', '0086090641', '2A', 'Krodan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141183'),
('111234040012141184', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Wahyu Mentari Januari Jari', 'P', 'Sleman', '2008-01-29', '0089255684', '2A', 'Pugeran Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141184'),
('111234040012141185', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Zaki Ahmad Wahono', 'L', 'Sleman', '2008-05-12', '0089556537', '2A', 'Jl. Nangka III No 146 Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141185'),
('111234040012141186', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Zaydan Aliviansyah Al Ghani ', 'L', 'Wonosobo', '2008-05-09', '0082948951', '2A', 'Jl. Nangka V No 96 Sanggrahan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141186'),
('111234040012141187', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Abdul Aziz', 'L', 'Sleman', '2008-08-21', '0088632431', '2B', 'Gandok RT 4 RW 25 Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141187'),
('111234040012141188', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Abimatrana Pandu Pinilih', 'L', 'Sleman', '2008-03-31', '0081003019', '2B', 'Tambakbayan III No 10', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141188'),
('111234040012141189', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Adilla Rizqi Ramadhani', 'P', 'Klaten', '2007-09-12', '0078039582', '2B', 'Pasekan, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141189'),
('111234040012141190', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ahmad Said Chasanal Basri', 'L', 'Sleman', '2007-06-19', '0073879027', '2B', 'Denokan RT 3 RW 63 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141190'),
('111234040012141191', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Amanda Salsabila', 'P', 'Sleman', '2008-03-15', '0084360809', '2B', 'Pugeran RT 10 RW 64 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141191'),
('111234040012141192', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Anandika Bima Wirajati Putra', 'L', 'Sleman', '2008-04-29', '0081201712', '2B', 'Plosokuning IV RT 18 RW 7 No. 80 Minomartani', 'Ngaglik', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141192'),
('111234040012141193', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Andika Permana Putra', 'L', 'Sleman', '2008-03-04', '0082110576', '2B', 'Sanggrahan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141193'),
('111234040012141194', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Aushaf Zaidah Nur', 'P', 'Sleman', '2008-07-16', '0082809499', '2B', 'Perum Sinar Surya Idaman No. 31 Sempu, Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141194'),
('111234040012141195', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Daania Putri Hasna Az Zahra', 'P', 'Karanganyar', '2007-10-22', '0073686622', '2B', 'Jabung RT 5 RW 2 Berbah', 'Berbah', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141195'),
('111234040012141196', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Diva Anggraini Purba Kencana', 'P', 'Gunungkidul', '2008-03-21', '0081392230', '2B', 'Karangnongko RT 7 RW 13 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141196'),
('111234040012141197', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Febriana Damayanti', 'P', 'Sleman', '2008-02-28', '0083955844', '2B', 'Karang Kalasan RT 6 RW 7 Tirtomartani', 'Kalasan', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141197'),
('111234040012141198', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Hanif Zahran Qurohman', 'L', 'Sleman', '2008-09-17', '0088623305', '2B', 'Sanggrahan RT 2 RW 11 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141198'),
('111234040012141199', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Karunia Putri Rahayu', 'P', 'Sleman', '2008-07-22', '0085141215', '2B', 'Karangnongko Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141199'),
('111234040012141200', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Kusnia Lailatul Karim', 'P', 'Gunungkidul', '2008-05-16', '0083218072', '2B', 'Paingan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141200'),
('111234040012141201', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Laudza Vira Dhiyaul Khaq', 'P', 'Yogyakarta', '2008-07-24', '0087422275', '2B', 'Jl. Jenengan Raya RT 1 RW 7 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141201'),
('111234040012141202', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Latifa Puspitasari', 'P', 'Gunungkidul', '2007-09-26', '0078170534', '2B', 'Stan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141202'),
('111234040012141203', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Mailatul Hasanah', 'P', 'Surabaya', '2007-11-15', '0073800412', '2B', 'Demangan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141203'),
('111234040012141204', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Melani Puspita Wulandari', 'P', 'Sleman', '2008-05-06', '0088557547', '2B', 'Pomahan Krodan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141204'),
('111234040012141205', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Ashraf Maulana', 'L', 'Sleman', '2008-03-03', '0884040280', '2B', 'Onggomerten RT 6/26 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141205'),
('111234040012141206', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Tajlibur Rizqi', 'L', 'Sleman', '2008-07-11', '0083395711', '2B', 'Tambakan RT 1 RW 19 Sinduharjo', 'Ngaglik', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141206'),
('111234040012141207', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Zakiy', 'L', 'Boyolali', '2008-09-05', '0085170124', '2B', 'Karangnongko RT 11 RW 14 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141207'),
('111234040012141208', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Zidan Yasin', 'L', 'Sleman', '2007-09-25', '0071629874', '2B', 'Palgading Sinduharjo ', 'Ngaglik', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141208'),
('111234040012141209', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Praditya Kirana', 'L', 'Bantul', '2008-10-13', '0082343030', '2B', 'Maguwo Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141209'),
('111234040012141210', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Putri Nur Setyowati', 'P', 'Sleman', '2007-11-10', '0072112286', '2B', 'Karangnongko Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141210'),
('111234040012141211', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Raya Ari Desvita', 'P', 'Sleman', '2007-12-22', '0079196714', '2B', 'Tambakbayan 3 No 13A Caturtunggal', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141211'),
('111234040012141212', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Saninatun Najjah', 'P', 'Yogyakarta', '2008-01-15', '0084153763', '2B', 'Pugeran RT 9 RW 65 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141212'),
('111234040012141213', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Talitha Aulia Rahma', 'P', 'Malang', '2008-06-13', '0084962395', '2B', 'Jl Pugeran 3 No 24 RT 8 RW 10 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141213'),
('111234040012141214', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Tyan Desti Anjani', 'P', 'Sleman', '2007-12-30', '0072796661', '2B', 'Sanggrahan Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141214'),
('111234040012141215', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Vandy Mahesa Yuniar', 'L', 'Yogyakarta', '2007-09-29', '0071387391', '2B', 'Karangnonko,Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141215'),
('111234040012141216', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Viviana Dewi Rengganis', 'P', 'Sleman', '2008-04-09', '0082660841', '2B', 'Berbah RT 2 RW 1 Kalitirto', 'Berbah', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141216'),
('111234040012141217', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Maulidin Shodiq', 'L', 'Pekalongan', '2006-10-04', '0063676008', '3A', 'Denokan RT 1 RW 1 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141217'),
('111234040012141219', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Noor Syifa Aini', 'P', 'Mataram', '2005-10-09', '0055855747', '5A', 'Karangnongko', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012141219'),
('111234040012151221', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'M. Rafli', 'L', 'Banjarnegara', '2006-06-29', '', '3B', 'Sopalan, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151221'),
('111234040012151222', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Alfi Akbar Maulana', 'L', 'Sleman', '2008-04-09', '', '1A', 'Maguwo RT02/RW45 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151222'),
('111234040012151223', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ardiansyah Bekti Panuntun', 'L', 'Sleman', '2008-09-06', '', '1A', 'Sanggrahan, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151223'),
('111234040012151224', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Arvhia Ika Ramadhani', 'P', 'Sleman', '2008-09-18', '', '1A', 'Karangnongko, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151224'),
('111234040012151225', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Atina Kiyasa Asshofiya', 'P', 'Magelang', '2009-03-11', '', '1A', 'Pugeran, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151225'),
('111234040012151226', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Cantika Wijaya Purnamasari', 'P', 'Sleman', '2009-09-15', '', '1A', 'Karangnongko, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151226'),
('111234040012151227', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Cheesa Adelia Putri', 'P', 'Sleman', '2009-03-08', '', '1A', 'Malangrejo RT03/RW34', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151227'),
('111234040012151228', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Defrizal Safian Wardhana', 'L', 'Sleman', '2008-12-15', '', '1A', 'Karangnongko, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151228'),
('111234040012151229', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Hanif Muhammad Al-Fatih', 'L', 'Sleman', '2009-07-21', '', '1A', 'Perum Candi Gebang DD-3', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151229'),
('111234040012151230', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Ikhsan Zein', 'L', 'Sleman', '2008-10-06', '', '1A', 'Losari I Rt004/Rw006 Wukirharjo', 'Prambanan', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151230'),
('111234040012151231', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Mohammad Aji Ali', 'L', 'Sampang', '2009-01-23', '', '1A', 'Tajem, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151231'),
('111234040012151232', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Zaki Abdillah', 'L', 'Magelang', '2009-01-19', '', '1A', 'Tapanrejo RT 10 RW 93 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151232'),
('111234040012151233', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nasywa Azaria  Putri', 'P', 'Sleman', '2008-12-27', '', '1A', 'Karangasem, Gempol Rt05/12', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151233'),
('111234040012151234', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Naura Lathifa Nur''aini', 'P', 'Sleman', '2009-01-28', '', '1A', 'Sombomerten, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151234'),
('111234040012151235', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nisrina Juwita Anggraini', 'P', 'Sleman', '2009-08-10', '', '1A', 'Sombomerten, Demangan', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151235'),
('111234040012151236', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nur Aida Lathif Munawaroh', 'P', 'Sleman', '2009-03-10', '', '1A', 'Sanggrahan, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151236'),
('111234040012151237', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nur Aziz', 'L', 'Sleman', '2008-12-05', '', '1A', 'Garan, Denokan, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151237'),
('111234040012151238', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nur Dea Amalia', 'P', 'Lampung Timur', '2009-06-02', '', '1A', 'Bulus Kulon, smbersari, jetis Bantul', 'Jetis', 'Bantul', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151238'),
('111234040012151239', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nur Latifatun Nisa', 'P', 'Sleman', '2008-12-17', '', '1A', 'Karangnongko, RT10/14 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151239'),
('111234040012151240', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nur Yulianti', 'P', 'Yogyakarta', '2008-07-04', '', '1A', 'Maguwo, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151240'),
('111234040012151241', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Raka Bagus Dwi Saputra', 'L', 'Sleman', '2008-10-13', '', '1A', 'Jl.Perkutut 15 Demangan Baru', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151241'),
('111234040012151242', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Reno Septian Wara Di', 'L', 'Maumere', '2008-09-20', '', '1A', 'Karangnongko, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151242'),
('111234040012151243', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rifai Maulana Putra', 'L', 'Sleman', '2008-11-15', '', '1A', 'Kemloko, Caturharjo', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151243'),
('111234040012151244', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Salfa Ardelia Vero', 'P', 'Palembang', '2009-10-11', '', '1A', 'Nayan RT004/RW025 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151244'),
('111234040012151245', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Umaira Nurul Maulida', 'P', 'Sleman', '2009-08-21', '', '1A', 'Pomahan, maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151245'),
('111234040012151246', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Willya Alifah Calysta', 'P', 'Ponorogo', '2008-03-29', '', '1A', 'Karangasem', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151246'),
('111234040012151247', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Aisha Nur Hidayah', 'P', 'Sleman', '2008-07-31', '', '1B', 'Pugeran RT10/RW64 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151247'),
('111234040012151248', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Al Zahra Aima Latifah', 'P', 'Wonosari', '2009-07-11', '', '1B', 'Karanngsari, Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151248'),
('111234040012151249', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Benadzir Marwa Kuniya', 'P', 'Grobogan', '2009-04-06', '', '1B', 'Pasekan RT21/40 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151249'),
('111234040012151250', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Chelsea Cheva Prasetyo', 'L', 'Tangerang', '2008-04-23', '', '1B', 'Sanggrahan, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151250'),
('111234040012151251', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Dwiki Ikhsan Ramadhani', 'L', 'Brebes', '2008-10-03', '', '1B', 'Karangnongko, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151251'),
('111234040012151252', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Egan Ezra Athallah Syam', 'L', 'Sleman', '2008-11-16', '', '1B', 'Onggomertan RT7/RW26 Nayan Mgw', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151252'),
('111234040012151253', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Fahrizal Jovan Al Farizi', 'L', 'Sleman', '2008-10-30', '', '1B', 'Tajem, Mauwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151253'),
('111234040012151254', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Intan Maharani Putri Irawan', 'P', 'Sleman', '2009-05-02', '', '1B', 'Jetis RT02/RW48 Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151254'),
('111234040012151255', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Khustama Ahsanul Putra', 'L', 'Sleman', '2009-05-06', '', '1B', 'Onggomertan RT6/RW26 Nayan Mgw', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151255'),
('111234040012151256', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Fahri  Dwi Nugroho', 'L', 'Sleman', '2008-05-03', '', '1B', 'Karangnongko, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151256'),
('111234040012151257', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Haddad Yassar', 'L', 'Indramayu', '2008-07-25', '', '1B', 'Randusari RT06/RW03 Kalasan', 'Kalasan', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151257'),
('111234040012151258', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Irsyaddul Ngibad', 'L', 'Sleman', '2009-04-17', '', '1B', 'Pugeran RT04/RW09 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151258'),
('111234040012151259', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muhammad Novandra Kurniawan', 'L', 'Sleman', '2008-11-07', '', '1B', 'Sanggrahan, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151259'),
('111234040012151260', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Muwafiq Hawari Muhammad', 'L', 'Sleman', '2008-05-11', '', '1B', 'Tapanrejo, Maguwoharjoi', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151260'),
('111234040012151261', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Naila Nafisa Putri', 'P', 'Sleman', '2009-03-21', '', '1B', 'Tapanrejo, Maguwoharjoi', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151261'),
('111234040012151262', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Phiyo Pahlevi', 'L', 'sleman', '2010-03-06', '', '1B', 'Karangnongko, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151262'),
('111234040012151263', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Putri Eka Nur Setyanti', 'P', 'Sleman', '2009-04-22', '', '1B', 'Sorogenen II Purwomartani', 'Kalasan', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151263'),
('111234040012151264', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rasiekh Reksadama', 'L', 'Bantul', '2010-03-21', '', '1B', 'Rusunawa Polda DIY', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151264'),
('111234040012151265', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Riska', 'P', 'Cilacap', '2008-07-28', '', '1B', 'Karangnongko, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151265'),
('111234040012151266', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Rasha Noor Ramadhan', 'L', 'Karanganyar', '2008-08-31', '', '1B', 'Depok RT5/47 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151266'),
('111234040012151267', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Sintia Dinda Arum Cahyatinda', 'P', 'Sleman', '2009-02-10', '', '1B', 'Jenengan, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151267'),
('111234040012151268', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Zakky Dhiyatulhaq', 'L', 'Sleman', '2008-10-04', '', '1B', 'Jetis,Perum Candi Indah P1, Wedomartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151268'),
('111234040012151269', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Frederick Musyaffa Harlin Khananta', 'L', 'Magelang', '2008-04-07', '', '2A', 'Rumah Dinas POLDA DIY (Rusun Maguwo)', 'Depok', 'Sleman', 'DIY', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151269'),
('111234040012151270', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Zahra Andinita', 'P', 'Sleman', '2007-01-03', '0074796077', '2A', 'Pugeran, Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151270'),
('111234040012151271', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Elsa Dhitanafeilla Ramadhani', 'P', 'Yogyakarta', '2007-09-20', '', '3A', 'Babrik, Stan RT03/43 Maguwoharjo', 'Depok', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151271'),
('111234040012151272', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Fikri Tahara Fawwas Firjatullah', 'L', 'Sleman', '2005-04-06', '0066162682', '3B', 'Ngemplak asem, Umbulmartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151272'),
('111234040012151273', '111234040012', 'MI Al Huda', 'Karangnongko Maguwoharjo', 'Depok', 'Nandia Adinda Maika', 'P', 'Sleman', '2008-05-16', '', '2B', 'Bokesan, Sindumartani', 'Ngemplak', 'Sleman', 'DI Yogyakarta', 'ISLAM', 'Belum Disi', '0000-00-00', 'AKTIF', 'Belum Ada', '111234040012151273');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tahfid_doa`
--

CREATE TABLE IF NOT EXISTS `tbl_tahfid_doa` (
`id_tahfid_doa` int(2) NOT NULL,
  `nama_doa` varchar(15) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tbl_tahfid_doa`
--

INSERT INTO `tbl_tahfid_doa` (`id_tahfid_doa`, `nama_doa`) VALUES
(1, 'Al-Fatihah'),
(2, 'An-Naas'),
(3, 'Al-Falaq'),
(4, 'Al-Ikhlas'),
(5, 'Al-Lahab'),
(6, 'An-Nashr'),
(7, 'Al-Kafirun'),
(8, 'Al-Kautsar'),
(9, 'Al-Maa''uun'),
(10, 'Al-Quraisy'),
(11, 'Al-Fiil'),
(12, 'Al-Humazah'),
(13, 'Al-Ashr'),
(14, 'At-Takaatsur'),
(15, 'Al-Qarari''ah'),
(16, 'Al-Adiyaat'),
(17, 'Al-Zalzalah'),
(18, 'Al-Bayyinah'),
(19, 'Al-Qadr'),
(20, 'Al-Alaq'),
(21, 'At-Tiin'),
(22, 'Alam Nasyrah'),
(23, 'Adh-Dhuhaa'),
(24, 'Al-Lail'),
(25, 'Asy-Syams'),
(26, 'Al-Balad'),
(27, 'Al-Fajr');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_thn_ajaran`
--

CREATE TABLE IF NOT EXISTS `tbl_thn_ajaran` (
`id` int(2) NOT NULL,
  `kode_thn_ajaran` varchar(9) NOT NULL,
  `nama_thn_ajaran` varchar(9) NOT NULL,
  `status` varchar(6) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_thn_ajaran`
--

INSERT INTO `tbl_thn_ajaran` (`id`, `kode_thn_ajaran`, `nama_thn_ajaran`, `status`) VALUES
(1, '2015/2016', '2015/2016', 'Ganjil'),
(2, '2015/2016', '2015/2016', 'Genap'),
(3, '2016/2017', '2016/2017', 'Ganjil');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_login`
--

CREATE TABLE IF NOT EXISTS `tbl_user_login` (
  `nip_nisn` varchar(18) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(5) NOT NULL,
  `password_tampil` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_login`
--

INSERT INTO `tbl_user_login` (`nip_nisn`, `password`, `status`, `password_tampil`) VALUES
('111234040012', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'admin'),
('111234040012100966', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100967', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100968', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100969', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100970', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100971', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100972', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100973', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100974', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100975', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100976', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100977', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100978', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100980', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100982', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100983', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100984', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100986', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100987', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100988', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100989', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100990', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100991', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100994', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100995', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100996', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100997', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012100999', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012101000', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012101001', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012101002', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012101003', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012101004', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012101157', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111008', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111010', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111012', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111013', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111016', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111018', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111019', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111020', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111021', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111022', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111023', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111024', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111025', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111026', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111027', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111028', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111029', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111030', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111031', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111032', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111034', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111035', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111036', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111038', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111039', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111040', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111041', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111042', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111044', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111045', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111046', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111047', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111048', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111049', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111050', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111051', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111100', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012111103', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121043', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121054', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121055', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121056', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121058', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121059', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121060', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121062', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121063', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121064', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121066', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121068', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121069', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121070', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121071', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121072', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121074', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121075', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121076', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121077', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121078', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121079', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121080', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121081', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121082', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121083', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121084', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121085', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121086', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121087', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121088', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121090', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121093', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121094', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121095', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121096', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121097', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121098', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121099', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012121105', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131107', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131108', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131109', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131110', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131111', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131113', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131114', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131115', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131116', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131117', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131119', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131121', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131122', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131123', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131124', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131125', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131126', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131128', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131129', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131130', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131131', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131132', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131133', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131134', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131135', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131136', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131137', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131138', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131139', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131141', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131142', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131143', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131144', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131145', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131146', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131147', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131148', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131149', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131150', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131151', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131153', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012131154', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141158', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141159', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141160', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141161', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141162', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141164', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141165', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141166', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141167', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141168', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141169', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141170', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141171', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141172', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141173', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141174', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141175', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141176', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141177', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141178', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141179', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141180', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141181', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141182', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141183', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141184', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141185', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141186', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141187', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141188', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141189', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141190', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141191', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141192', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141193', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141194', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141195', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141196', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141197', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141198', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141199', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141200', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141201', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141202', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141203', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141204', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141205', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141206', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141207', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141208', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141209', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141210', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141211', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141212', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141213', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141214', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141215', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141216', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141217', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012141219', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151221', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151222', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151223', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151224', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151225', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151226', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151227', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151228', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151229', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151230', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151231', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151232', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151233', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151234', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151235', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151236', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151237', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151238', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151239', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151240', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151241', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151242', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151243', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151244', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151245', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151246', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151247', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151248', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151249', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151250', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151251', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151252', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151253', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151254', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151255', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151256', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151257', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151258', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151259', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151260', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151261', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151262', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151263', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151264', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151265', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151266', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151267', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151268', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151269', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151270', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151271', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151272', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('111234040012151273', 'bcd724d15cde8c47650fda962968f102', 'siswa', 'siswa'),
('20160001', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160002', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160003', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160004', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160005', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160006', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160007', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160008', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160009', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160010', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160011', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160012', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160013', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160014', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160015', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160016', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160017', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru'),
('20160018', '77e69c137812518e359196bb2f5e9bb9', 'guru', 'guru');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_alumni`
--
ALTER TABLE `tbl_alumni`
 ADD PRIMARY KEY (`id_alumni`);

--
-- Indexes for table `tbl_artikel`
--
ALTER TABLE `tbl_artikel`
 ADD PRIMARY KEY (`id_artikel`);

--
-- Indexes for table `tbl_catatan_wali`
--
ALTER TABLE `tbl_catatan_wali`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_ekskul`
--
ALTER TABLE `tbl_ekskul`
 ADD PRIMARY KEY (`id_ekstra`);

--
-- Indexes for table `tbl_galeri`
--
ALTER TABLE `tbl_galeri`
 ADD PRIMARY KEY (`id_galeri`);

--
-- Indexes for table `tbl_guru`
--
ALTER TABLE `tbl_guru`
 ADD PRIMARY KEY (`nomer_pegawai`);

--
-- Indexes for table `tbl_hari`
--
ALTER TABLE `tbl_hari`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_identitas_lembaga`
--
ALTER TABLE `tbl_identitas_lembaga`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_inbox_kontak`
--
ALTER TABLE `tbl_inbox_kontak`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_info`
--
ALTER TABLE `tbl_info`
 ADD PRIMARY KEY (`id_info`);

--
-- Indexes for table `tbl_jadwal_pelajaran`
--
ALTER TABLE `tbl_jadwal_pelajaran`
 ADD PRIMARY KEY (`id_jdwl`);

--
-- Indexes for table `tbl_kehadiran`
--
ALTER TABLE `tbl_kehadiran`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_kelas`
--
ALTER TABLE `tbl_kelas`
 ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `tbl_kenaikan_kls`
--
ALTER TABLE `tbl_kenaikan_kls`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_kepribadian`
--
ALTER TABLE `tbl_kepribadian`
 ADD PRIMARY KEY (`id_kepribadian`);

--
-- Indexes for table `tbl_komentar`
--
ALTER TABLE `tbl_komentar`
 ADD PRIMARY KEY (`id_komentar`);

--
-- Indexes for table `tbl_mapel`
--
ALTER TABLE `tbl_mapel`
 ADD PRIMARY KEY (`id_mapel`);

--
-- Indexes for table `tbl_nilai_kepribadian`
--
ALTER TABLE `tbl_nilai_kepribadian`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_nilai_pembiasaan`
--
ALTER TABLE `tbl_nilai_pembiasaan`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_nilai_pengembangan_diri`
--
ALTER TABLE `tbl_nilai_pengembangan_diri`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_nilai_raport`
--
ALTER TABLE `tbl_nilai_raport`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_nilai_raport_rata`
--
ALTER TABLE `tbl_nilai_raport_rata`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_nilai_rata_kepribadian`
--
ALTER TABLE `tbl_nilai_rata_kepribadian`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_nilai_rata_tid`
--
ALTER TABLE `tbl_nilai_rata_tid`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_nilai_semester`
--
ALTER TABLE `tbl_nilai_semester`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_nilai_tahfid_doa`
--
ALTER TABLE `tbl_nilai_tahfid_doa`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_ortu`
--
ALTER TABLE `tbl_ortu`
 ADD PRIMARY KEY (`id_ortu`);

--
-- Indexes for table `tbl_pembiasaan`
--
ALTER TABLE `tbl_pembiasaan`
 ADD PRIMARY KEY (`id_pembiasaan`);

--
-- Indexes for table `tbl_siswa1`
--
ALTER TABLE `tbl_siswa1`
 ADD PRIMARY KEY (`nis_lokal`);

--
-- Indexes for table `tbl_tahfid_doa`
--
ALTER TABLE `tbl_tahfid_doa`
 ADD PRIMARY KEY (`id_tahfid_doa`);

--
-- Indexes for table `tbl_thn_ajaran`
--
ALTER TABLE `tbl_thn_ajaran`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_login`
--
ALTER TABLE `tbl_user_login`
 ADD PRIMARY KEY (`nip_nisn`), ADD UNIQUE KEY `nip_nisn` (`nip_nisn`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_alumni`
--
ALTER TABLE `tbl_alumni`
MODIFY `id_alumni` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_artikel`
--
ALTER TABLE `tbl_artikel`
MODIFY `id_artikel` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `tbl_catatan_wali`
--
ALTER TABLE `tbl_catatan_wali`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `tbl_ekskul`
--
ALTER TABLE `tbl_ekskul`
MODIFY `id_ekstra` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_galeri`
--
ALTER TABLE `tbl_galeri`
MODIFY `id_galeri` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_hari`
--
ALTER TABLE `tbl_hari`
MODIFY `id` int(1) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_identitas_lembaga`
--
ALTER TABLE `tbl_identitas_lembaga`
MODIFY `id` int(1) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_inbox_kontak`
--
ALTER TABLE `tbl_inbox_kontak`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_info`
--
ALTER TABLE `tbl_info`
MODIFY `id_info` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_jadwal_pelajaran`
--
ALTER TABLE `tbl_jadwal_pelajaran`
MODIFY `id_jdwl` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `tbl_kehadiran`
--
ALTER TABLE `tbl_kehadiran`
MODIFY `id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_kenaikan_kls`
--
ALTER TABLE `tbl_kenaikan_kls`
MODIFY `id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `tbl_kepribadian`
--
ALTER TABLE `tbl_kepribadian`
MODIFY `id_kepribadian` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `tbl_komentar`
--
ALTER TABLE `tbl_komentar`
MODIFY `id_komentar` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `tbl_nilai_kepribadian`
--
ALTER TABLE `tbl_nilai_kepribadian`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=631;
--
-- AUTO_INCREMENT for table `tbl_nilai_pembiasaan`
--
ALTER TABLE `tbl_nilai_pembiasaan`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=249;
--
-- AUTO_INCREMENT for table `tbl_nilai_pengembangan_diri`
--
ALTER TABLE `tbl_nilai_pengembangan_diri`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=311;
--
-- AUTO_INCREMENT for table `tbl_nilai_raport`
--
ALTER TABLE `tbl_nilai_raport`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=259;
--
-- AUTO_INCREMENT for table `tbl_nilai_raport_rata`
--
ALTER TABLE `tbl_nilai_raport_rata`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `tbl_nilai_rata_kepribadian`
--
ALTER TABLE `tbl_nilai_rata_kepribadian`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `tbl_nilai_rata_tid`
--
ALTER TABLE `tbl_nilai_rata_tid`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `tbl_nilai_semester`
--
ALTER TABLE `tbl_nilai_semester`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=249;
--
-- AUTO_INCREMENT for table `tbl_nilai_tahfid_doa`
--
ALTER TABLE `tbl_nilai_tahfid_doa`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=352;
--
-- AUTO_INCREMENT for table `tbl_ortu`
--
ALTER TABLE `tbl_ortu`
MODIFY `id_ortu` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=268;
--
-- AUTO_INCREMENT for table `tbl_pembiasaan`
--
ALTER TABLE `tbl_pembiasaan`
MODIFY `id_pembiasaan` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_tahfid_doa`
--
ALTER TABLE `tbl_tahfid_doa`
MODIFY `id_tahfid_doa` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `tbl_thn_ajaran`
--
ALTER TABLE `tbl_thn_ajaran`
MODIFY `id` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
