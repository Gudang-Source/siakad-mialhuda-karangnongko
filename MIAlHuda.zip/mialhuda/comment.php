<?php
include('settings/config.php');

$id_artikel = $_POST['id_artikel'];
$keterangan = $_POST['keterangan']; 
$nama = $_POST['nama'];
$email = $_POST['email'];
$komentar = $_POST['komentar'];
$tanggal_komentar = date('Y-m-d');
$jam_komentar = date('h:i:sa');

$query = mysql_query("INSERT INTO  tbl_komentar VALUES ('', '$id_artikel', '$nama', '$email', '$komentar', '$tanggal_komentar', '$jam_komentar', '$keterangan')") or die(mysql_error());

if ($query) {
	echo "<script>location.replace('readmore_single_pengumuman.php?id=$id_artikel')</script>";
}
else{
		echo "<script>alert('Gagal Disimpan');</script>";
	}
?>