<?php
session_start();
include('../check_login.php');
include('../settings/config.php');

$nis_lokal = $_GET['id'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Selamat Datang</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Education Tutorial Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--bootstrap-->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!--coustom css-->
<link href="../css/style.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="../css/menu-profil.css">
<!--script-->
<script src="../js/jquery-1.11.0.min.js"></script>
<!-- js -->
<script src="../js/bootstrap.js"></script>
<!-- /js -->
<script type="text/javascript" src="../js/move-top.js"></script>
<script type="text/javascript" src="../js/easing.js"></script>
</head>
	<body>
<!--header-->
		<div class="header" id="home">
			<nav class="navbar navbar-default">
				<div class="container">
          <div class="col-md-1" style="margin-right:30px;">
            <img style="margin-top:15px; height:95px;" src="../images/logo.png">
          </div>
          <div class="col-md-10">
            <label style="margin-top:25px; color:#fff; font-size:25px">Sistem Informasi Akademik</label><br>
            <label style="color:#fff; font-size:25px">MI AL-HUDA</label>
          </div>
        </div>
			</nav>
<!--/script-->
		   <div class="clearfix"> </div>
		</div>
<!-- Top Navigation -->
<!--header-->
<!-- About -->
<section class="box-profil">

	 <?php
	 $user = $_SESSION['nip_nisn'];
      $query = mysql_query("SELECT * FROM tbl_guru INNER JOIN tbl_kelas ON tbl_kelas.wali_kelas = tbl_guru.nomer_pegawai WHERE nomer_pegawai = $user");
        if (mysql_num_rows($query) > 0) {
          $user  = mysql_fetch_array($query);
          $nama = $user['nama'];
          $nip = $user['nip'];
          $kelas =$user['id_kelas'];
          $jabatan = $user['jabatan'];
          $nopeg= $user['nomer_pegawai'];
          $foto = $user['foto']; 
        }
        else{
      $query1 = mysql_query("SELECT * FROM tbl_guru WHERE nomer_pegawai = $user");   
      $user  = mysql_fetch_array($query1);
          $nama = $user['nama'];
          $nip = $user['nip'];
          $kelas = "-";
          $jabatan = $user['jabatan'];
          $nopeg= $user['nomer_pegawai'];  
          $foto = $user['foto'];     
        }
    ?>

	<div class="container">
		<div class="about-info-grids" style="margin-top:70px;">
			 <div class="col-md-3 abt-profil">
        <?php
          if ($foto == 'Belum Ada') {
            if ($user['jenis_kel'] == 'L') {
              $foto_tampil = '../../AdminKP/Admin/app/insert/foto/laki-laki.png';
              
            }
            elseif ($user['jenis_kel'] == 'P') {
              $foto_tampil = '../../AdminKP/Admin/app/insert/foto/perempuan.png';
            }
          }
          else{
            $foto_tampil = '../../AdminKP/Admin/app/insert/'.$user['foto'].'';
          }
        ?>
			 	 <div class="testi-profile">
				 	<center><img src="<?php echo $foto_tampil;?>" class="img-responsive" alt=""/></center><br>
				 	<p class="text-center"><?php echo $nama;?></p>
          			<p class="text-center"><?php echo $user['nomer_pegawai'];?></p>
				 </div>
			 </div>
			
			 <div class="col-md-9">
			 		<div class="row"></div>
			 		<div class="row">
			 			<div class="alert alert-info alert-dismissible" role="alert" style="border-radius:0px">
  							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  							<strong>Assalamu'alaikum,</strong> <?php echo $nama; ?>
						</div>
			 		</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">Nama</div>
			 	 			<div class="col-md-10"> : <?php echo $nama; ?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Wali Kelas</div>
			 	 			<div class="col-md-8"> : <?php echo $kelas; ?> </div>
			 	 		</div>
			 	 	</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">NIP</div>
			 	 			<div class="col-md-10"> : <?php echo $nip;?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Jabatan</div>
			 	 			<div class="col-md-8"> : <?php echo $user['jabatan'];?></div>
			 	 		</div>
			 	 	</div><br>
			 	 	<div class="row">	
						<ol class="breadcrumb" style="background-color:#dff0d8; border-radius:0px;">
  							<li style="font-size:15px">Dashboard</li>
  							<li style="font-size:15px">Akademik</li>
  							<li class="active" style="font-size:15px">Nilai Raport</li>
						</ol>
			 	 	</div>
				 <!--<h3>Vestibulum congue neque quis ex fringilla, in pellentesque massa gravida.</h3>-->
			 </div>
			 <div class="clearfix"> </div>
		 </div>
	</div>
</section>
<section class="box-profil">
	<div class="container"><br>
		<div class="col-md-3 abt-profil">
				 <div>
			 		<ul class="nav nav-pills nav-stacked">
  						<li role="presentation" style="background-color:#006600;"><a href="profil.php" style="background-color:#006600; color:#fff"><span class="glyphicon glyphicon-home">
                            </span> Dashboard</a></li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"><span class="glyphicon glyphicon-th">
                            </span> Data Pribadi Guru</a>
                    		<div id="collapseTwo" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a style="color: #4d4d4d; font-size:14px" href="data_diri_guru.php">Lihat Data Pribadi Guru</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordio" href="#collapseThree"><span class="glyphicon glyphicon-th">
                            </span> Identitas Lembaga</a>
                        <div id="collapseThree" class="panel-collapse collapse">
                            <div class="panel-body">
                              <div class="row"><a style="color: #4d4d4d; font-size:14px" href="identitas_lembaga.php">Lihat Identitas Lembaga</a></div>
                            </div>
                        </div>
              </li>
              <li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTw"><span class="glyphicon glyphicon-th">
                            </span> Akademik</a>
                            <div id="collapseTw" class="panel-collapse collapse">
                            <div class="panel-body">
                              <div class="row"><a href="data_peserta_didik.php" style="color: #4d4d4d; font-size:14px">Peserta Didik</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="data_jadwal_mengajar.php" style="color: #4d4d4d; font-size:14px">Jadwal Mengajar</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="leger.php" style="color: #4d4d4d; font-size:14px">Lihat Ledger</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_kepribadian.php" style="color: #4d4d4d; font-size:14px">Nilai Kepribadian</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_tahfid.php" style="color: #4d4d4d; font-size:14px">Nilai Tahfid / Doa</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_semester.php" style="color: #4d4d4d; font-size:14px">Nilai Semester</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_raport.php" style="color: #4d4d4d; font-size:14px">Nilai Raport</a></div>
                            </div>
                        </div>
              </li>
  						<li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collap"><span class="glyphicon glyphicon-th">
                            </span> Ganti Password</a>
                            <div id="collap" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a href="ubah_password.php" style="color: #4d4d4d; font-size:14px">Ganti Password</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" href="<?php echo '../logout.php';?>"><span class="glyphicon glyphicon-log-out">
                            </span> Logout</a>
  						</li>
					</ul>
			 	</div>
			 </div>
		<div class="col-md-9">
			
			<form action="" method="POST">
                  <div class="col-md-12"><!--col-md-12-->
                  <div class="row"><br>
                    <?php
                      $query_siswa = mysql_query("SELECT * FROM tbl_siswa1
                                                  INNER JOIN tbl_kelas ON tbl_kelas.id_kelas = tbl_siswa1.kelas
                                                  INNER JOIN tbl_guru ON tbl_guru.nomer_pegawai = tbl_kelas.wali_kelas 
                                                  WHERE nis_lokal = '$nis_lokal'");
                      $siswa = mysql_fetch_array($query_siswa);
                      $kelase = $siswa['kelas'];
                    ?>
                    <div class="col-md-2">
                      <label>NIS</label>
                    </div>
                    <div class="col-md-5">
                      <input type="hidden" name="nis_lok" value="<?php echo $siswa['nis_lokal'];?>">
                      <input type="text" name="nis_lokal" class="form-control" value="<?php echo $siswa['nis_lokal'];?>" disabled>
                    </div>
                  </div><br>
                  <div class="row">
                    <div class="col-md-2">
                      <label>Nama</label>
                    </div>
                    <div class="col-md-5">
                      <input type="hidden" name="nama_sis" value="<?php echo $siswa['nama_siswa'];?>">
                      <input type="text" name="nama_siswa" class="form-control" value="<?php echo $siswa['nama_siswa'];?>" disabled>
                    </div>
                  </div><br>
                  <div class="row">
                    <div class="col-md-2">
                      <label>Kelas</label>
                    </div>
                    <div class="col-md-5">
                      <input type="hidden" name="kls" value="<?php echo $siswa['kelas'];?>">
                      <input type="text" name="kelas" class="form-control" value="<?php echo $siswa['kelas'];?>" disabled>
                    </div>
                  </div><br>
                  <div class="row">
                    <div class="col-md-2">
                      <label>Wali Kelas</label>
                    </div>
                    <div class="col-md-5">
                      <input type="hidden" name="wali_kls" value="<?php echo $siswa['nomer_pegawai'];?>">
                      <input type="text" name="wali_kelas" class="form-control" value="<?php echo $siswa['nama'];?>" disabled>
                    </div>
                  </div>  
                  <br>
                  <div class="row">
                    <div class="col-md-2">
                      <label>Tahun Ajaran</label>
                    </div>';
                        
                    <div class="col-md-3">
                        <select name="thn_ajaran" class="form-control">
                        <?php
                        $query_thn_ajaran = mysql_query("SELECT * FROM tbl_thn_ajaran GROUP BY kode_thn_ajaran ORDER BY id ASC");
                        $no_thn=1;
                        while ( $thn = mysql_fetch_array($query_thn_ajaran)) {
                        ?>
                        <option value="<?php echo $thn['kode_thn_ajaran'];?>"><?php echo $thn['kode_thn_ajaran'];?></option>
                        <?php
                        $no_thn++;
                        }
                        ?>
                        </select>
                    </div>
                  </div><br>
                  <div class="row">
                    <div class="col-md-2">
                      <label>Semester</label>
                    </div>
                    <div class="col-md-3">
                      <select name="semester" class="form-control">
                      <?php
                        $query_status = mysql_query("SELECT * FROM tbl_thn_ajaran GROUP BY status");
                        $no_status=1;
                        while ($status = mysql_fetch_array($query_status)) {
                      ?>
                      <option value="<?php echo $status['status'];?>"><?php echo $status['status'];?></option>
                      <?php
                        $no_status++;
                        }
                      ?>
                      </select>
                    </div>
                  </div><br>
                  <div class="row">
                    <div class="col-md-2">
                      <label></label>
                    </div>
                    <div class="col-md-3">
                      <button type="submit" name="olah_nilai" class="btn" style="float:right; background-color:#006600; color:#fff; border-radius:0px"><i class="glyphicon glyphicon-th"></i> Olah Nilai</button>
                    </div>
                  </div><br>
                  </form>
                  <?php
                    if (isset($_POST['olah_nilai'])) {
                       $thn_ajaran = $_POST['thn_ajaran'];
                       $semester = $_POST['semester'];

                       $nis_lokal = $_POST['nis_lok'];
                       $nama_siswa = $_POST['nama_sis'];
                       $kls = $_POST['kls'];
                       $wali_kls = $_POST['wali_kls'];

                       if ($semester == 'Ganjil') {

                        echo '<div class="row">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-7">';
                       
                        $query = mysql_query("SELECT * FROM tbl_jadwal_pelajaran
                                              INNER JOIN tbl_mapel ON tbl_mapel.id_mapel=tbl_jadwal_pelajaran.id_mapel
                                              WHERE tbl_jadwal_pelajaran.id_kelas='$kelase' AND status_jadwal='Pokok'
                                              GROUP BY tbl_jadwal_pelajaran.id_mapel");
                        $no =1;
                        if (mysql_num_rows($query) == 0) {
                          echo '<div class="alert alert-danger" role="alert" style="border-radius:0px">';
                          echo '<h5>Maaf, Kelas '.$kelase.' Belum Ada Jadwal Pelajaran</h5>';
                          echo '</div>';
                        }
                        else{

                        echo '<table id="" class="table table-bordered">';
                        echo '<thead>';
                        echo '<tr>';
                        echo '<th class="text-center" style="width: 10px">No</th>';
                        echo '<th class="text-center" style="width: 180px">Mata Pelajaran</th>';
                        echo '<th class="text-center" style="width: 50px">KKM</th>';
                        echo '<th class="text-center" style="width: 50px">Nilai</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';
                        echo '<form action="../app/insert/insert_nilai_raport_ganjil.php" method="POST">';

                        $jumlah_mapel = mysql_num_rows($query);
                        echo '<input type="hidden" name="jumlah_mapel" value='.$jumlah_mapel.'>';

                        echo '<input type="hidden" name="thn_ajaran" value='.$thn_ajaran.'>';
                        echo '<input type="hidden" name="semester" value='.$semester.'>';
                        echo '<input type="hidden" name="nis_lokal" value='.$nis_lokal.'>';
                        echo '<input type="hidden" name="kelas" value='.$kls.'>';
                        echo '<input type="hidden" name="wali_kls" value='.$wali_kls.'>';
                        while ($data = mysql_fetch_array($query)) {

                        echo '<tr>';
                        echo '<input type="hidden" name="id_guru[]" value='.$data['id_guru'].'>';
                        echo '<td style="font-size:14px" class="text-center">'.$no.'</td>';
                        echo '<input type="hidden" name="id_mapel[]" value='.$data['id_mapel'].'>';
                        echo '<td style="font-size:14px">'.$data['nama_mapel'].'</td>';
                        echo '<td class="text-center"><input type="number" name="kkm_mapel[]" class="form-control"></td>';
                        echo '<td class="text-center"><input type="number" name="nilai_mapel[]" class="form-control"></td>';
                        echo '</tr>';

                         $no++;
                          }
                        echo '</tbody>';
                        echo '</table>';
                        echo '</div>';
                        echo '</div>';

                        echo '<div class="row">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-7">';

                        $query_pembiasaan = mysql_query("SELECT * FROM tbl_pembiasaan ORDER BY id_pembiasaan ASC");
                        $no_pembiasaan =1;
                        $jumlah_pembiasaan = mysql_num_rows($query_pembiasaan);
                        echo '<input type="hidden" name="jumlah_pembiasaan" value='.$jumlah_pembiasaan.'>';

                        echo '<table id="" class="table table-bordered">';
                        echo '<thead>';
                        echo '<tr>';
                        echo '<th class="text-center" style="width: 10px">No</th>';
                        echo '<th class="text-center" style="width: 180px">Pembiasaan</th>';
                        echo '<th class="text-center" style="width: 50px">Nilai</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';
                        while ($data1 = mysql_fetch_array($query_pembiasaan)) {

                        echo '<tr>';
                        echo '<input type="hidden" name="id_pembiasaan[]" value='.$data1['id_pembiasaan'].'>';
                        echo '<td style="font-size:14px" class="text-center">'.$no_pembiasaan.'</td>';
                        echo '<td style="font-size:14px">'.$data1['nama_pembiasaan'].'</td>';
                        echo '<td class="text-center"><input type="number" name="nilai_pembiasaan[]" class="form-control"></td>';
                        echo '</tr>';

                         $no_pembiasaan++;
                          }
                        echo '</tbody>';
                        echo '</table>';
                        echo '</div>';
                        echo '</div>';

                        echo '<div class="row">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-7">';

                        $query_ekstra = mysql_query("SELECT * FROM tbl_ekskul ORDER BY id_ekstra ASC");
                        $no_ekstra =1;
                        $jumlah_ekstra = mysql_num_rows($query_ekstra);
                        echo '<input type="hidden" name="jumlah_ekstra" value='.$jumlah_ekstra.'>';

                        echo '<table id="" class="table table-bordered">';
                        echo '<thead>';
                        echo '<tr>';
                        echo '<th class="text-center" style="width: 10px">No</th>';
                        echo '<th class="text-center" style="width: 180px">Pengembangan Diri</th>';
                        echo '<th class="text-center" style="width: 50px">Nilai</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';
                        while ($data2 = mysql_fetch_array($query_ekstra)) {

                        echo '<tr>';
                        echo '<input type="hidden" name="id_ekstra[]" value='.$data2['id_ekstra'].'>';
                        echo '<td style="font-size:14px"  class="text-center">'.$no_ekstra.'</td>';
                        echo '<td style="font-size:14px">'.$data2['nama_ekstra'].'</td>';
                        echo '<td class="text-center"><input type="number" name="nilai_ekstra[]" class="form-control"></td>';
                        echo '</tr>';

                         $no_ekstra++;
                          }
                        echo '</tbody>';
                        echo '</table>';
                        echo '</div>';
                        echo '</div>';

                        echo '<div class="row">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-7">';

                        echo '<table id="" class="table table-bordered">';
                        echo '<thead>';
                        echo '<tr>';
                        echo '<th class="text-center" style="width: 50px">Ijin</th>';
                        echo '<th class="text-center" style="width: 50px">Sakit</th>';
                        echo '<th class="text-center" style="width: 50px">Alpha</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';

                        echo '<tr>';
                        echo '<td style="font-size:14px"><input type="number" name="ijin" class="form-control"></td>';
                        echo '<td class="text-center"><input type="number" name="sakit" class="form-control"></td>';
                        echo '<td class="text-center"><input type="number" name="alpha" class="form-control"></td>';
                        echo '</tr>';

                        echo '</tbody>';
                        echo '</table>';
                        echo '</div>';
                        echo '</div>';

                        echo '<div class="row">';
                        echo '<div class="col-md-12">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-10">';
                        echo '<div class="row">';
                        echo '<label>Catatan Wali Kelas :</label>';
                        echo '</div>';
                        echo '<div class="row">';
                        echo '<textarea name="catatan" rows="5" cols="60"></textarea>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '<br>';

                        echo '<div class="row">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-10">';
                        echo '<button type="submit" class="btn" style="float:right; background-color:#006600; color:#fff; border-radius:0px"><i class="glyphicon glyphicon-th"></i> Simpan Nilai</button>';
                        echo '</div>';
                        echo '</div>';
                        echo '</form>';
                        }

                        echo '</div><!--col-md-12-->';

                       }

                       elseif ($semester == 'Genap') {
                         
                        echo '<div class="row">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-7">';
                       
                        $query = mysql_query("SELECT * FROM tbl_jadwal_pelajaran
                                              INNER JOIN tbl_mapel ON tbl_mapel.id_mapel=tbl_jadwal_pelajaran.id_mapel
                                              WHERE tbl_jadwal_pelajaran.id_kelas='$kelase' AND status_jadwal='Pokok'
                                              GROUP BY tbl_jadwal_pelajaran.id_mapel");
                        $no =1;
                        if (mysql_num_rows($query) == 0) {
                          echo '<div class="alert alert-danger" role="alert" style="border-radius:0px">';
                          echo '<h5>Maaf, Kelas '.$kelase.' Belum Ada Jadwal Pelajaran</h5>';
                          echo '</div>';
                        }
                        else{

                        echo '<table id="" class="table table-bordered">';
                        echo '<thead>';
                        echo '<tr>';
                        echo '<th class="text-center" style="width: 10px">No</th>';
                        echo '<th class="text-center" style="width: 180px">Mata Pelajaran</th>';
                        echo '<th class="text-center" style="width: 50px">KKM</th>';
                        echo '<th class="text-center" style="width: 50px">Nilai</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';
                        echo '<form action="../app/insert/insert_nilai_raport_genap.php" method="POST">';

                        $jumlah_mapel = mysql_num_rows($query);
                        echo '<input type="hidden" name="jumlah_mapel" value='.$jumlah_mapel.'>';

                        echo '<input type="hidden" name="thn_ajaran" value='.$thn_ajaran.'>';
                        echo '<input type="hidden" name="semester" value='.$semester.'>';
                        echo '<input type="hidden" name="nis_lokal" value='.$nis_lokal.'>';
                        echo '<input type="hidden" name="kelas" value='.$kls.'>';
                        echo '<input type="hidden" name="wali_kls" value='.$wali_kls.'>';

                        while ($data = mysql_fetch_array($query)) {

                        echo '<tr>';
                        echo '<input type="hidden" name="id_guru[]" value='.$data['id_guru'].'>';
                        echo '<td style="font-size:14px" class="text-center">'.$no.'</td>';
                        echo '<input type="hidden" name="id_mapel[]" value='.$data['id_mapel'].'>';
                        echo '<td style="font-size:14px">'.$data['nama_mapel'].'</td>';
                        echo '<td class="text-center"><input type="number" name="kkm_mapel[]" class="form-control"></td>';
                        echo '<td class="text-center"><input type="number" name="nilai_mapel[]" class="form-control"></td>';
                        echo '</tr>';

                         $no++;
                          }
                        echo '</tbody>';
                        echo '</table>';
                        echo '</div>';
                        echo '</div>';

                        echo '<div class="row">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-7">';

                        $query_pembiasaan = mysql_query("SELECT * FROM tbl_pembiasaan ORDER BY id_pembiasaan ASC");
                        $no_pembiasaan =1;
                        $jumlah_pembiasaan = mysql_num_rows($query_pembiasaan);
                        echo '<input type="hidden" name="jumlah_pembiasaan" value='.$jumlah_pembiasaan.'>';

                        echo '<table id="" class="table table-bordered">';
                        echo '<thead>';
                        echo '<tr>';
                        echo '<th class="text-center" style="width: 10px">No</th>';
                        echo '<th class="text-center" style="width: 180px">Pembiasaan</th>';
                        echo '<th class="text-center" style="width: 50px">Nilai</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';
                        while ($data1 = mysql_fetch_array($query_pembiasaan)) {

                        echo '<tr>';
                        echo '<input type="hidden" name="id_pembiasaan[]" value='.$data1['id_pembiasaan'].'>';
                        echo '<td style="font-size:14px" class="text-center">'.$no_pembiasaan.'</td>';
                        echo '<td style="font-size:14px">'.$data1['nama_pembiasaan'].'</td>';
                        echo '<td class="text-center"><input type="number" name="nilai_pembiasaan[]" class="form-control"></td>';
                        echo '</tr>';

                         $no_pembiasaan++;
                          }
                        echo '</tbody>';
                        echo '</table>';
                        echo '</div>';
                        echo '</div>';

                        echo '<div class="row">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-7">';

                        $query_ekstra = mysql_query("SELECT * FROM tbl_ekskul ORDER BY id_ekstra ASC");
                        $no_ekstra =1;
                        $jumlah_ekstra = mysql_num_rows($query_ekstra);
                        echo '<input type="hidden" name="jumlah_ekstra" value='.$jumlah_ekstra.'>';

                        echo '<table id="" class="table table-bordered">';
                        echo '<thead>';
                        echo '<tr>';
                        echo '<th class="text-center" style="width: 10px">No</th>';
                        echo '<th class="text-center" style="width: 180px">Pengembangan Diri</th>';
                        echo '<th class="text-center" style="width: 50px">Nilai</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';
                        while ($data2 = mysql_fetch_array($query_ekstra)) {

                        echo '<tr>';
                       echo '<input type="hidden" name="id_ekstra[]" value='.$data2['id_ekstra'].'>';
                        echo '<td style="font-size:14px" class="text-center">'.$no_ekstra.'</td>';
                        echo '<td style="font-size:14px">'.$data2['nama_ekstra'].'</td>';
                        echo '<td class="text-center"><input type="number" name="nilai_ekstra[]" class="form-control"></td>';
                        echo '</tr>';

                         $no_ekstra++;
                          }
                        echo '</tbody>';
                        echo '</table>';
                        echo '</div>';
                        echo '</div>';

                        echo '<div class="row">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-7">';

                        echo '<table id="" class="table table-bordered">';
                        echo '<thead>';
                        echo '<tr>';
                        echo '<th class="text-center" style="width: 50px">Ijin</th>';
                        echo '<th class="text-center" style="width: 50px">Sakit</th>';
                        echo '<th class="text-center" style="width: 50px">Alpha</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';

                        echo '<tr>';
                        echo '<td style="font-size:14px"><input type="number" name="ijin" class="form-control"></td>';
                        echo '<td class="text-center"><input type="number" name="sakit" class="form-control"></td>';
                        echo '<td class="text-center"><input type="number" name="alpha" class="form-control"></td>';
                        echo '</tr>';

                        echo '</tbody>';
                        echo '</table>';
                        echo '</div>';
                        echo '</div>';

                        echo '<div class="row">';
                        echo '<div class="col-md-12">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-10">';
                        echo '<div class="row">';
                        echo '<label>Catatan Wali Kelas :</label>';
                        echo '</div>';
                        echo '<div class="row">';
                        echo '<textarea name="catatan" rows="5" cols="60"></textarea>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '<br>';

                        echo '<div class="row">';
                        echo '<div class="col-md-12">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-10">';
                        echo '<div class="row">';
                        echo '<label>Keterangan Naik / Tinggal Kelas :</label>';
                        echo '</div>';
                        echo '<div class="row">';
                        echo '<div class="radio">';
                        echo '<label style="font-size:14px"><input type="radio" name="ket_naik_tinggal" value="Naik Kelas" checked>Naik Kelas</label>';
                        echo '<label style="font-size:14px; margin-left:10px"><input type="radio" name="ket_naik_tinggal" value="Tinggal Kelas" >Tinggal Kelas</label>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '<br>';

                        echo '<div class="row">';
                        echo '<div class="col-md-2">';
                        echo '<label></label>';
                        echo '</div>';
                        echo '<div class="col-md-10">';
                        echo '<button type="submit" class="btn" style="float:right; background-color:#006600; color:#fff; border-radius:0px"><i class="glyphicon glyphicon-th"></i> Simpan Nilai</button>';
                        echo '</div>';
                        echo '</div>';
                        echo '</form>';
                        }

                        echo '</div><!--col-md-12-->';   

                       }
                    }

                  ?>
			
		</div>
	</div>
</section>
<section>

</section>
<div class="about">
	 <div class="container">
		 <div class="testimonals">
				
		   </div>
		   <div class="team">
			  
			 <div class="clearfix"> </div> 
		  </div>
	 </div>
</div>
<!-- /About -->
<!--copy-rights-->
<div class="copyright">
		<!-- container -->
		<div class="container">
			<div class="copyright-left">
			<p>MI Al-Huda © 2016 All rights reserved</p>
			</div>
			<div class="clearfix"> </div>
			
		</div>
		<!-- //container -->
	</div>
<!--/copy-rights-->
	</body>
</html>
