<?php
session_start();
include('../check_login.php');
include('../settings/config.php');
?>
<!DOCTYPE html>
<html>
<head>
<title>Selamat Datang</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Education Tutorial Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--bootstrap-->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!--coustom css-->
<link href="../css/style.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="../css/menu-profil.css">
<!--script-->
<script src="../js/jquery-1.11.0.min.js"></script>
<!-- js -->
<script src="../js/bootstrap.js"></script>
<!-- /js -->
<script type="text/javascript" src="../js/move-top.js"></script>
<script type="text/javascript" src="../js/easing.js"></script>
</head>
	<body>
<!--header-->
		<div class="header" id="home">
			<nav class="navbar navbar-default">
				<div class="container">
					<div class="col-md-1" style="margin-right:30px;">
						<img style="margin-top:15px; height:95px;" src="../images/logo.png">
					</div>
					<div class="col-md-10">
						<label style="margin-top:25px; color:#fff; font-size:25px">Sistem Informasi Akademik</label><br>
						<label style="color:#fff; font-size:25px">MI AL-HUDA</label>
					</div>
				</div>
			</nav>
<!--/script-->
		   <div class="clearfix"> </div>
		</div>
<!-- Top Navigation -->
<!--header-->
<!-- About -->
<section class="box-profil">

	 <?php
	 $user = $_SESSION['nip_nisn'];
      $query = mysql_query("SELECT * FROM tbl_guru INNER JOIN tbl_kelas ON tbl_kelas.wali_kelas = tbl_guru.nomer_pegawai WHERE nomer_pegawai = $user");
        if (mysql_num_rows($query) > 0) {
          $user  = mysql_fetch_array($query);
          $nama = $user['nama'];
          $nip = $user['nip'];
          $kelas =$user['id_kelas'];
          $jabatan = $user['jabatan'];
          $nopeg= $user['nomer_pegawai'];
          $foto = $user['foto'];  

        }
        else{
      $query1 = mysql_query("SELECT * FROM tbl_guru WHERE nomer_pegawai = $user");   
      $user  = mysql_fetch_array($query1);
          $nama = $user['nama'];
          $nip = $user['nip'];
          $kelas = "-";
          $jabatan = $user['jabatan'];
          $nopeg= $user['nomer_pegawai'];
          $foto = $user['foto'];         
        }
    ?>

	<div class="container">
		<div class="about-info-grids" style="margin-top:70px;">
			 <div class="col-md-3 abt-profil">
			 	<?php
			 		if ($foto == 'Belum Ada') {
			 			if ($user['jenis_kel'] == 'L') {
			 				$foto_tampil = '../../AdminKP/Admin/app/insert/foto/laki-laki.png';
			 				
			 			}
			 			elseif ($user['jenis_kel'] == 'P') {
			 				$foto_tampil = '../../AdminKP/Admin/app/insert/foto/perempuan.png';
			 			}
			 		}
			 		else{
			 			$foto_tampil = '../../AdminKP/Admin/app/insert/'.$user['foto'].'';
			 		}
			 	?>
			 	 <div class="testi-profile">
				 	<center><img src="<?php echo $foto_tampil;?>" class="img-responsive" alt=""/></center><br>
				 	<p class="text-center"><?php echo $nama;?></p>
          			<p class="text-center"><?php echo $user['nomer_pegawai'];?></p>
				 </div>
			 </div>
			
			 <div class="col-md-9">
			 		<div class="row"></div>
			 		<div class="row">
			 			<div class="alert alert-info alert-dismissible" role="alert" style="border-radius:0px">
  							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  							<strong>Assalamu'alaikum,</strong> <?php echo $nama; ?>
						</div>
			 		</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">Nama</div>
			 	 			<div class="col-md-10"> : <?php echo $nama; ?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Wali Kelas</div>
			 	 			<div class="col-md-8"> : <?php echo $kelas; ?> </div>
			 	 		</div>
			 	 	</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">NIP</div>
			 	 			<div class="col-md-10"> : <?php echo $nip;?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Jabatan</div>
			 	 			<div class="col-md-8"> : <?php echo $user['jabatan'];?></div>
			 	 		</div>
			 	 	</div><br>
			 	 	<div class="row">	
						<ol class="breadcrumb" style="background-color:#dff0d8; border-radius:0px;">
  							<li style="font-size:15px">Dashboard</li>
  							<li style="font-size:15px">Akademik</li>
  							<li class="active" style="font-size:15px">Nilai Semester</li>
						</ol>
			 	 	</div>
				 <!--<h3>Vestibulum congue neque quis ex fringilla, in pellentesque massa gravida.</h3>-->
			 </div>
			 <div class="clearfix"> </div>
		 </div>
	</div>
</section>
<section class="box-profil">
	<div class="container"><br>
		<div class="col-md-3 abt-profil">
				 <div>
			 		<ul class="nav nav-pills nav-stacked">
  						<li role="presentation" style="background-color:#006600;"><a href="profil.php" style="background-color:#006600; color:#fff"><span class="glyphicon glyphicon-home">
                            </span> Dashboard</a></li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"><span class="glyphicon glyphicon-th">
                            </span> Data Pribadi Guru</a>
                    		<div id="collapseTwo" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a style="color: #4d4d4d; font-size:14px" href="data_diri_guru.php">Lihat Data Pribadi Guru</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordio" href="#collapseThree"><span class="glyphicon glyphicon-th">
                            </span> Identitas Lembaga</a>
                        <div id="collapseThree" class="panel-collapse collapse">
                            <div class="panel-body">
                              <div class="row"><a style="color: #4d4d4d; font-size:14px" href="identitas_lembaga.php">Lihat Identitas Lembaga</a></div>
                            </div>
                        </div>
              </li>
              <li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTw"><span class="glyphicon glyphicon-th">
                            </span> Akademik</a>
                            <div id="collapseTw" class="panel-collapse collapse">
                            <div class="panel-body">
                              <div class="row"><a href="data_peserta_didik.php" style="color: #4d4d4d; font-size:14px">Peserta Didik</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="data_jadwal_mengajar.php" style="color: #4d4d4d; font-size:14px">Jadwal Mengajar</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="leger.php" style="color: #4d4d4d; font-size:14px">Lihat Ledger</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_kepribadian.php" style="color: #4d4d4d; font-size:14px">Nilai Kepribadian</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_tahfid.php" style="color: #4d4d4d; font-size:14px">Nilai Tahfid / Doa</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_semester.php" style="color: #4d4d4d; font-size:14px">Nilai Semester</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_raport.php" style="color: #4d4d4d; font-size:14px">Nilai Raport</a></div>
                            </div>
                        </div>
              </li>
  						<li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collap"><span class="glyphicon glyphicon-th">
                            </span> Ganti Password</a>
                            <div id="collap" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a href="ubah_password.php" style="color: #4d4d4d; font-size:14px">Ganti Password</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" href="<?php echo '../logout.php';?>"><span class="glyphicon glyphicon-log-out">
                            </span> Logout</a>
  						</li>
					</ul>
			 	</div>
			 </div>
		<div class="col-md-9">
			<?php
			$query_siswa = mysql_query("SELECT * FROM tbl_kelas WHERE wali_kelas = '$nopeg' GROUP BY id_kelas");
			if (mysql_num_rows($query_siswa) < 1 ) {
                echo '<div class="alert alert-danger" role="alert" style="border-radius:0px">';
                echo '<h5>Maaf, Menu Ini Hanya Bisa Diakses Oleh Wali Kelas</h5>';
            	  echo '</div>';
             }
      else{

      echo '<form action="#" method="POST">
			<div class="row">
			<div class="form-group">
				<div class="col-md-3" style="margin-top:5px"><label>Tahun Ajaran</label></div>
				<div class="col-md-4">
				<select name="thn_ajaran" class="form-control">';
					
						$query_thn_ajaran = mysql_query("SELECT * FROM tbl_thn_ajaran GROUP BY kode_thn_ajaran ORDER BY id ASC");
            
						if (mysql_num_rows($query_thn_ajaran) == 0) {
              echo '<option name="Belum_Ada">Tidak Ada Tahun Ajaran</option>';
            }
            else{
            $no_thn=1;
						while ($th = mysql_fetch_array($query_thn_ajaran)) {
					
						echo '<option value='.$th['kode_thn_ajaran'].'>'.$th['kode_thn_ajaran'].'</option>';
					
						$no++;
					}}
					
			echo '</select>
				</div><br><br>
			</div>
			</div>

      <div class="row">
      <div class="form-group">
        <div class="col-md-3" style="margin-top:5px"><label>Semester</label></div>
        <div class="col-md-4">
        <select name="semester" class="form-control">
          <option value="Ganjil">Ganjil</option>
          <option value="Genap">Genap</option>
        </select>
        </div>
      </div>
      </div><br>

			<div class="row">
			<div class="form-group">
				<div class="col-md-3" style="margin-top:5px"><label></label></div>
				<div class="col-md-4">
				 <button class="btn" type="submit" name="btn_tampil_leger" style="border-radius:0px; color:#fff; background-color:#006600;"><span class="glyphicon glyphicon-th"></span> Lihat Leger</button>
				</div>
			</div>
			</div><br><br>
			</form>';

      if (isset($_POST['btn_tampil_leger'])) {
        $thn_ajaran = $_POST['thn_ajaran'];
        $semester = $_POST['semester'];

        $cek = mysql_query("SELECT * FROM tbl_nilai_raport
                                        INNER JOIN tbl_siswa1 ON tbl_siswa1.nis_lokal = tbl_nilai_raport.nis_lokal
                                        WHERE tbl_nilai_raport.id_kelas = '$kelas' AND tbl_nilai_raport.thn_ajaran = '$thn_ajaran' 
                                        AND tbl_nilai_raport.semester = '$semester' AND tbl_nilai_raport.id_wali = '$nopeg' 
                                        GROUP BY tbl_nilai_raport.nis_lokal ASC");
        if (mysql_num_rows($cek) < 1) {
          echo '<div class="alert alert-danger" role="alert" style="border-radius:0px">';
          echo '<h5>Maaf, Leger Nilai Untuk Tahun Ajaran '.$thn_ajaran.' ( '.$semester.' ) Belum Tersedia</h5>';
          echo '</div>';
        }
        else{
        echo '<div class="row">
        <div class="col-md-6">
        <h4><b>Leger Nilai</b></h4>
        </div>
        </div>
      <div class="row">
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>';

              $query_nilai = mysql_query("SELECT id_mapel FROM tbl_nilai_raport
                                         WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                         AND semester = '$semester' GROUP BY id_mapel");
              $query_pembiasaan= mysql_query("SELECT * FROM tbl_pembiasaan ORDER BY id_pembiasaan");
              $query_ekstra = mysql_query("SELECT * FROM tbl_nilai_pengembangan_diri
                                           INNER JOIN tbl_ekskul ON tbl_ekskul.id_ekstra = tbl_nilai_pengembangan_diri.id_ekstra
                                           WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                           AND semester = '$semester' GROUP BY tbl_ekskul.id_ekstra ");

              $no_mpl_leger=1;
              $no_pembiasaan=1;
              $no_ekstra=1;

              echo '
                <th class="text-center" style="width: 5px; font-size:12px;">No</th>
                <th class="text-center" style="font-size:12px;">Nama Siswa</th>';

              while ($mpl = mysql_fetch_array($query_nilai)) {
                echo '<th class="active text-center" style="font-size:12px;">KKM</th>';
                echo '<th class="info text-center" style="font-size:12px;">'.$mpl['id_mapel'].'</th>';
                $no_mpl_leger++;
              }

              while ($pmbs = mysql_fetch_array($query_pembiasaan)) {
                echo '<th class="warning text-center" style="font-size:10px;">'.$pmbs['nama_pembiasaan'].'</th>';
                $no_pembiasaan++;
              }
              echo '
                <th class="success text-center" style="font-size:12px;">Ijin</th>
                <th class="success text-center" style="font-size:12px;">Sakit</th>
                <th class="success text-center" style="font-size:12px;">Alpha</th>
                <th class="text-center" style="font-size:10px;">Jml Nilai Akademik</th>
                <th class="text-center" style="font-size:10px;">Ranking</th>
                <th class="text-center" style="font-size:10px;">Catatan</th>';

              while ($ekstr = mysql_fetch_array($query_ekstra)) {
                echo '<th class="danger text-center" style="font-size:10px;">'.$ekstr['nama_ekstra'].'</th>';
              }

              echo '
                <th class="text-center" style="font-size:12px;">TID</th>
                <th class="text-center" style="font-size:12px;">KP</th>
                <th class="text-center" style="font-size:10px;">Jml N.Komulatif</th>
                <th class="text-center" style="font-size:10px;">Rata N.Komulatif</th>
                <th class="text-center" style="font-size:10px;">Rata Pembiasaan</th>
                <th class="text-center" style="font-size:10px;">Rata Pengembangan</th>
              </tr> 
            </thead>';
          
            echo '<tbody>';
             $query_nilai1 = mysql_query("SELECT * FROM tbl_nilai_raport
                                        INNER JOIN tbl_siswa1 ON tbl_siswa1.nis_lokal = tbl_nilai_raport.nis_lokal
                                        WHERE tbl_nilai_raport.id_kelas = '$kelas' AND tbl_nilai_raport.thn_ajaran = '$thn_ajaran' 
                                        AND tbl_nilai_raport.semester = '$semester' AND tbl_nilai_raport.id_wali = '$nopeg' 
                                        GROUP BY tbl_nilai_raport.nis_lokal ASC");

                    $no1 = 1;
                    $jum=0;
                    while ($sis = mysql_fetch_array($query_nilai1)) {
                    echo '<tr>';
                    echo '<td style="padding: 5px; font-size:12px; text-align:center;">'.$no1.'</td>';
                    echo '<td style="padding: 5px; font-size:12px;">'.$sis['nama_siswa'].'</td>';

                        $nis = $sis['nis_lokal'];
                        $query_nilai2 = mysql_query("SELECT kkm, nilai FROM tbl_nilai_raport
                                                     WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                     AND semester = '$semester' AND nis_lokal = '$nis' ");
                       $no3 = 1;

                        while ($nil_map = mysql_fetch_array($query_nilai2)) {
                            $jum = $jum + $nil_map['nilai'];
                            echo '<td class="active" style="padding: 5px; font-size:12px; text-align: center;">'.$nil_map['kkm'].'</td>';
                            echo '<td class="info" style="padding: 5px; font-size:12px; text-align: center;">'.$nil_map['nilai'].'</td>';

                            $no3++;
                         }

                         $nilai_pembiasaan= mysql_query("SELECT nilai FROM tbl_nilai_pembiasaan
                                                        WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                        AND semester = '$semester' AND nis_lokal = '$nis'");
                         $no4=1;

                         while ($nil_pmbs = mysql_fetch_array($nilai_pembiasaan)) {
                            echo '<td class="warning" style="padding: 5px; font-size:12px; text-align: center;">'.$nil_pmbs['nilai'].'</td>';

                            $no4++;
                         }

                         $kehadiran = mysql_query("SELECT * FROM tbl_kehadiran  WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                   AND semester = '$semester' AND nis_lokal = '$nis' ");
                         $hadir = mysql_fetch_array($kehadiran);

                         echo '<td class="success" style="padding: 5px; font-size:12px; text-align: center;">'.$hadir['ijin'].'</td>';
                         echo '<td class="success" style="padding: 5px; font-size:12px; text-align: center;">'.$hadir['sakit'].'</td>';
                         echo '<td class="success" style="padding: 5px; font-size:12px; text-align: center;">'.$hadir['alpha'].'</td>';
                         echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.$jum.'</td>';

                         $ranking = mysql_query("SELECT * FROM tbl_nilai_raport_rata
                                                 WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg' AND semester = '$semester' ORDER BY jumlah_nilai DESC");
                          $no_rank = 1;

                          while ($data_rank = mysql_fetch_array($ranking)) {

                              $rank = $no_rank;
                              $ns_lok = $data_rank['nis_lokal'];

                              if ($ns_lok == $nis) {
                                  $rank_kls = $rank;
                              }
                              else{

                              }
                              $no_rank++;
                          }

                         echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.$rank_kls.'</td>';

                         $catatan = mysql_query("SELECT * FROM tbl_catatan_wali WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                 AND semester = '$semester' AND nis_lokal = '$nis' ");
                         $cttn = mysql_fetch_array($catatan);

                         echo '<td style="padding: 5px; font-size:9px; text-align: center;">'.$cttn['catatan'].'</td>';

                         $nilai_ekstra = mysql_query("SELECT nilai FROM tbl_nilai_pengembangan_diri
                                                    WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                    AND semester = '$semester' AND nis_lokal = '$nis' ORDER BY id_ekstra");
                         $no5=1;

                         while ($nil_eks = mysql_fetch_array($nilai_ekstra)) {
                           if ($nil_eks['nilai'] == 0) {
                             $eks = '-';
                           }
                           else{
                             $eks = $nil_eks['nilai'];
                           }
                           echo '<td class="danger" style="padding: 5px; font-size:12px; text-align: center;">'.$eks.'</td>';
                           $no5++;
                         }

                         $nilai_tid = mysql_query("SELECT * FROM tbl_nilai_rata_tid
                                                  WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                  AND semester = '$semester' AND nis_lokal = '$nis'");
                         $nil_tid=mysql_fetch_array($nilai_tid);

                         $nilai_kp = mysql_query("SELECT * FROM tbl_nilai_rata_kepribadian
                                                  WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                  AND semester = '$semester' AND nis_lokal = '$nis'");
                         $nil_kp=mysql_fetch_array($nilai_kp);

                         echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.substr($nil_tid['nilai_rata_tid'], 0,2).'</td>';
                         echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.substr($nil_kp['nilai_rata_kp'], 0,2).'</td>';

                         $komulatif = mysql_query("SELECT * FROM tbl_nilai_raport_rata
                                                   WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                   AND semester = '$semester' AND nis_lokal = '$nis'");
                         $no6=1;
                         while ($kom = mysql_fetch_array($komulatif)) {
                           echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.$kom['jumlah_nilai'].'</td>';
                           echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.substr($kom['nilai_rata'], 0,5).'</td>';
                           $no6++;
                         }

                         $cek_pembiasaan = mysql_query("SELECT SUM(nilai) as rata_pembiasaan FROM tbl_nilai_pembiasaan
                                                        WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg' AND semester = '$semester' AND nis_lokal = '$nis'");  
                         $jmlh_pembiasaan = mysql_query("SELECT * FROM tbl_nilai_pembiasaan
                                                        WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg' AND semester = '$semester' AND nis_lokal = '$nis'");  
                         $nil_pembiasaan = mysql_fetch_array($cek_pembiasaan);
                         $rata_pembiasaan =$nil_pembiasaan['rata_pembiasaan'] / mysql_num_rows($jmlh_pembiasaan);

                         echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.substr($rata_pembiasaan, 0,5).'</td>';

                         $cek_ekstra = mysql_query("SELECT SUM(nilai) as rata_ekstra FROM tbl_nilai_pengembangan_diri
                                                    WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg' AND semester = '$semester' AND nis_lokal = '$nis'");
                         $jmlh_ekstra = mysql_query("SELECT * FROM tbl_nilai_pengembangan_diri
                                                      WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg' AND semester = '$semester' AND nis_lokal = '$nis' AND nilai != 0 ");
                         $nil_ekstra = mysql_fetch_array($cek_ekstra);
                         $rata_ekstra = $nil_ekstra['rata_ekstra'] / mysql_num_rows($jmlh_ekstra);

                         echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.substr($rata_ekstra, 0,5).'</td>';

                    $no1++;
                    echo '</tr>';
 
                  }
            
          echo '</tbody>
          </table>
        </div>
      </div><br>
      <div class="row">
        <div class="col-md-12">
        <form action="../app/report/cetak_ledger_nilai_guru.php" target="_blank" method="POST">
        <input type="hidden" name="thn_ajaran" value='.$thn_ajaran.'>
        <input type="hidden" name="semester" value='.$semester.'>
        <input type="hidden" name="nopeg" value='.$nopeg.'>
        <input type="hidden" name="kelas" value='.$kelas.'>
        <button class="btn" style="float:left; background-color:#006600; color:#fff; border-radius:0px;"><span class="glyphicon glyphicon-th"></span> Cetak Leger</button>
        </form>
        </div>
      </div>
      ';

        echo "<!--=========================================-->";

      }

			}

   }

			?>
			
			<!--Modal Cetak-->
                      <div class="modal fade" id="cetak_nilai_semester" tabindex="-1">
                        <div class="modal-dialog modal-md">
                          <div class="modal-content">
                              <div class="modal-header">
                              <button class="close" data-dismiss="modal" type="button">x</button>
                              <h4 class="modal-tittle" id="myModalLabel">Cetak Nilai Semester</h4>
                              </div>
                              <div class="modal-body">
                                <form action="../app/report/cetak_nilai_semester_guru.php" target="_blank" method="POST">
                                		<input type="hidden" name="nopeg" value="<?php echo $nopeg;?>">
                                        <div class="form-group"><br>
                                          <label class="col-md-3 control-label">Kelas</label>
                                        <div class="col-md-9">
                                         <select name="kelas" class="form-control">
                                        <?php
                                        	$kelas_nilai = mysql_query("SELECT * FROM tbl_jadwal_pelajaran WHERE id_guru = '$nopeg' GROUP BY id_kelas");
                                        	$no_nilai=1;
                                        	if (mysql_num_rows($kelas_nilai) == 0) {
                                        		$status_btn = 'disabled';
                                        	}
                                        	else{
                                        		$status_btn = '';
                                        	while ($kls_nilai = mysql_fetch_array($kelas_nilai)) {
                                        ?>
                                          	<option value="<?php echo $kls_nilai['id_kelas'];?>"><?php echo $kls_nilai['id_kelas'];?></option>
                                         <?php
                                         	$no_nilai++;
                                         	}
                                        	}
                                         ?>
                                         </select>
                                        </div><br>
                                        <div class="form-group"><br>
                                          <label class="col-md-3 control-label">Tahun Ajaran</label>
                                        <div class="col-md-9">
                                          <select name="thn_ajaran" class="form-control">
                                        <?php
                                        	$tahun_ajar = mysql_query("SELECT * FROM tbl_thn_ajaran GROUP BY kode_thn_ajaran ORDER BY id ASC");
                                        	$no_thn=1;
                                        	while ($thn=mysql_fetch_array($tahun_ajar)) {
                                        ?>
                                          	<option value="<?php echo $thn['kode_thn_ajaran'];?>"><?php echo $thn['kode_thn_ajaran'];?></option>
                                        <?php
                                        	$no_thn++;
                                        }
                                        ?>
                                          </select>
                                        </div><br>
                                        <div class="form-group"><br>
                                          <label class="col-md-3 control-label">Semester</label>
                                        <div class="col-md-9">
                                          <select name="semester" class="form-control">
                                          	<option value="Ganjil">Ganjil</option>
                                          	<option value="Genap">Genap</option>
                                          </select>
                                        </div><br>
                                        <div class="form-group"><br>
                                          <label class="col-md-3 control-label">Keterangan</label>
                                        <div class="col-md-9">
                                          <select name="keterangan" class="form-control">
                                          	<option value="UTS">UTS</option>
                                          	<option value="UAS">UAS</option>
                                          </select>
                                        </div><br>
                                        <div class="form-group"><br>
                                          <label class="col-md-3 control-label"></label>
                                        <div class="col-md-9" align="right">
                                          <button class="btn btn-flat btn-primary" style="border-radius:0px;" <?php echo $status_btn;?> type="submit"><i class="glyphicon glyphicon-print"></i> Cetak</button>
                                        </div><br>
                                </form>
                              </div>
                          </div>
                        </div>
                      </div>
                      <!--Modal Cetak-->

		</div>
	</div>
</section>
<section>

</section>
<div class="about">
	 <div class="container">
		 <div class="testimonals">
				
		   </div>
		   <div class="team">
			  
			 <div class="clearfix"> </div> 
		  </div>
	 </div>
</div>
<!-- /About -->
<!--copy-rights-->
<div class="copyright">
		<!-- container -->
		<div class="container">
			<div class="copyright-left">
			<p>MI Al-Huda © 2016 All rights reserved</p>
			</div>
			<div class="clearfix"> </div>
			
		</div>
		<!-- //container -->
	</div>
<!--/copy-rights-->
	</body>

</html>
