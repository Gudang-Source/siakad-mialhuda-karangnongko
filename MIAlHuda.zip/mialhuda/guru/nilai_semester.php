<?php
session_start();
include('../check_login.php');
include('../settings/config.php');
?>
<!DOCTYPE html>
<html>
<head>
<title>Selamat Datang</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Education Tutorial Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--bootstrap-->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!--coustom css-->
<link href="../css/style.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="../css/menu-profil.css">
<!--script-->
<script src="../js/jquery-1.11.0.min.js"></script>
<!-- js -->
<script src="../js/bootstrap.js"></script>
<!-- /js -->
<script type="text/javascript" src="../js/move-top.js"></script>
<script type="text/javascript" src="../js/easing.js"></script>
</head>
	<body>
<!--header-->
		<div class="header" id="home">
			<nav class="navbar navbar-default">
				<div class="container">
					<div class="col-md-1" style="margin-right:30px;">
						<img style="margin-top:15px; height:95px;" src="../images/logo.png">
					</div>
					<div class="col-md-10">
						<label style="margin-top:25px; color:#fff; font-size:25px">Sistem Informasi Akademik</label><br>
						<label style="color:#fff; font-size:25px">MI AL-HUDA</label>
					</div>
				</div>
			</nav>
<!--/script-->
		   <div class="clearfix"> </div>
		</div>
<!-- Top Navigation -->
<!--header-->
<!-- About -->
<section class="box-profil">

	 <?php
	 $user = $_SESSION['nip_nisn'];
      $query = mysql_query("SELECT * FROM tbl_guru INNER JOIN tbl_kelas ON tbl_kelas.wali_kelas = tbl_guru.nomer_pegawai WHERE nomer_pegawai = $user");
        if (mysql_num_rows($query) > 0) {
          $user  = mysql_fetch_array($query);
          $nama = $user['nama'];
          $nip = $user['nip'];
          $kelas =$user['id_kelas'];
          $jabatan = $user['jabatan'];
          $nopeg= $user['nomer_pegawai'];
          $foto = $user['foto'];  

        }
        else{
      $query1 = mysql_query("SELECT * FROM tbl_guru WHERE nomer_pegawai = $user");   
      $user  = mysql_fetch_array($query1);
          $nama = $user['nama'];
          $nip = $user['nip'];
          $kelas = "-";
          $jabatan = $user['jabatan'];
          $nopeg= $user['nomer_pegawai'];
          $foto = $user['foto'];         
        }
    ?>

	<div class="container">
		<div class="about-info-grids" style="margin-top:70px;">
			 <div class="col-md-3 abt-profil">
			 	<?php
			 		if ($foto == 'Belum Ada') {
			 			if ($user['jenis_kel'] == 'L') {
			 				$foto_tampil = '../../AdminKP/Admin/app/insert/foto/laki-laki.png';
			 				
			 			}
			 			elseif ($user['jenis_kel'] == 'P') {
			 				$foto_tampil = '../../AdminKP/Admin/app/insert/foto/perempuan.png';
			 			}
			 		}
			 		else{
			 			$foto_tampil = '../../AdminKP/Admin/app/insert/'.$user['foto'].'';
			 		}
			 	?>
			 	 <div class="testi-profile">
				 	<center><img src="<?php echo $foto_tampil;?>" class="img-responsive" alt=""/></center><br>
				 	<p class="text-center"><?php echo $nama;?></p>
          			<p class="text-center"><?php echo $user['nomer_pegawai'];?></p>
				 </div>
			 </div>
			
			 <div class="col-md-9">
			 		<div class="row"></div>
			 		<div class="row">
			 			<div class="alert alert-info alert-dismissible" role="alert" style="border-radius:0px">
  							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  							<strong>Assalamu'alaikum,</strong> <?php echo $nama; ?>
						</div>
			 		</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">Nama</div>
			 	 			<div class="col-md-10"> : <?php echo $nama; ?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Wali Kelas</div>
			 	 			<div class="col-md-8"> : <?php echo $kelas; ?> </div>
			 	 		</div>
			 	 	</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">NIP</div>
			 	 			<div class="col-md-10"> : <?php echo $nip;?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Jabatan</div>
			 	 			<div class="col-md-8"> : <?php echo $user['jabatan'];?></div>
			 	 		</div>
			 	 	</div><br>
			 	 	<div class="row">	
						<ol class="breadcrumb" style="background-color:#dff0d8; border-radius:0px;">
  							<li style="font-size:15px">Dashboard</li>
  							<li style="font-size:15px">Akademik</li>
  							<li class="active" style="font-size:15px">Nilai Semester</li>
						</ol>
			 	 	</div>
				 <!--<h3>Vestibulum congue neque quis ex fringilla, in pellentesque massa gravida.</h3>-->
			 </div>
			 <div class="clearfix"> </div>
		 </div>
	</div>
</section>
<section class="box-profil">
	<div class="container"><br>
		<div class="col-md-3 abt-profil">
				 <div>
			 		<ul class="nav nav-pills nav-stacked">
  						<li role="presentation" style="background-color:#006600;"><a href="profil.php" style="background-color:#006600; color:#fff"><span class="glyphicon glyphicon-home">
                            </span> Dashboard</a></li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"><span class="glyphicon glyphicon-th">
                            </span> Data Pribadi Guru</a>
                    		<div id="collapseTwo" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a style="color: #4d4d4d; font-size:14px" href="data_diri_guru.php">Lihat Data Pribadi Guru</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordio" href="#collapseThree"><span class="glyphicon glyphicon-th">
                            </span> Identitas Lembaga</a>
                        <div id="collapseThree" class="panel-collapse collapse">
                            <div class="panel-body">
                              <div class="row"><a style="color: #4d4d4d; font-size:14px" href="identitas_lembaga.php">Lihat Identitas Lembaga</a></div>
                            </div>
                        </div>
              </li>
              <li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTw"><span class="glyphicon glyphicon-th">
                            </span> Akademik</a>
                            <div id="collapseTw" class="panel-collapse collapse">
                            <div class="panel-body">
                              <div class="row"><a href="data_peserta_didik.php" style="color: #4d4d4d; font-size:14px">Peserta Didik</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="data_jadwal_mengajar.php" style="color: #4d4d4d; font-size:14px">Jadwal Mengajar</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="leger.php" style="color: #4d4d4d; font-size:14px">Lihat Ledger</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_kepribadian.php" style="color: #4d4d4d; font-size:14px">Nilai Kepribadian</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_tahfid.php" style="color: #4d4d4d; font-size:14px">Nilai Tahfid / Doa</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_semester.php" style="color: #4d4d4d; font-size:14px">Nilai Semester</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_raport.php" style="color: #4d4d4d; font-size:14px">Nilai Raport</a></div>
                            </div>
                        </div>
              </li>
  						<li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collap"><span class="glyphicon glyphicon-th">
                            </span> Ganti Password</a>
                            <div id="collap" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a href="ubah_password.php" style="color: #4d4d4d; font-size:14px">Ganti Password</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" href="<?php echo '../logout.php';?>"><span class="glyphicon glyphicon-log-out">
                            </span> Logout</a>
  						</li>
					</ul>
			 	</div>
			 </div>
		<div class="col-md-9">
			<?php
			$query_siswa = mysql_query("SELECT * FROM tbl_jadwal_pelajaran WHERE id_guru = '$nopeg' GROUP BY id_kelas");
			if (mysql_num_rows($query_siswa) < 1) {
                echo '<div class="alert alert-danger" role="alert" style="border-radius:0px">';
                echo '<h5>Maaf, Anda Belum Mempunyai Peserta Didik</h5>';
            	echo '</div>';
             }
             else{

             echo '<form action="tampil_siswa_nilai.php" method="POST">
			<div class="row">
			<div class="form-group">
				<div class="col-md-3" style="margin-top:5px"><label>Kelas</label></div>
				<div class="col-md-4">
				<select name="kelas" class="form-control">';
					
						$query_siswa = mysql_query("SELECT * FROM tbl_jadwal_pelajaran WHERE id_guru = '$nopeg' GROUP BY id_kelas");
						if (mysql_num_rows($query_siswa) < 1) {
                          echo '<option name="Belum_Ada">Peserta Didik Belum Ada</option>';
                        }
                        else{
						$no =1;
						while ($kls = mysql_fetch_array($query_siswa)) {
					
						echo '<option value='.$kls['id_kelas'].'>'.$kls['id_kelas'].'</option>';
					
						$no++;
					}}
					
			echo '</select>
				</div><br><br>
			</div>
			</div>
			<div class="row">
			<div class="form-group">
				<div class="col-md-3" style="margin-top:5px"><label></label></div>
				<div class="col-md-4">
				 <button class="btn " style="border-radius:0px; color:#fff; background-color:#006600;"><span class="glyphicon glyphicon-th"></span> Lihat Siswa</button>
				</div>
			</div>
			</div><br><br>
			</form>
			<div class="row">
				<div class="col-md-6">
				<h4><b>Nilai Semester</b></h4>
				</div>
				<div class="col-md-6">
				<button data-target="#cetak_nilai_semester" data-toggle="modal" class="btn" style="float:right; color:#fff; background-color:#006600; border-radius:0px;"><span class="glyphicon glyphicon-th"></span> Cetak Nilai Semester</button>
				</div>
			</div>
			<div class="row">
				<div class="table-responsive">
  				<table class="table table-bordered">
  					<thead>
  						<tr>
  							<th class="text-center" style="width: 5px; font-size:13px;">No</th>
  							<th class="text-center" style="width: 60px; font-size:13px;">NIS</th>
  							<th class="text-center" style="width: 170px; font-size:13px;">Nama Siswa</th>
  							<th class="text-center" style="width: 30px; font-size:13px;">Kelas</th>
  							<th class="text-center" style="width: 50px; font-size:13px;">Aksi</th>
  						</tr>	
  					</thead>';
  					
						$query_siswa1 = mysql_query("SELECT * FROM tbl_jadwal_pelajaran WHERE id_guru = '$nopeg' GROUP BY id_kelas ORDER BY id_kelas ASC limit 1");
						$kls1 = mysql_fetch_array($query_siswa1);
						$kel = $kls1['id_kelas'];
					
  					echo '<tbody>';
  						
  							$query = mysql_query("SELECT * FROM tbl_siswa1 WHERE kelas ='$kel' ORDER BY nis_lokal ASC");
  							$no=1;
  							while ($siswa = mysql_fetch_array($query)) {
  						
  					echo '<tr>
  							<td class="text-center" style="font-size:13px;">'.$no.'</td>
  							<td style="font-size:13px;">'.$siswa['nis_lokal'].'</td>
  							<td style="font-size:13px;">'.$siswa['nama_siswa'].'</td>
  							<td class="text-center" style="font-size:13px;">'.$siswa['kelas'].'</td>
  							<td class="text-center">
                  <a href="nilai_semester_person.php?id='.$siswa['nis_lokal'].'" class="btn btn-primary btn-sm" style="border-radius:0px">Olah Nilai</a>
                  <a href="edit_nilai_semester_person.php?id='.$siswa['nis_lokal'].'" class="btn btn-info btn-sm" style="border-radius:0px">Edit Nilai</a>
                </td>';
  						
  							$no++;
  							} 
  					
  				echo '</tbody>
  				</table>
				</div>
			</div>';

             }

			?>
			
			<!--Modal Cetak-->
                      <div class="modal fade" id="cetak_nilai_semester" tabindex="-1">
                        <div class="modal-dialog modal-md">
                          <div class="modal-content">
                              <div class="modal-header">
                              <button class="close" data-dismiss="modal" type="button">x</button>
                              <h4 class="modal-tittle" id="myModalLabel">Cetak Nilai Semester</h4>
                              </div>
                              <div class="modal-body">
                                <form action="../app/report/cetak_nilai_semester_guru.php" target="_blank" method="POST">
                                		<input type="hidden" name="nopeg" value="<?php echo $nopeg;?>">
                                        <div class="form-group"><br>
                                          <label class="col-md-3 control-label">Kelas</label>
                                        <div class="col-md-9">
                                         <select name="kelas" class="form-control">
                                        <?php
                                        	$kelas_nilai = mysql_query("SELECT * FROM tbl_jadwal_pelajaran WHERE id_guru = '$nopeg' GROUP BY id_kelas");
                                        	$no_nilai=1;
                                        	if (mysql_num_rows($kelas_nilai) == 0) {
                                        		$status_btn = 'disabled';
                                        	}
                                        	else{
                                        		$status_btn = '';
                                        	while ($kls_nilai = mysql_fetch_array($kelas_nilai)) {
                                        ?>
                                          	<option value="<?php echo $kls_nilai['id_kelas'];?>"><?php echo $kls_nilai['id_kelas'];?></option>
                                         <?php
                                         	$no_nilai++;
                                         	}
                                        	}
                                         ?>
                                         </select>
                                        </div><br>
                                        <div class="form-group"><br>
                                          <label class="col-md-3 control-label">Tahun Ajaran</label>
                                        <div class="col-md-9">
                                          <select name="thn_ajaran" class="form-control">
                                        <?php
                                        	$tahun_ajar = mysql_query("SELECT * FROM tbl_thn_ajaran GROUP BY kode_thn_ajaran ORDER BY id ASC");
                                        	$no_thn=1;
                                        	while ($thn=mysql_fetch_array($tahun_ajar)) {
                                        ?>
                                          	<option value="<?php echo $thn['kode_thn_ajaran'];?>"><?php echo $thn['kode_thn_ajaran'];?></option>
                                        <?php
                                        	$no_thn++;
                                        }
                                        ?>
                                          </select>
                                        </div><br>
                                        <div class="form-group"><br>
                                          <label class="col-md-3 control-label">Semester</label>
                                        <div class="col-md-9">
                                          <select name="semester" class="form-control">
                                          	<option value="Ganjil">Ganjil</option>
                                          	<option value="Genap">Genap</option>
                                          </select>
                                        </div><br>
                                        <div class="form-group"><br>
                                          <label class="col-md-3 control-label">Keterangan</label>
                                        <div class="col-md-9">
                                          <select name="keterangan" class="form-control">
                                          	<option value="UTS">UTS</option>
                                          	<option value="UAS">UAS</option>
                                          </select>
                                        </div><br>
                                        <div class="form-group"><br>
                                          <label class="col-md-3 control-label"></label>
                                        <div class="col-md-9" align="right">
                                          <button class="btn btn-flat btn-primary" style="border-radius:0px;" <?php echo $status_btn;?> type="submit"><i class="glyphicon glyphicon-print"></i> Cetak</button>
                                        </div><br>
                                </form>
                              </div>
                          </div>
                        </div>
                      </div>
                      <!--Modal Cetak-->

		</div>
	</div>
</section>
<section>

</section>
<div class="about">
	 <div class="container">
		 <div class="testimonals">
				
		   </div>
		   <div class="team">
			  
			 <div class="clearfix"> </div> 
		  </div>
	 </div>
</div>
<!-- /About -->
<!--copy-rights-->
<div class="copyright">
		<!-- container -->
		<div class="container">
			<div class="copyright-left">
			<p>MI Al-Huda © 2016 All rights reserved</p>
			</div>
			<div class="clearfix"> </div>
			
		</div>
		<!-- //container -->
	</div>
<!--/copy-rights-->
	</body>
</html>
