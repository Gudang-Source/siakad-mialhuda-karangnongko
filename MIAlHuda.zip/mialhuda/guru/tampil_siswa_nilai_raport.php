<?php
session_start();
include('../check_login.php');
include('../settings/config.php');
?>
<!DOCTYPE html>
<html>
<head>
<title>Selamat Datang</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Education Tutorial Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--bootstrap-->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!--coustom css-->
<link href="../css/style.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="../css/menu-profil.css">
<!--script-->
<script src="../js/jquery-1.11.0.min.js"></script>
<!-- js -->
<script src="../js/bootstrap.js"></script>
<!-- /js -->
<script type="text/javascript" src="../js/move-top.js"></script>
<script type="text/javascript" src="../js/easing.js"></script>
</head>
	<body>
<!--header-->
		<div class="header" id="home">
			<nav class="navbar navbar-default">
				<div class="container">
					<div class="col-md-1" style="margin-right:30px;">
						<img style="margin-top:15px; height:95px;" src="../images/logo.png">
					</div>
					<div class="col-md-10">
						<label style="margin-top:25px; color:#fff; font-size:25px">Sistem Informasi Akademik</label><br>
						<label style="color:#fff; font-size:25px">MI AL-HUDA</label>
					</div>
				</div>
			</nav>
<!--/script-->
		   <div class="clearfix"> </div>
		</div>
<!-- Top Navigation -->
<!--header-->
<!-- About -->
<section class="box-profil">

	 <?php
	 $user = $_SESSION['nip_nisn'];
      $query = mysql_query("SELECT * FROM tbl_guru INNER JOIN tbl_kelas ON tbl_kelas.wali_kelas = tbl_guru.nomer_pegawai WHERE nomer_pegawai = $user");
        if (mysql_num_rows($query) > 0) {
          $user  = mysql_fetch_array($query);
          $nama = $user['nama'];
          $nip = $user['nip'];
          $kelas =$user['id_kelas'];
          $jabatan = $user['jabatan'];
          $nopeg= $user['nomer_pegawai'];
          $foto = $user['foto'];
        }
        else{
      $query1 = mysql_query("SELECT * FROM tbl_guru WHERE nomer_pegawai = $user");   
      $user  = mysql_fetch_array($query1);
          $nama = $user['nama'];
          $nip = $user['nip'];
          $kelas = "-";
          $jabatan = $user['jabatan'];
          $nopeg= $user['nomer_pegawai'];
          $foto = $user['foto'];      
        }
    ?>

	<div class="container">
		<div class="about-info-grids" style="margin-top:70px;">
			 <div class="col-md-3 abt-profil">
			 	<?php
			 		if ($foto == 'Belum Ada') {
			 			if ($user['jenis_kel'] == 'L') {
			 				$foto_tampil = '../../AdminKP/Admin/app/insert/foto/laki-laki.png';
			 				
			 			}
			 			elseif ($user['jenis_kel'] == 'P') {
			 				$foto_tampil = '../../AdminKP/Admin/app/insert/foto/perempuan.png';
			 			}
			 		}
			 		else{
			 			$foto_tampil = '../../AdminKP/Admin/app/insert/'.$user['foto'].'';
			 		}
			 	?>
			 	 <div class="testi-profile">
				 	<center><img src="<?php echo $foto_tampil;?>" class="img-responsive" alt=""/></center><br>
				 	<p class="text-center"><?php echo $nama;?></p>
          			<p class="text-center"><?php echo $user['nomer_pegawai'];?></p>
				 </div>
			 </div>
			
			 <div class="col-md-9">
			 		<div class="row"></div>
			 		<div class="row">
			 			<div class="alert alert-info alert-dismissible" role="alert" style="border-radius:0px">
  							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  							<strong>Assalamu'alaikum,</strong> <?php echo $nama; ?>
						</div>
			 		</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">Nama</div>
			 	 			<div class="col-md-10"> : <?php echo $nama; ?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Wali Kelas</div>
			 	 			<div class="col-md-8"> : <?php echo $kelas; ?> </div>
			 	 		</div>
			 	 	</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">NIP</div>
			 	 			<div class="col-md-10"> : <?php echo $nip;?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Jabatan</div>
			 	 			<div class="col-md-8"> : <?php echo $user['jabatan'];?></div>
			 	 		</div>
			 	 	</div><br>
			 	 	<div class="row">	
						<ol class="breadcrumb" style="background-color:#dff0d8; border-radius:0px;">
  							<li style="font-size:15px">Dashboard</li>
  							<li style="font-size:15px">Akademik</li>
  							<li class="active" style="font-size:15px">Nilai Semester</li>
						</ol>
			 	 	</div>
				 <!--<h3>Vestibulum congue neque quis ex fringilla, in pellentesque massa gravida.</h3>-->
			 </div>
			 <div class="clearfix"> </div>
		 </div>
	</div>
</section>
<section class="box-profil">
	<div class="container"><br>
		<div class="col-md-3 abt-profil">
				 <div>
			 		<ul class="nav nav-pills nav-stacked">
  						<li role="presentation" style="background-color:#006600;"><a href="profil.php" style="background-color:#006600; color:#fff"><span class="glyphicon glyphicon-home">
                            </span> Dashboard</a></li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"><span class="glyphicon glyphicon-th">
                            </span> Data Pribadi Guru</a>
                    		<div id="collapseTwo" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a style="color: #4d4d4d; font-size:14px" href="data_diri_guru.php">Lihat Data Pribadi Guru</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordio" href="#collapseThree"><span class="glyphicon glyphicon-th">
                            </span> Identitas Lembaga</a>
                    		<div id="collapseThree" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a style="color: #4d4d4d; font-size:14px" href="identitas_lembaga.php">Lihat Identitas Lembaga</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTw"><span class="glyphicon glyphicon-th">
                            </span> Akademik</a>
                            <div id="collapseTw" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a href="data_peserta_didik.php" style="color: #4d4d4d; font-size:14px">Peserta Didik</a></div>
                        			<div style="color:#9A9598">-------------------------------</div>
                        			<div class="row"><a href="data_jadwal_mengajar.php" style="color: #4d4d4d; font-size:14px">Jadwal Mengajar</a></div>
                        			<div style="color:#9A9598">-------------------------------</div>
                        			<div class="row"><a href="leger.php" style="color: #4d4d4d; font-size:14px">Lihat Ledger</a></div>
                        			<div style="color:#9A9598">-------------------------------</div>
                        			<div class="row"><a href="nilai_kepribadian.php" style="color: #4d4d4d; font-size:14px">Nilai Kepribadian</a></div>
                        			<div style="color:#9A9598">-------------------------------</div>
                        			<div class="row"><a href="nilai_tahfid.php" style="color: #4d4d4d; font-size:14px">Nilai Tahfid / Doa</a></div>
                        			<div style="color:#9A9598">-------------------------------</div>
                        			<div class="row"><a href="nilai_semester.php" style="color: #4d4d4d; font-size:14px">Nilai Semester</a></div>
                        			<div style="color:#9A9598">-------------------------------</div>
                        			<div class="row"><a href="nilai_raport.php" style="color: #4d4d4d; font-size:14px">Nilai Raport</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collap"><span class="glyphicon glyphicon-th">
                            </span> Ganti Password</a>
                            <div id="collap" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a href="ubah_password.php" style="color: #4d4d4d; font-size:14px">Ganti Password</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" href="<?php echo '../logout.php';?>"><span class="glyphicon glyphicon-log-out">
                            </span> Logout</a>
  						</li>
					</ul>
			 	</div>
			 </div>
		<div class="col-md-9">
			<form action="tampil_siswa_nilai.php" method="POST">
			<div class="row">
			<div class="form-group">
				<div class="col-md-3" style="margin-top:5px"><label>Kelas</label></div>
				<div class="col-md-4">
				<select name="kelas" class="form-control">
					<?php
						$query_siswa = mysql_query("SELECT * FROM tbl_kelas WHERE wali_kelas = '$nopeg' GROUP BY id_kelas");
						if (mysql_num_rows($query_siswa) == 0) {
                          echo '<option name="Belum_Ada">Peserta Didik Belum Ada</option>';
                        }
                        else{
						$no =1;
						while ($kls = mysql_fetch_array($query_siswa)) {
					?>
						<option value="<?php echo $kls['id_kelas'];?>"><?php echo $kls['id_kelas'];?></option>
					<?php
						$no++;
					}}
					?>
				</select>
				</div><br><br>
			</div>
			</div>
			<div class="row">
			<div class="form-group">
				<div class="col-md-3" style="margin-top:5px"><label></label></div>
				<div class="col-md-4">
				 <button class="btn " style="border-radius:0px; color:#fff; background-color:#006600;"><span class="glyphicon glyphicon-th"></span> Lihat Siswa</button>
				</div>
			</div>
			</div>
			</form>
			<div class="row">
				<div class="col-md-12">
				<h4><b>Nilai Raport</b></h4>
				</div>
			</div>
			<div class="row">
				<div class="table-responsive">
  				<table class="table table-bordered">
  					<thead>
  						<tr>
  							<th class="text-center" style="width: 5px; font-size:13px;">No</th>
  							<th class="text-center" style="width: 60px; font-size:13px;">NIS</th>
  							<th class="text-center" style="width: 170px; font-size:13px;">Nama Siswa</th>
  							<th class="text-center" style="width: 30px; font-size:13px;">Kelas</th>
  							<th class="text-center" style="width: 50px; font-size:13px;">Aksi</th>
  						</tr>	
  					</thead>
  					<tbody>
  						<?php
  							$kls = $_POST['kelas'];

  							$query = mysql_query("SELECT * FROM tbl_siswa1 WHERE kelas ='$kls' ORDER BY nis_lokal ASC");
  							$no=1;
  							while ($siswa = mysql_fetch_array($query)) {
  						?>
  						<tr>
  							<td class="text-center" style="font-size:13px;"><?php echo $no;?></td>
  							<td style="font-size:13px;"><?php echo $siswa['nis_lokal'];?></td>
  							<td style="font-size:13px;"><?php echo $siswa['nama_siswa'];?></td>
  							<td class="text-center" style="font-size:13px;"><?php echo $siswa['kelas'];?></td>
  							<td class="text-center">
	                          <a href="nilai_raport_person.php?id=<?php echo $siswa['nis_lokal']; ?>" class="btn btn-primary btn-sm" style="border-radius:0px">Olah Nilai</a>
	                          <a href="edit_nilai_raport_person.php?id=<?php echo $siswa['nis_lokal']; ?>" class="btn btn-info btn-sm" style="border-radius:0px">Edit Nilai</a>
	                        </td>
  						<?php
  							$no++;
  							} 
  						?>
  					</tbody>
  				</table>
				</div>
			</div>
		</div>
	</div>
</section>
<section>

</section>
<div class="about">
	 <div class="container">
		 <div class="testimonals">
				
		   </div>
		   <div class="team">
			  
			 <div class="clearfix"> </div> 
		  </div>
	 </div>
</div>
<!-- /About -->
<!--copy-rights-->
<div class="copyright">
		<!-- container -->
		<div class="container">
			<div class="copyright-left">
			<p>MI Al-Huda © 2016 All rights reserved</p>
			</div>
			<div class="clearfix"> </div>
			
		</div>
		<!-- //container -->
	</div>
<!--/copy-rights-->
	</body>
</html>
