<?php
//jika session nip_nisn belum dibuat, atau session nip_nisn kosong
if (!isset($_SESSION['nip_nisn']) || empty($_SESSION['nip_nisn'])) {
	header('location:index.php');
	break;
}
?>