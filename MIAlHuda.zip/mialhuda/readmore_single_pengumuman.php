<?php
session_start();
if(isset($_SESSION['nip_nisn'])){
  if (isset($_SESSION['guru'])) {
    header('location:guru/profil.php');
  }
  else{
    header('location:siswa/profil.php');  
  }
}
include('settings/config.php');
$id_artikel = $_GET['id'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Selamat Datang</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Education Tutorial Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--bootstrap-->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="css/login.css">
<!--coustom css-->
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<!--script-->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- js -->
<script src="js/bootstrap.js"></script>
<!-- /js -->
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Open+Sans:300,300italic,400italic,400,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--/fonts-->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<!--script-->
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
			});
</script>
<!--/script-->
</head>
	<body>
<!--header-->
		<div class="header" id="home">
			<nav class="navbar navbar-default">
					<div class="banner-top banner-top1"></div>
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"> </span>
						<span class="icon-bar"> </span>
						<span class="icon-bar"> </span>
					</button>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-left margin-top cl-effect-2">
                <li><a href="index.php"><span data-hover="Home">Home</span></a></li>
                <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Info<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                          <li><a href="sejarah_singkat.php">Sejarah Singkat</a></li>
                          <li role="separator" class="divider"></li>
                          <li><a href="visi_misi.php">Visi dan Misi</a></li>
                          <li role="separator" class="divider"></li>
                          <li><a href="sarana.php">Sarana dan Prasarana</a></li>
                          <li role="separator" class="divider"></li>
                          <li><a href="proker.php">Program Kerja</a></li>
                        </ul>
                    </li>
                <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Pengumuman<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                          <li><a href="readmore_pengumuman.php">Pengumuman</a></li>
                          <li role="separator" class="divider"></li>
                          <li><a href="readmore_agenda.php">Agenda</a></li>
                          <li role="separator" class="divider"></li>
                          <li><a href="readmore_berita.php">Berita</a></li>
                          <li role="separator" class="divider"></li>
                          <li><a href="readmore_prestasi.php">Prestasi</a></li>
                          <li role="separator" class="divider"></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Pendaftaran<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                          <li><a href="#">Cara Pendaftaran</a></li>
                          <li role="separator" class="divider"></li>
                          <li><a href="#">Pendaftaran</a></li>
                          <li role="separator" class="divider"></li>
                          <li><a href="#">Siswa Terdaftar</a></li>
                        </ul>
                    </li>
                <li><a href="gallery.php"><span data-hover="Gallery">Galeri</span></a></li>
                <li><a href="contact.php"><span data-hover="Contact">Kontak</span></a></li>
              </ul>
							<div class="clearfix"> </div>
						</div><!-- /.navbar-collapse -->
				<!-- /.container-fluid -->
				<div class="login-pop">
						<div id="loginpop"><a href="#" role="button" data-toggle="modal" data-target="#login-modal"><span>Login</span></a>
					    </div>
			    </div>

			  <!-- BEGIN # MODAL LOGIN -->
        <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
            <div class="modal-dialog">
          <div class="modal-content">
          <div class="modal-header" align="center">
            <img class="" id="img_logo" src="images/logo.png">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
            </button>
          </div>
                <!-- Begin # DIV Form -->
                    <!-- Begin # Login Form -->
                    <form accept-charset="UTF-8" role="form" method="POST" action="autentifikasi.php">
                      <fieldset>
                    <div class="modal-body">
                <input name="nip_nisn" class="form-control" type="text" placeholder="Username" required>
                <input name="password" class="form-control" type="password" placeholder="Password" required>
                  </div>
                <div class="modal-footer">
                        <div>
                            <button type="submit" class="btn btn-primary btn-lg btn-block">Login</button>
                        </div>
                </div>
                </fieldset>
                    </form>
                    <!-- End # Login Form -->
                <!-- End # DIV Form -->
                
          </div>
          </div>
        </div>
          <!-- END # MODAL LOGIN -->

			    <script src="js/menu_jquery.js"></script>
					    </div>
			</nav>
<!--/script-->
		   <div class="clearfix"> </div>
</div>
<!-- Top Navigation -->
<!--header-->
<!--section-->
<section class="box-news">
  <div class="container">
    <div class="about-info-grids">
      <div class="row">
        <div class="col-md-8">
        <?php
          $query = mysql_query("SELECT * FROM tbl_artikel WHERE id_artikel = '$id_artikel'");
          $data = mysql_fetch_array($query);

          $jml_view = $data['jml_view'];
          $jml_view_new = $jml_view + 1;
          $update = mysql_query("UPDATE tbl_artikel SET jml_view = '$jml_view_new' WHERE id_artikel = '$id_artikel'");
        ?>
        <div class="panel panael-default" style="border-radius:0">
          <div class="panel-body" id="flag"><?php echo date("d F Y,", strtotime($data['tanggal']));?></div>
          <div class="panel-body">
            <h3 style="padding-top:0px"><b><?php echo ucwords($data['keterangan']);?> : <?php echo $data['judul'];?></b></h3>
            <div class="row">
              <a class="col-md-12"><i class="glyphicon glyphicon-user"></i> Post By Admin, <i class="glyphicon glyphicon-calendar"></i> On <?php echo date("d F Y,", strtotime($data['tanggal']));?></a>
            </div>
            <div class="row">
              <div class="col-md-12"><br>
              <p class="text-justify">
                <?php echo $data['isi'];?>
              </p>
              </div>
            </div>
          </div>
        </div>
        </div>
        <!--=========================================-->
        <div class="col-md-4">
          <div id="content" class="row">
            <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
              <li class="active col-md-6"><a href="#populer-post" data-toggle="tab" style="text-align:center"><b>Populer Post</b></a></li>
              <li class="col-md-6"><a href="#recent-post" data-toggle="tab"><b>Recent Post</b></a></li>
            </ul>
          </div>
          <div id="my-tab-content" style="background:#fff" class="tab-content">
            <div class="tab-pane active col-md-12" style="background:#fff" id="populer-post">
            <?php
              $Populer = mysql_query("SELECT * FROM tbl_artikel ORDER BY jml_view DESC LIMIT 3");
              $no =1;
              while ($pop = mysql_fetch_array($Populer)) {
            ?>
            <div class="row">
              <a href="readmore_single_pengumuman.php?id=<?php echo $pop['id_artikel'];?>">
              <div class="notice2 notice-sm col-md-12">
              <div class="col-md-3">
                <img src="../AdminKP/Admin/app/insert/<?php echo $pop['gambar'];?>" class="img-responsive" style="width:70px; height:50px">
              </div>
              <div class="col-md-9">
                <strong><?php echo substr($pop['judul'], 0, 55);?></strong>
              </div>
              </div>
              </a>
            </div>
            <?php
              $no++;
              }
            ?>
          </div>
          <div class="tab-pane col-md-12" style="background:#fff" id="recent-post">
            <?php
              $Recent = mysql_query("SELECT * FROM tbl_artikel ORDER BY id_artikel DESC LIMIT 3");
              $no =1;
              while ($rec = mysql_fetch_array($Recent)) {
            ?>
            <div class="row">
              <a href="readmore_single_pengumuman.php?id=<?php echo $pop['id_artikel'];?>">
              <div class="notice2 notice-sm col-md-12">
              <div class="col-md-3">
                <img src="../AdminKP/Admin/app/insert/<?php echo $rec['gambar'];?>" class="img-responsive" style="width:70px; height:50px">
              </div>
              <div class="col-md-9">
                <strong><?php echo substr($rec['judul'], 0, 55);?></strong>
              </div>
              </div>
              </a>
            </div>
            <?php
              $no++;
              }
            ?>
          </div>
          </div>
        </div>
        <!--=========================================-->
      </div>
       <!---->
      <div class="row">
        <div class="col-md-8">
        <div class="panel panael-default" style="border-radius:0">
          <div class="panel-body">
            <h3 style="padding-top:0px"><b>Leave a comment</b></h3>
            <div class="row">
              <div class="col-md-12">
                <form name="komentar" class="form-horizontal" action="comment.php" method="POST" style="padding:15px">
                  <div class="form-group">
                    <input type="hidden" name="id_artikel" value="<?php echo $data['id_artikel'];?>">
                    <input type="hidden" name="keterangan" value="<?php echo $data['keterangan'];?>">
                    <label>Nama</label>
                    <input type="text" class="form-control" name="nama"  placeholder="Nama">
                  </div>
                  <div class="form-group">
                    <label>Email</label>
                    <input type="email" class="form-control" name="email" placeholder="Email@example.com">
                  </div>
                  <div class="form-group">
                    <label>Comment</label>
                    <textarea name ="komentar" class="form-control" rows="5"></textarea>
                  </div>
                  <div class="form-group" style="float:right">
                    <button class="btn btn-flat btn-primary " type="submit" ><i class="glyphicon glyphicon-send"></i> Kirim</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        </div>
      </div>
      <!---->
      <div class="row">
        <div class="col-md-8">
        <div class="panel panael-default" style="border-radius:0">
          <div class="panel-body">
            <h3 style="padding-top:0px"><b>Comments</b></h3>
            
            <?php
              $keterangan =$data['keterangan'];
              $komen = mysql_query("SELECT * FROM tbl_komentar WHERE id_artikel = '$id_artikel' AND keterangan = '$keterangan' ORDER BY id_komentar DESC");
              $nom=1;
              while ($dat=mysql_fetch_array($komen)) {              
            ?>
            <div class="row">
              <div class="col-md-12">
                <div class="panel panel-default" style="border-radius:0px">
                <div class="panel-body">
                  <div class="row">
                    <div class="col-md-2">
                      <img src="images/avatar.png" class="img-responsive" style="border: 2px solid #ccc;">
                    </div>
                    <div class="col-md-10">
                      <h5><b><?php echo $dat['nama_komentar'];?></b>, <i style="color:grey"><?php echo $dat['email_komentar'];?></i></h5>
                      <p>
                        <?php echo $dat['komentar'];?>     
                      </p>
                      <h5><b style="color:#2793FD">On <?php echo $dat['tgl_komentar'];?>, <?php echo $dat['jam_komentar'];?></b></h5>
                    </div>
                  </div>
                </div>
                </div>
              </div>
            </div>
            <?php
              $nom++;
              }
            ?>
            </div>
          </div>
        </div>
        </div>
      </div>
      <!---->
    </div>
  </div>
</section>
<!--section-->
<!--copy-rights-->
<div class="copyright">
		<!-- container -->
		<div class="container">
			<div class="copyright-left">
			<p>MI AL HUDA © 2016 All rights reserved.</p>
			</div>
			<div class="clearfix"> </div>
			
		</div>
		<!-- //container -->
				<!---->
<script type="text/javascript">
		$(document).ready(function() {
				/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
				*/
		$().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
<a href="#to-top" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!----> 
	</div>
<!--/copy-rights-->
	</body>
</html>
