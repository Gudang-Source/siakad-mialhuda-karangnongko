<?php
include('settings/config.php');
 
session_start();
 
//tangkap data dari form login
$nip_nisn = $_POST['nip_nisn'];
$password = md5($_POST['password']);
 
//untuk mencegah sql injection
//kita gunakan mysql_real_escape_string
$nip_nisn = mysql_real_escape_string($nip_nisn);
$password = mysql_real_escape_string($password);
 
//cek data yang dikirim, apakah kosong atau tidak
if (empty($nip_nisn) && empty($password)) {
    //kalau username dan password kosong
    header('location:index.php?error=1');
    break;
} else if (empty($nip_nisn)) {
    //kalau username saja yang kosong
    header('location:index.php?error=2');
    break;
} else if (empty($password)) {
    //kalau password saja yang kosong
    //redirect ke halaman index
    header('location:index.php?error=3');
    break;
}

$cek  = mysql_query("SELECT * FROM tbl_user_login WHERE nip_nisn='$nip_nisn' AND password='$password'");
$data = mysql_fetch_array($cek);
 
if (mysql_num_rows($cek) > 0) {

    $status = $data['status'];

    if($status == 'guru'){
        $_SESSION['nip_nisn'] = $nip_nisn;
        header('location: guru/profil.php');
    }
    else if($status == 'siswa'){
        $_SESSION['nip_nisn'] = substr($nip_nisn, -8);
        header('location: siswa/profil.php');
    }
    //kalau username dan password sudah terdaftar di database
} else {
    //kalau username ataupun password tidak terdaftar di database
    echo "<script>alert('NIP/NISN atau password salah'); window.location = 'index.php'</script>";
}

?>