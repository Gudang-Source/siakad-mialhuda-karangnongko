<?php
	$host ='localhost';
	$user ='root';
	$pass ='';

	$dbname ='mialhuda_database';

	//koneksi database
	$connect =mysql_connect($host,$user,$pass) or die (mysql_error());
	
	//pilih database
	$dbselect=mysql_select_db($dbname,$connect);

	//cek error
	if(!$connect){
		echo "koneksi gagal<br>", mysql_error($connect);
	}
	else{
		mysql_select_db($dbname);
	}
?>