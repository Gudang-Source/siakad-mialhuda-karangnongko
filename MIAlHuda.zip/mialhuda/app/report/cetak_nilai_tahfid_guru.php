<?php
session_start();
include('../../settings/config.php');

ob_start();

$nopeg= $_POST['nopeg'];
$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];

$judul_tahfid = mysql_query("SELECT * FROM tbl_tahfid_doa ORDER BY id_tahfid_doa ASC");

$tgl = date('d-m-Y');
?>

<html>
    <head>
    </head>

    <body><br><br>
        <div class="row">
        <div class="col-md-2">
            <img src='mi_alhuda.png' width='50' style="margin-left:15px;">
            <label style="margin-top:-25px; margin-left:15px; font-size:18px">Laporan Nilai Tahfid / Doa Tahun Ajaran <?php echo $thn_ajaran;?> (<?php echo $semester;?>)</label><br><br>
            <label style="margin-top:-45px; margin-left:85px; font-size:16px">MI Al-Huda Karangnongko</label>
        </div>
        </div>
        <div style="position: absolute; right: 1mm; top: 3mm; text-align: right; color:grey;"><i>Cetak Tanggal : <?php echo $tgl;?></i></div>
        <br>
            <table style="font-size:11px;" border="1" cellspacing="0">
                <thead>
                <tr>
                    <th style="padding: 5px; width:10px; text-align:center; ">No</th>
                    <th style="padding: 5px; width:100px; text-align:center; ">Nama</th>
                    <th style="padding: 5px; width:50px; text-align:center; ">Nilai</th>
                </tr>
                </thead>
                <tbody>
                    <?php
                        $nilai_tahfid = mysql_query("SELECT * FROM tbl_nilai_tahfid_doa
                                                      INNER JOIN tbl_siswa1 ON tbl_siswa1.nis_lokal = tbl_nilai_tahfid_doa.nis_lokal
                                                      WHERE id_wali = '$nopeg' AND thn_ajaran='$thn_ajaran' AND semester='$semester' GROUP BY tbl_nilai_tahfid_doa.nis_lokal");
                        $no=1;
                        while ($nilai = mysql_fetch_array($nilai_tahfid)) {
                        $nis = $nilai['nis_lokal'];
                    ?>
                    <tr>
                    <td style="padding: 5px; text-align:center;"><?php echo $no;?></td>
                    <td style="padding: 5px;"><?php echo $nilai['nama_siswa'];?></td>
                    <?php
                        $nilai_tid = mysql_query("SELECT nilai_tahfid FROM tbl_nilai_tahfid_doa
                                                WHERE nis_lokal='$nis' AND id_wali = '$nopeg' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");
                        
                        $no_nil=1;
                        $rata1=0;
                        while ($nil =mysql_fetch_array($nilai_tid)) {
                        $rata1 = $rata1 + $nil['nilai_tahfid'];

                    ?>
                    <?php
                        $no_nil++;
                    }
                    $hasil_rata = round($rata1 / mysql_num_rows($judul_tahfid), 0, PHP_ROUND_HALF_EVEN);
                    ?>
                    <td style="padding: 5px; text-align:center;"><?php echo $hasil_rata;?></td>
                    </tr>
                    <?php
                        $no++;
                    }
                    ?>
                </tbody>
            </table><br>
            
    </body>
</html>
<?php
    include('../../settings/config.php');
    $thn_ajaran = $_POST['thn_ajaran'];
    $semester = $_POST['semester'];

    $filename="Nilai Tahfid_Doa (".$thn_ajaran." / ".$semester.").pdf";
    $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15',array(15, 10, 20, 10));  
        $html2pdf->setDefaultFont('Arial');  
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));  
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

?>