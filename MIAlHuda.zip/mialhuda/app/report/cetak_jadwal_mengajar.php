<?php
session_start();
include('../../settings/config.php');

ob_start();

$nopeg = $_GET['id'];

$data_guru = mysql_query("SELECT * FROM tbl_guru WHERE nomer_pegawai = '$nopeg' ORDER BY nomer_pegawai ASC ");
$guru = mysql_fetch_array($data_guru);
$tgl = date('d-m-Y');
?>

<html>
    <head>
        
    </head>

    <body><br><br>
        <div class="row">
        <div class="col-md-2">
            <img src='mi_alhuda.png' width='50' style="margin-left:15px;">
            <label style="margin-top:-25px; margin-left:15px; font-size:18px">Jadwal Mengajar</label><br><br>
            <label style="margin-top:-45px; margin-left:85px; font-size:16px">MI Al-Huda Karangnongko</label>
        </div>
        </div>
        <div style="position: absolute; right: 1mm; top: 3mm; text-align: right; color:grey;"><i>Cetak Tanggal : <?php echo $tgl;?></i></div>
        <br>
            <div style="margin-left:13px;">
            <table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="50">Nama</td>
                        <td width="10">:</td>
                        <td width="250"><?php echo $guru['nama'];?></td>
                    </tr>
                    <tr>
                        <td width="50">NIP</td>
                        <td width="10">:</td>
                        <td width="250"><?php echo $guru['nip'];?></td>
                    </tr>
                </tbody>
            </table>
            </div><br>
            <table align="center" style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <thead>
                <tr>
                    <th style="padding: 5px; width:20px; text-align:center; ">No</th>
                    <th style="padding: 5px; width:50px; text-align:center; ">Hari</th>
                    <th style="padding: 5px; width:200px; text-align:center; ">Mata Pelajaran</th>
                    <th style="padding: 5px; width:130px; text-align:center; ">Jam</th>
                    <th style="padding: 5px; width:50px; text-align:center; ">Kelas</th>
                </tr>
                </thead>
                <tbody>
                    <?php
                    $nopeg = $_GET['id'];
                    $query = mysql_query("SELECT * FROM tbl_jadwal_pelajaran
                                          INNER JOIN tbl_mapel ON tbl_mapel.id_mapel=tbl_jadwal_pelajaran.id_mapel
                                          INNER JOIN tbl_hari ON tbl_hari.id = tbl_jadwal_pelajaran.hari
                                          WHERE tbl_jadwal_pelajaran.id_guru='$nopeg' ORDER BY tbl_hari.id");

                    if (mysql_num_rows($query) == 0) {
                        echo '<div><h4>Maaf, Jadwal Mengajar Anda Belum Ada</h4></div>';
                    }

                    else{
                    $no=1;
                    while ($data = mysql_fetch_array($query)) {
                    ?>
                    <tr>
                    <td style="padding: 5px; text-align:center;"> <?php echo $no;?> </td>
                    <td style="padding: 5px;"> <?php echo $data['hari'];?> </td>
                    <td style="padding: 5px;"> <?php echo $data['nama_mapel'];?> </td>
                    <td style="padding: 5px; text-align:center;"> <?php echo $data['jam_mulai'];?> - <?php echo $data['jam_selesai'];?> </td>
                    <td style="padding: 5px; text-align:center;"> <?php echo $data['id_kelas'];?> </td>
                    </tr>
                    <?php
                        $no++;
                    }}
                    ?>
                
                </tbody>
            </table><br>
    </body>
</html>
<?php
    include('../../settings/config.php');
   

    $filename="Jadwal Mengajajar.pdf";
    $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15',array(15, 0, 20, 0));  
        $html2pdf->setDefaultFont('Arial');  
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));  
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

?>