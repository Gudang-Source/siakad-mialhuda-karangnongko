<?php
session_start();
include('../../settings/config.php');

ob_start();

$nopeg= $_POST['nopeg'];
$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];

$judul_kepribadian = mysql_query("SELECT * FROM tbl_kepribadian ORDER BY id_kepribadian ASC");

$tgl = date('d-m-Y');
?>

<html>
    <head>
    </head>

    <body><br><br>
        <div class="row">
        <div class="col-md-2">
            <img src='mi_alhuda.png' width='50' style="margin-left:15px;">
            <label style="margin-top:-25px; margin-left:15px; font-size:18px">Laporan Nilai Kepribadian Tahun Ajaran <?php echo $thn_ajaran;?> (<?php echo $semester;?>)</label><br><br>
            <label style="margin-top:-45px; margin-left:85px; font-size:16px">MI Al-Huda Karangnongko</label>
        </div>
        </div>
        <div style="position: absolute; right: 1mm; top: 3mm; text-align: right; color:grey;"><i>Cetak Tanggal : <?php echo $tgl;?></i></div>
        <br>
            <table style="font-size:11px;" border="1" cellspacing="0">
                <thead>
                <tr>
                    <th style="padding: 5px; width:10px; text-align:center; ">No</th>
                    <th style="padding: 5px; width:100px; text-align:center; ">Nama</th>
                    <?php
                        $no_judul=1;
                        while ($judul = mysql_fetch_array($judul_kepribadian)) {
                    ?>
                    <th style="padding: 5px; width:20px; text-align:center; "><?php echo $judul['id_kepribadian'];?></th>
                    <?php
                        $no_judul++;
                    }
                    ?>
                    <th style="padding: 5px; width:50px; text-align:center; ">Rata-rata</th>
                </tr>
                </thead>
                <tbody>
                    <?php
                        $nilai_kepribadian = mysql_query("SELECT * FROM tbl_nilai_kepribadian 
                                                          INNER JOIN tbl_siswa1 ON tbl_siswa1.nis_lokal = tbl_nilai_kepribadian.nis_lokal
                                                          WHERE id_wali = '$nopeg' AND thn_ajaran='$thn_ajaran' AND semester='$semester' GROUP BY tbl_nilai_kepribadian.nis_lokal");
                        $no=1;
                        while ($nilai = mysql_fetch_array($nilai_kepribadian)) {
                        $nis = $nilai['nis_lokal'];
                    ?>
                    <tr>
                    <td style="padding: 5px; text-align:center;"><?php echo $no;?></td>
                    <td style="padding: 5px;"><?php echo $nilai['nama_siswa'];?></td>
                    <?php
                        $nilai_kp = mysql_query("SELECT nilai_kepribadian FROM tbl_nilai_kepribadian 
                                                WHERE nis_lokal='$nis' AND id_wali = '$nopeg' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");
                        
                        $no_nil=1;
                        $rata1=0;
                        while ($nil =mysql_fetch_array($nilai_kp)) {
                        $rata1 = $rata1 + $nil['nilai_kepribadian'];

                    ?>
                    <td style="padding: 5px; text-align:center;"><?php echo $nil['nilai_kepribadian'];?></td>
                    <?php
                        $no_nil++;
                    }
                    $hasil_rata = round($rata1 / mysql_num_rows($judul_kepribadian), 0, PHP_ROUND_HALF_EVEN);
                    ?>
                    <td style="padding: 5px; text-align:center;"><?php echo $hasil_rata;?></td>
                    </tr>
                    <?php
                        $no++;
                    }
                    ?>
                </tbody>
            </table><br>
            <table  style="font-size:11px;" border="0" cellspacing="0">
                <tbody>
                <tr>
                <td><b>Keterangan :</b></td>
                </tr>
                <?php
                $ket_kepribadian = mysql_query("SELECT * FROM tbl_kepribadian ORDER BY id_kepribadian ASC");
                $no_ket=1;
                while ($ket = mysql_fetch_array($ket_kepribadian)) {
                ?>
                <tr>
                <td width="5px;"><?php echo $ket['id_kepribadian'];?></td>
                <td width="10px;">:</td>
                <td><?php echo $ket['nama_kepribadian'];?></td>
                </tr>
                <?php
                $no_ket++;
                }
                ?>
                </tbody>
            </table>
            
    </body>
</html>
<?php
    include('../../settings/config.php');
    $thn_ajaran = $_POST['thn_ajaran'];
    $semester = $_POST['semester'];

    $filename="Nilai Kepribadian (".$thn_ajaran." / ".$semester.").pdf";
    $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('L','A4','en', false, 'ISO-8859-15',array(15, 10, 20, 10));  
        $html2pdf->setDefaultFont('Arial');  
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));  
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

?>