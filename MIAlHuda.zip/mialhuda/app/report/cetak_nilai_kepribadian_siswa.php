<?php
session_start();
include('../../settings/config.php');

ob_start();

$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];
$nama = $_POST['nama_tampil'];
$nisn = $_POST['nisn_tampil'];

$siswa = mysql_query("SELECT * FROM tbl_siswa1 WHERE nis_lokal = '$nisn' ");
$sis = mysql_fetch_array($siswa);

$cek_nilai = mysql_query("SELECT * FROM tbl_nilai_kepribadian WHERE nis_lokal='$nisn' AND thn_ajaran='$thn_ajaran' AND semester='$semester' ");
$cek = mysql_fetch_array($cek_nilai);
$kelas = $cek['id_kelas'];
$wali = $cek['id_wali'];

$wali_kel = mysql_query("SELECT * FROM tbl_guru WHERE nomer_pegawai = '$wali' ");
$wal = mysql_fetch_array($wali_kel);

$tgl = date('d-m-Y');
?>

<html>
    <head>
        
    </head>

    <body><br><br>
        <div><br><br>
            <img src='mi_alhuda.png' width='50' style="margin-left:15px;">
            <label style="margin-top:-25px; margin-left:15px; font-size:18px">Hasil Nilai Kepribadian <?php echo $thn_ajaran;?> (<?php echo $semester;?>)</label><br><br>
            <label style="margin-top:-45px; margin-left:85px; font-size:16px">MI Al-Huda Karangnongko</label>
        </div>
        <div>
            <table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="50">Nama</td>
                        <td width="10">:</td>
                        <td width="250"><?php echo $sis['nama_siswa'];?></td>
                        <td>Kelas</td>
                        <td width="10">:</td>
                        <td width="300"><?php echo $kelas;?></td>
                    </tr>
                    <tr>
                        <td width="50">NIS</td>
                        <td width="10">:</td>
                        <td width="250"><?php echo $sis['nis_lokal'];?></td>
                        <td>Wali Kelas</td>
                        <td width="10">:</td>
                        <td width="300"><?php echo $wal['nama'];?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div style="position: absolute; right: 1mm; top: 3mm; text-align: right; color:grey;"><i>Cetak Tanggal : <?php echo $tgl;?></i></div>
        <br>
            <table align="center" style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <thead>
                <tr>
                    <th style="padding: 5px; width:50px; text-align:center; ">No</th>
                    <th style="padding: 5px; width:200px; text-align:center; ">Kepribadian</th>
                    <th style="padding: 5px; width:130px; text-align:center; ">Nilai Angka</th>
                </tr>
                </thead>
                <tbody>
                    <?php

                    $thn_ajaran = $_POST['thn_ajaran'];
                    $semester = $_POST['semester'];
                    $nisn = $_POST['nisn_tampil'];

                    $lihat_nilai = mysql_query("SELECT * FROM tbl_nilai_kepribadian
                                                INNER JOIN tbl_kepribadian ON tbl_kepribadian.id_kepribadian = tbl_nilai_kepribadian.id_kepribadian
                                                WHERE nis_lokal = '$nisn' AND thn_ajaran LIKE '%$thn_ajaran%' AND semester LIKE '%$semester%'  ");

                    
                    $no=1;
                    while ($data = mysql_fetch_array($lihat_nilai)) {
                    ?>
                    <tr>
                    <td style="padding: 5px; text-align:center;"> <?php echo $no;?> </td>
                    <td style="padding: 5px;"> <?php echo $data['nama_kepribadian'];?> </td>
                    <td style="padding: 5px; text-align:center;"> <?php echo $data['nilai_kepribadian'];?></td>
                    </tr>
                    <?php
                        $no++;
                    }
                    ?>
                
                </tbody>
            </table><br><br>
            <table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="50">Mengetahui,</td>
                    </tr>
                    <tr>
                        <td width="150">Orang Tua / Wali </td>
                        <td width="400"></td>
                        <td>Wali Kelas</td>
                    </tr>
                    <tr>
                        <td height="35" width="150"></td>
                        <td width="400"></td>
                        <td height="35"></td>
                    </tr>
                    <tr>
                        <td width="150">............................</td>
                        <td width="380"></td>
                        <td><?php echo $wal['nama'];?></td>
                    </tr>
                    <tr>
                        <td width="150"></td>
                        <td width="350"></td>
                        <td>NIP : <?php echo $wal['nip'];?></td>
                    </tr>
                </tbody>
            </table>
    </body>
</html>
<?php
    include('../../settings/config.php');
    $nisn = $_POST['nisn_tampil'];

    $siswa = mysql_query("SELECT * FROM tbl_siswa1 WHERE nis_lokal = '$nisn' ");
    $sis = mysql_fetch_array($siswa);
    
    $filename="[".$sis['nama_siswa']."] Nilai Kepribadian Th Ajaran ".$thn_ajaran."_".$keterangan."_".$semester.".pdf";
    $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15',array(15, 0, 20, 10));  
        $html2pdf->setDefaultFont('Arial');  
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));  
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

?>