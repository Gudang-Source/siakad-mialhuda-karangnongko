<?php
session_start();
include('../../settings/config.php');

ob_start();

$nopeg = $_GET['id'];
$data_guru = mysql_query("SELECT * FROM tbl_guru
                          INNER JOIN tbl_kelas ON tbl_kelas.wali_kelas = tbl_guru.nomer_pegawai
                          WHERE tbl_guru.nomer_pegawai = '$nopeg'");
$guru= mysql_fetch_array($data_guru);


if ($guru['jenis_kel'] == 'L') {
    $JK = 'Laki-laki';
}
elseif ($guru['jenis_kel'] == 'P') {
    $JK = 'Perempuan';
}

?>

<html>
    <head>
        
    </head>

    <body><br><br>
        <div>
            <img src='mi_alhuda.png' width='50' style="margin-left:10px;">
            <label style="font-size: 18px; margin-left:200px; margin-top:-30px;">Biodata Guru  Pengajar</label><br>
            <label style="font-size: 18px; margin-left:220px; margin-top:-30px;">MI AL HUDA KARANGNONGKO</label><br><br>
        </div>
        <table align="left" style="font-size:14px;" border="0">
            <tbody>
            <tr>
                <td style="padding:5px;" width="150">Nomer Pegawai</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['nomer_pegawai'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">NIP</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['nip'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Nama</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['nama'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Tempat, Tanggal Lahir</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['tempat_lahir'];?>, <?php echo date("d F Y", strtotime($guru['tgl_lahir']));?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Alamat</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['alamat'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Jenis Kelamin</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $JK;?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Nama Ibu</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['nama_ibu'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Jabatan</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['jabatan'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Status</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['status'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Sertifikasi</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['sertifikasi'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Kualifikasi Pendidikan</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['pendidikan_akhir'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Tahun Lulus Sertifikasi</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['thn_lulus_setifikasi'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">NUPTK</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['nuptk'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">NRG</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['nrg'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">PEG ID</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['id_peg'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Wali Kelas</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $guru['id_kelas'];?></td>
            </tr>
            </tbody>
        </table>
            
    </body>
</html>
<?php
    include('../../settings/config.php');

    $nopeg = $_GET['id'];
    $data_guru = mysql_query("SELECT * FROM tbl_guru WHERE nomer_pegawai = '$nopeg'");
    $guru= mysql_fetch_array($data_guru);

    
    $filename="".$guru['nama'].".pdf";
    $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15',array(20, 0, 20, 20));  
        $html2pdf->setDefaultFont('Arial');  
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));  
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

?>