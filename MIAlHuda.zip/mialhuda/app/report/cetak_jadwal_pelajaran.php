<?php
session_start();
include('../../settings/config.php');

ob_start();

$kelas = $_GET['kelas'];
$tgl = date('d-m-Y');
?>

<html>
    <head>
        
    </head>

    <body><br><br>
        <div class="row">
        <div class="col-md-2">
            <img src='mi_alhuda.png' width='50' style="margin-left:15px;">
            <label style="margin-top:-25px; margin-left:15px; font-size:18px">Jadwal Pelajaran Kelas <?php echo $kelas;?></label><br><br>
            <label style="margin-top:-45px; margin-left:85px; font-size:16px">MI Al-Huda Karangnongko</label>
        </div>
        </div>
        <div style="position: absolute; right: 1mm; top: 3mm; text-align: right; color:grey;"><i>Cetak Tanggal : <?php echo $tgl;?></i></div>
        <br>
            <table align="center" style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <thead>
                <tr>
                    <th style="padding: 5px; width:50px; text-align:center; ">Hari</th>
                    <th style="padding: 5px; width:200px; text-align:center; ">Mata Pelajaran</th>
                    <th style="padding: 5px; width:130px; text-align:center; ">Jam</th>
                    <th style="padding: 5px; width:150px; text-align:center; ">Pengajar</th>
                </tr>
                </thead>
                <tbody>
                    <?php
                    $kelas = $_GET['kelas'];
                    $query = mysql_query("SELECT * FROM tbl_jadwal_pelajaran 
                                          INNER JOIN tbl_mapel ON tbl_mapel.id_mapel = tbl_jadwal_pelajaran.id_mapel
                                          INNER JOIN tbl_hari ON tbl_hari.id = tbl_jadwal_pelajaran.hari
                                          INNER JOIN tbl_guru ON tbl_guru.nomer_pegawai = tbl_jadwal_pelajaran.id_guru
                                          WHERE id_kelas = '$kelas' ORDER BY tbl_hari.id ");

                    if (mysql_num_rows($query) == 0) {
                        echo '<div><h4>Maaf, Jadwal Pelajaran Untuk Kelas '.$kelas.' Belum Ada</h4></div>';
                    }

                    else{
                    $no=1;
                    while ($data = mysql_fetch_array($query)) {
                    ?>
                    <tr>
                    <td style="padding: 5px;"> <?php echo $data['hari'];?> </td>
                    <td style="padding: 5px;"> <?php echo $data['nama_mapel'];?> </td>
                    <td style="padding: 5px; text-align:center;"> <?php echo $data['jam_mulai'];?> - <?php echo $data['jam_selesai'];?> </td>
                    <td style="padding: 5px"> <?php echo $data['nama'];?> </td>
                    </tr>
                    <?php
                        $no++;
                    }}
                    ?>
                
                </tbody>
            </table><br>
            
    </body>
</html>
<?php
    include('../../settings/config.php');
    $kelas = $_POST['kelas1'];

    $filename="Jadwal Pelajaran Kelas ".$kelas.".pdf";
    $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15',array(15, 0, 20, 10));  
        $html2pdf->setDefaultFont('Arial');  
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));  
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

?>