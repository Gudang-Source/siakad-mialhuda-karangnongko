<?php
session_start();
include('../../settings/config.php');

ob_start();

$nopeg = $_POST['nopeg'];
$kelas = $_POST['kelas'];
$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];

if ($semester == 'Ganjil') {
  $tampil_semester = 'I';
}
elseif ($semester == 'Genap') {
  $tampil_semester = 'II';
}

$query_wali= mysql_query("SELECT * FROM tbl_kelas
                          INNER JOIN tbl_guru ON tbl_guru.nomer_pegawai = tbl_kelas.wali_kelas
                          WHERE tbl_kelas.id_kelas = '$kelas' AND tbl_kelas.wali_kelas='$nopeg' ");
$wali = mysql_fetch_array($query_wali);

$tgl = date('d-m-Y');
?>

<html>
    <head>
        
    </head>

    <body><br><br>
        <div class="row">
        <div class="col-md-2">
            <img src='mi_alhuda.png' width='50' style="margin-left:15px;">
            <label style="margin-top:-25px; margin-left:15px; font-size:18px">Ledger Peserta Didik</label><br><br>
            <label style="margin-top:-45px; margin-left:85px; font-size:16px">MI Al-Huda Karangnongko</label>
        </div>
        </div>
        <table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="150">Kelas</td>
                        <td width="10">:</td>
                        <td width="200"><?php echo $kelas;?></td>
                    </tr>
                    <tr>
                        <td width="150">Semester</td>
                        <td width="10">:</td>
                        <td width="200"><?php echo $tampil_semester;?></td>
                    </tr>
                    <tr>
                        <td width="150">Tahun Ajaran</td>
                        <td width="10">:</td>
                        <td width="200"><?php echo $thn_ajaran;?></td>
                    </tr>
                </tbody>
            </table>
        <div style="position: absolute; right: 1mm; top: 3mm; text-align: right; color:grey;"><i>Cetak Tanggal : <?php echo $tgl;?></i></div>
        <br>
            <?php
            $cek = mysql_query("SELECT * FROM tbl_nilai_raport
                                        INNER JOIN tbl_siswa1 ON tbl_siswa1.nis_lokal = tbl_nilai_raport.nis_lokal
                                        WHERE tbl_nilai_raport.id_kelas = '$kelas' AND tbl_nilai_raport.thn_ajaran = '$thn_ajaran' 
                                        AND tbl_nilai_raport.semester = '$semester' AND tbl_nilai_raport.id_wali = '$nopeg' 
                                        GROUP BY tbl_nilai_raport.nis_lokal ASC");
            

            if (mysql_num_rows($cek) == 0) {
                echo '<div><h4>Maaf, Ledger Nilai Semester Untuk Kelas '.$kelas.' Tahun Ajaran '.$thn_ajaran.'( '.$semester.' ) Belum Ada</h4></div>';
            }

            else {
            echo'<table align="left" style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                 <thead>
              <tr>';

              $query_nilai = mysql_query("SELECT * FROM tbl_nilai_raport
                                         WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                         AND semester = '$semester' GROUP BY id_mapel");
              $query_kkm = mysql_query("SELECT kkm FROM tbl_nilai_raport
                                         WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                         AND semester = '$semester' GROUP BY id_mapel");
              $query_pembiasaan= mysql_query("SELECT * FROM tbl_pembiasaan ORDER BY id_pembiasaan");
              $query_ekstra = mysql_query("SELECT * FROM tbl_nilai_pengembangan_diri
                                           INNER JOIN tbl_ekskul ON tbl_ekskul.id_ekstra = tbl_nilai_pengembangan_diri.id_ekstra
                                           WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                           AND semester = '$semester' GROUP BY tbl_ekskul.id_ekstra ");

              $no_mpl_leger=1;
              $no_pembiasaan=1;
              $no_ekstra=1;
              $no_kkm=1;

              echo '
                <th rowspan="2" align="center" style="width: 5px; padding:5px; font-size:12px;">No</th>
                <th align="center" style="font-size:12px;">Nama Siswa</th>';

              while ($mpl = mysql_fetch_array($query_nilai)) {
                echo '<th align="center" style="font-size:12px; padding:5px;">'.$mpl['id_mapel'].'</th>';
                $no_mpl_leger++;
              }

              echo '
                <th rowspan="2" style="width:10px; background-color:grey; padding:5px; font-size:12px;"></th>
                <th rowspan="2" align="center" style="font-size:12px; padding:5px;"> Kprd </th>
                <th rowspan="2" align="center" style="font-size:12px; padding:5px;"> Thfd </th>
                <th rowspan="2" align="center" style="font-size:12px; padding:5px;"> Pmbs </th>
                <th rowspan="2" align="center" style="font-size:12px; padding:5px;"> Pngb </th>
                <th rowspan="2" class="text-center" style="font-size:10px; padding:5px;">Jml Total</th>
                <th rowspan="2" class="text-center" style="font-size:10px; padding:5px;">Rata-rata</th>
                <th rowspan="2" class="text-center" style="font-size:10px; padding:5px;">Ranking</th>';

              echo '
              </tr>
              <tr>
                <th align="center" style="font-size:12px;">KKM</th>';

               while ($km = mysql_fetch_array($query_kkm)) {
                echo '<th align="center" style="font-size:12px; padding:5px;">'.$km['kkm'].'</th>';
                $no_kkm++;
              }

            echo '</tr>
            </thead>';
            echo '<tbody>';
             $query_nilai1 = mysql_query("SELECT * FROM tbl_nilai_raport
                                        INNER JOIN tbl_siswa1 ON tbl_siswa1.nis_lokal = tbl_nilai_raport.nis_lokal
                                        WHERE tbl_nilai_raport.id_kelas = '$kelas' AND tbl_nilai_raport.thn_ajaran = '$thn_ajaran' 
                                        AND tbl_nilai_raport.semester = '$semester' AND tbl_nilai_raport.id_wali = '$nopeg' 
                                        GROUP BY tbl_nilai_raport.nis_lokal ASC");

                    $no1 = 1;
                    $jum=0;
                    while ($sis = mysql_fetch_array($query_nilai1)) {
                    echo '<tr>';
                    echo '<td style="padding: 5px; font-size:12px; text-align:center;">'.$no1.'</td>';
                    echo '<td style="padding: 5px; font-size:12px;">'.$sis['nama_siswa'].'</td>';

                        $nis = $sis['nis_lokal'];
                        $query_nilai2 = mysql_query("SELECT kkm, nilai FROM tbl_nilai_raport
                                                     WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                     AND semester = '$semester' AND nis_lokal = '$nis' ");
                       $no3 = 1;

                        while ($nil_map = mysql_fetch_array($query_nilai2)) {
                            $jum = $jum + $nil_map['nilai'];
                            echo '<td class="info" style="padding: 5px; font-size:12px; text-align: center;">'.$nil_map['nilai'].'</td>';

                            $no3++;
                         }

                            echo '<td style="padding: 5px; font-size:12px; background-color:grey;  text-align: center;"></td>';

                         $nilai_kp = mysql_query("SELECT * FROM tbl_nilai_rata_kepribadian
                                                  WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                  AND semester = '$semester' AND nis_lokal = '$nis'");
                         $nil_kp=mysql_fetch_array($nilai_kp);

                         echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.substr($nil_kp['nilai_rata_kp'], 0,2).'</td>';

                         $nilai_tid = mysql_query("SELECT * FROM tbl_nilai_rata_tid
                                                  WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                  AND semester = '$semester' AND nis_lokal = '$nis'");
                         $nil_tid=mysql_fetch_array($nilai_tid);
                         
                         echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.substr($nil_tid['nilai_rata_tid'], 0,2).'</td>';

                         $cek_pembiasaan = mysql_query("SELECT SUM(nilai) as rata_pembiasaan FROM tbl_nilai_pembiasaan
                                                        WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg' AND semester = '$semester' AND nis_lokal = '$nis'");  
                         $jmlh_pembiasaan = mysql_query("SELECT * FROM tbl_nilai_pembiasaan
                                                        WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg' AND semester = '$semester' AND nis_lokal = '$nis'");  
                         $nil_pembiasaan = mysql_fetch_array($cek_pembiasaan);
                         $rata_pembiasaan =$nil_pembiasaan['rata_pembiasaan'] / mysql_num_rows($jmlh_pembiasaan);

                         echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.substr($rata_pembiasaan, 0,5).'</td>';

                         $cek_ekstra = mysql_query("SELECT SUM(nilai) as rata_ekstra FROM tbl_nilai_pengembangan_diri
                                                    WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg' AND semester = '$semester' AND nis_lokal = '$nis'");
                         $jmlh_ekstra = mysql_query("SELECT * FROM tbl_nilai_pengembangan_diri
                                                      WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg' AND semester = '$semester' AND nis_lokal = '$nis' AND nilai != 0 ");
                         $nil_ekstra = mysql_fetch_array($cek_ekstra);
                         $rata_ekstra = $nil_ekstra['rata_ekstra'] / mysql_num_rows($jmlh_ekstra);

                         echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.substr($rata_ekstra, 0,5).'</td>';

                         $komulatif = mysql_query("SELECT * FROM tbl_nilai_raport_rata
                                                   WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg'
                                                   AND semester = '$semester' AND nis_lokal = '$nis'");
                         $no6=1;
                         while ($kom = mysql_fetch_array($komulatif)) {
                           echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.$kom['jumlah_nilai'].'</td>';
                           echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.substr($kom['nilai_rata'], 0,5).'</td>';
                           $no6++;
                         }

                         $ranking = mysql_query("SELECT * FROM tbl_nilai_raport_rata
                                                 WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_wali = '$nopeg' AND semester = '$semester' ORDER BY jumlah_nilai DESC");
                          $no_rank = 1;

                          while ($data_rank = mysql_fetch_array($ranking)) {

                              $rank = $no_rank;
                              $ns_lok = $data_rank['nis_lokal'];

                              if ($ns_lok == $nis) {
                                  $rank_kls = $rank;
                              }
                              else{

                              }
                              $no_rank++;
                          }

                         echo '<td style="padding: 5px; font-size:12px; text-align: center;">'.$rank_kls.'</td>';


                    $no1++;
                    echo '</tr>';
 
                  }
            
          echo '</tbody>
            </table><br>';
            echo '<table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="50">Mengetahui,</td>
                    </tr>
                    <tr>
                        <td>Wali Kelas</td>
                    </tr>
                    <tr>
                        <td height="30"></td>
                    </tr>
                    <tr>
                        <td>'.$wali['nama'].'</td>
                    </tr>
                    <tr>
                        <td>NIP : '.$wali['nip'].'</td>
                    </tr>
                </tbody>
            </table>';

            }
            ?>
    </body>
</html>
<?php
    include('../../settings/config.php');
    $kelas = $_POST['kelas'];

    $filename="Nilai Semester ".$kelas.".pdf";
    $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('L','A4','en', false, 'ISO-8859-15',array(15, 0, 20, 0));  
        $html2pdf->setDefaultFont('Arial');  
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));  
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

?>