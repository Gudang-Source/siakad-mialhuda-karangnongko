<?php
session_start();
include('../../settings/config.php');

ob_start();

$nopeg = $_POST['nopeg'];
$kelas = $_POST['kelas'];
$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];
$keterangan = $_POST['keterangan'];

$query_wali= mysql_query("SELECT * FROM tbl_nilai_semester 
                          INNER JOIN tbl_guru ON tbl_guru.nomer_pegawai = tbl_nilai_semester.id_wali
                          WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' 
                          AND semester = '$semester' AND keterangan = '$keterangan' ");
$wali = mysql_fetch_array($query_wali);

$jumlah_siswa = mysql_query("SELECT * FROM tbl_nilai_semester
                            INNER JOIN tbl_siswa1 ON tbl_siswa1.nis_lokal = tbl_nilai_semester.nis_lokal
                            WHERE tbl_nilai_semester.id_kelas = '$kelas' AND tbl_nilai_semester.thn_ajaran = '$thn_ajaran' 
                            AND tbl_nilai_semester.semester = '$semester' AND tbl_nilai_semester.keterangan = '$keterangan' 
                            AND tbl_nilai_semester.id_guru = '$nopeg'
                            GROUP BY tbl_nilai_semester.nis_lokal ORDER BY tbl_nilai_semester.nis_lokal ASC");

$tgl = date('d-m-Y');
?>

<html>
    <head>
        
    </head>

    <body><br><br>
        <div class="row">
        <div class="col-md-2">
            <img src='mi_alhuda.png' width='50' style="margin-left:15px;">
            <label style="margin-top:-25px; margin-left:15px; font-size:18px">Laporan Hasil Nilai Semester</label><br><br>
            <label style="margin-top:-45px; margin-left:85px; font-size:16px">MI Al-Huda Karangnongko</label>
        </div>
        </div>
        <table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="150">Kelas</td>
                        <td width="10">:</td>
                        <td width="200"><?php echo $kelas;?></td>
                        <td>Tahun Ajaran</td>
                        <td width="10">:</td>
                        <td width="300"><?php echo $thn_ajaran;?></td>
                    </tr>
                    <tr>
                        <td width="150">Jumlah Siswa</td>
                        <td width="10">:</td>
                        <td width="200"><?php echo mysql_num_rows($jumlah_siswa);?></td>
                        <td>Semester</td>
                        <td width="10">:</td>
                        <td width="300"><?php echo $semester;?></td>
                    </tr>
                    <tr>
                        <td width="150">Wali Kelas</td>
                        <td width="10">:</td>
                        <td width="200"><?php echo $wali['nama'];?></td>
                        <td>Keterangan</td>
                        <td width="10">:</td>
                        <td width="300"><?php echo $keterangan;?></td>
                    </tr>
                </tbody>
            </table>
        <div style="position: absolute; right: 1mm; top: 3mm; text-align: right; color:grey;"><i>Cetak Tanggal : <?php echo $tgl;?></i></div>
        <br>
            <?php
            $query= mysql_query("SELECT * FROM tbl_nilai_semester WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' 
                                 AND semester = '$semester' AND keterangan = '$keterangan' AND id_guru = '$nopeg' ");
            

            if (mysql_num_rows($query) == 0) {
                echo '<div><h4>Maaf, Nilai Semester Untuk Kelas '.$kelas.' Tahun Ajaran '.$thn_ajaran.'( '.$semester.' / '.$keterangan.' ) Belum Ada</h4></div>';
            }

            else {
            echo'<table align="left" style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                 <thead>
                 <tr>';

                 $query_nilai = mysql_query("SELECT id_mapel FROM tbl_nilai_semester
                                             WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_guru = '$nopeg'
                                             AND semester = '$semester' AND keterangan = '$keterangan' GROUP BY id_mapel");
                 $no = 1;

                echo '<th style="padding: 5px; text-align:center; width:10px; text-align:center; ">No</th>';
                echo '<th style="padding: 5px; width:100px; text-align:center; ">Nama</th>';

                while ($data = mysql_fetch_array($query_nilai)) {
                $mpel = $data['id_mapel'];
                echo '<th style="padding: 5px; width:20px; text-align:center; ">'.$data['id_mapel'].'</th>';

                $no++;
                }
                echo '<th style="padding: 5px; width:30px; text-align:center; ">Jumlah</th>';
            echo '</tr>
                 </thead>';
            echo '<tbody>';
            $query_nilai1 = mysql_query("SELECT * FROM tbl_nilai_semester
                                        INNER JOIN tbl_siswa1 ON tbl_siswa1.nis_lokal = tbl_nilai_semester.nis_lokal
                                        WHERE tbl_nilai_semester.id_kelas = '$kelas' AND tbl_nilai_semester.thn_ajaran = '$thn_ajaran' 
                                        AND tbl_nilai_semester.semester = '$semester' AND tbl_nilai_semester.keterangan = '$keterangan' AND tbl_nilai_semester.id_guru = '$nopeg' 
                                        GROUP BY tbl_nilai_semester.nis_lokal ASC");

                    $no1 = 1;
                    $jum=0;
                    while ($sis = mysql_fetch_array($query_nilai1)) {
                    echo '<tr>';
                    echo '<td style="padding: 5px; text-align:center;">'.$no1.'</td>';
                    echo '<td style="padding: 5px;">'.$sis['nama_siswa'].'</td>';

                        $nis = $sis['nis_lokal'];
                        $query_nilai2 = mysql_query("SELECT nilai FROM tbl_nilai_semester
                                             WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_guru = '$nopeg'
                                             AND semester = '$semester' AND keterangan = '$keterangan' AND nis_lokal = '$nis' ");
                       $no3 = 1;

                        while ($nil_map = mysql_fetch_array($query_nilai2)) {
                            $jum = $jum + $nil_map['nilai'];
                            echo '<td style="padding: 5px; text-align: center;">'.$nil_map['nilai'].'</td>';

                            $no3++;
                         }
                    echo '<td style="padding: 5px; text-align:center">'.$jum.'</td>';
                    $no1++;
                    echo '</tr>';
 
                  }
            echo '<!--Nilai Tertinggi-->';
                  $max = mysql_query("SELECT max(nilai) as tertinggi FROM tbl_nilai_semester
                                      WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_guru = '$nopeg'
                                      AND semester = '$semester' AND keterangan = '$keterangan' GROUP BY id_mapel");

                  $no_max=1;

                  echo '<tr>';
                  echo '<td colspan="2" style="padding: 5px; text-align:center">Nilai Tertinggi</td>';

                  while ($tinggi = mysql_fetch_array($max)) {

                    echo '<td style="padding: 5px; text-align:center">'.$tinggi['tertinggi'].'</td>';
                    
                      $no_max++;
                  }
                  echo '<td style="padding: 5px; text-align:center; background-color:black;"></td>';
                  echo '</tr>';
            echo '<!--Nilai Tertinggi-->';

            echo '<!--Nilai Terendah-->';
                  $min = mysql_query("SELECT min(nilai) as terendah FROM tbl_nilai_semester
                                      WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_guru = '$nopeg'
                                      AND semester = '$semester' AND keterangan = '$keterangan' GROUP BY id_mapel");

                  $no_min=1;

                  echo '<tr>';
                  echo '<td colspan="2" style="padding: 5px; text-align:center">Nilai Terendah</td>';

                  while ($rendah = mysql_fetch_array($min)) {

                    echo '<td style="padding: 5px; text-align:center">'.$rendah['terendah'].'</td>';
                    
                      $no_min++;
                  }
                  echo '<td style="padding: 5px; text-align:center; background-color:black;"></td>';
                  echo '</tr>';
            echo '<!--Nilai Terendah-->';

            echo '<!--Nilai Rata-->';
                  $rata2 = mysql_query("SELECT SUM(nilai) as rata FROM tbl_nilai_semester
                                      WHERE id_kelas = '$kelas' AND thn_ajaran = '$thn_ajaran' AND id_guru = '$nopeg'
                                      AND semester = '$semester' AND keterangan = '$keterangan' GROUP BY id_mapel");

                  $no_rata=1;

                  echo '<tr>';
                  echo '<td colspan="2" style="padding: 5px; text-align:center">Rata-rata</td>';

                  while ($rata = mysql_fetch_array($rata2)) {
                    $hasil_rata = $rata['rata'] / mysql_num_rows($query_nilai1);
                    echo '<td style="padding: 5px; text-align:center";>'.substr($hasil_rata, 0,4).'</td>';
                    
                      $no_min++;
                  }
                  echo '<td style="padding: 5px; text-align:center; background-color:black;"></td>';
                  echo '</tr>';
            echo '<!--Nilai Rata-->';

            echo '
                 </tbody>
            </table><br>';
            echo '<table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="50">Mengetahui,</td>
                    </tr>
                    <tr>
                        <td>Wali Kelas</td>
                    </tr>
                    <tr>
                        <td height="30"></td>
                    </tr>
                    <tr>
                        <td>'.$wali['nama'].'</td>
                    </tr>
                    <tr>
                        <td>NIP : '.$wali['nip'].'</td>
                    </tr>
                </tbody>
            </table>';

            }
            ?>
    </body>
</html>
<?php
    include('../../settings/config.php');
    $kelas = $_POST['kelas'];

    $filename="Nilai Semester ".$kelas.".pdf";
    $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('L','A4','en', false, 'ISO-8859-15',array(15, 0, 20, 0));  
        $html2pdf->setDefaultFont('Arial');  
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));  
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

?>