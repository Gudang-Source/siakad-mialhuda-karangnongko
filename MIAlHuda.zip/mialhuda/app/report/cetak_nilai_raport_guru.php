<?php
session_start();
include('../../settings/config.php');

ob_start();

$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];
$nisn = $_POST['nis_lokal'];
$kelas =$_POST['kelas'];
$no_absen = $_POST['no_absen'];

$siswa = mysql_query("SELECT * FROM tbl_siswa1 WHERE nis_lokal = '$nisn' ");
$sis = mysql_fetch_array($siswa);

$kelas_raport = mysql_query("SELECT * FROM tbl_nilai_raport 
                             INNER JOIN tbl_guru ON tbl_guru.nomer_pegawai = tbl_nilai_raport.id_wali
                             WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' GROUP BY id_kelas");
$kel_raport = mysql_fetch_array($kelas_raport);
$kel = $kel_raport['id_kelas'];

$kls_raport = $kel_raport['id_kelas'];
$jumlah_siswa = mysql_query("SELECT * FROM tbl_nilai_raport WHERE thn_ajaran = '$thn_ajaran' 
                             AND semester = '$semester' AND id_kelas = '$kls_raport' GROUP BY nis_lokal ");

$jumlah_nilai_semua = mysql_query("SELECT * FROM tbl_nilai_raport_rata WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' 
                                   AND semester = '$semester'");
$jum_nilsem = mysql_fetch_array($jumlah_nilai_semua);

$ketidakhadiran = mysql_query("SELECT * FROM tbl_kehadiran WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester'");
$hadir = mysql_fetch_array($ketidakhadiran);

$catatan_wali = mysql_query("SELECT * FROM tbl_catatan_wali WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester'");
$catatan= mysql_fetch_array($catatan_wali);

$kepala = mysql_query("SELECT * FROM tbl_guru WHERE jabatan = 'Kemad' ");
$kemad = mysql_fetch_array($kepala);

if ($semester == 'Ganjil') {
    $semester_tampil = 'I';
}
elseif ($semester == 'Genap') {
    $semester_tampil = 'II';
}

$tgl = date('d-m-Y');
?>

<html>
    <head>
        
    </head>

    <body><br><br><br><br><br><br><br><br><br><br>
        <label style="margin-left:320px; font-size: 18px;">LAPORAN</label><br><br>
        <label style="margin-left:225px; font-size: 18px;">HASIL BELAJAR PESERTA DIDIK</label><br>
        <label style="margin-left:235px; margin-top:5px; font-size: 18px;">MI AL HUDA KARANGNONGKO</label><br><br><br><br><br>
        <img src="mi_alhuda.png" width='150' style="margin-left:290px;"><br><br><br><br>
        <label style="margin-left:285px; font-size: 18px;">Nama Peserta Didik :</label><br>
        <label style="margin-left:290px; font-size: 17px;"><?php echo $sis['nama_siswa'];?></label><br><br>
         <label style="margin-left:320px; font-size: 18px;">NIS / NISN :</label><br>
        <label style="margin-left:345px; font-size: 17px;"><?php echo substr($sis['nis_lokal'], -4);?></label><br><br><br><br><br><br><br><br><br><br><br>

        <label style="margin-left:260px; font-size: 17px;">KEMENTRIAN AGAMA RI</label><br>
        <label style="margin-left:230px; margin-top:5px; font-size: 17px;">DIREKTORAT PENDIDIKAN ISLAM</label><br><br><br><br><br>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <div><br><br>
            <img src='mi_alhuda.png' width='50' style="margin-left:15px;">
            <label style="margin-top:-25px; margin-left:145px; font-size:18px">LAPORAN HASIL BELAJAR</label><br><br>
            <label style="margin-top:-40px; margin-left:195px; font-size:18px">MI AL HUDA KARANGNONGKO</label>
        </div>
        <div style="margin-left:13px;">
            <table align="center" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="55">Nama</td>
                        <td width="10">:</td>
                        <td width="250"><?php echo $sis['nama_siswa'];?></td>
                        <td>Kelas</td>
                        <td width="15">:</td>
                        <td width="300"><?php echo $kel_raport['id_kelas'];?></td>
                    </tr>
                    <tr>
                        <td width="55">No. Abs</td>
                        <td width="10">:</td>
                        <td width="250"><?php echo $no_absen;?></td>
                        <td>Semester</td>
                        <td width="10">:</td>
                        <td width="300"><?php echo $semester_tampil;?></td>
                    </tr>
                    <tr>
                        <td width="55">NISN/NIS</td>
                        <td width="10">:</td>
                        <td width="250"><?php echo substr($sis['nis_lokal'],-4);?></td>
                        <td>Tahun Pelajaran</td>
                        <td width="10">:</td>
                        <td width="300"><?php echo $thn_ajaran;?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <br>

        <?php
            if (mysql_num_rows($kelas_raport) == 0) {
                echo '<p>Maaf, Nilai Raport Tahun Ajaran '.$thn_ajaran.' ('.$semester.') Belum Ada</p>';
            }
            else{
            if ($semester == 'Ganjil') {

                echo '<table  style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <thead>
                <tr>
                    <th rowspan="2" style="padding: 5px; width:20px; text-align:center; ">No</th>
                    <th rowspan="2" style="padding: 5px; width:200px; text-align:center; ">Mata Pelajaran</th>
                    <th rowspan="2" style="padding: 5px; width:30px; text-align:center; ">KKM</th>
                    <th colspan="2" style="padding: 5px; width:150px; text-align:center; ">NILAI PRESTASI</th>
                    <th rowspan="2" style="padding: 5px; width:40px; text-align:center; ">Rata-rata Kelas</th>
                </tr>
                <tr>
                    <th style="padding: 5px; width:35px; text-align:center; ">Angka</th>
                    <th style="padding: 5px; width:200px; text-align:center; ">Huruf</th>
                </tr>
                </thead>
                <tbody>';
                    
                    $thn_ajaran = $_POST['thn_ajaran'];
                    $semester = $_POST['semester'];
                    $nisn = $_POST['nis_lokal'];
                    $kelas =$_POST['kelas'];
                    $no_absen = $_POST['no_absen'];

                    $nilai_raport = mysql_query("SELECT * FROM tbl_nilai_raport
                                                 INNER JOIN tbl_mapel ON tbl_mapel.id_mapel = tbl_nilai_raport.id_mapel
                                                 WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' ORDER BY id ");
                    $jumlah_mapel = mysql_num_rows($nilai_raport);
                    $jumlah_nilai=0;
                    $rata = 0;
                    $no=1;
                    while ($data = mysql_fetch_array($nilai_raport)) {
                   
                    echo '<tr>';
                    echo '<td style="padding: 5px; text-align:center;">'.$no.'</td>
                    <td style="padding: 5px;">'.$data['nama_mapel'].'</td>
                    <td style="padding: 5px; text-align:center;">'.$data['kkm'].'</td>
                    <td style="padding: 5px; text-align:center;">'.$data['nilai'].'</td>
                    <td style="padding: 5px;">'.$data['nilai_huruf'].'</td>';
                    $mapel_id = $data['id_mapel'];

                    $rata_nilai = mysql_query("SELECT SUM(nilai) as jml FROM tbl_nilai_raport
                                               WHERE id_kelas = '$kel' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' AND id_mapel ='$mapel_id' ");
                    $rt_nilai = mysql_fetch_array($rata_nilai);
                    $hsl_rata = $rt_nilai['jml'] / mysql_num_rows($jumlah_siswa);

                    echo '<td style="padding: 5px; text-align:center;">'.substr($hsl_rata, 0,4).'</td>
                    </tr>';
                    
                        $jumlah_nilai = $jumlah_nilai + $data['nilai'];
                        $no++;
                    }
                    $rata = $jumlah_nilai / $jumlah_mapel;
                    echo '<td style="padding: 10px; text-align:center;" border="2" colspan="6" rowspan="2" width="622"><b>Jumlah Nilai Akademik : '.$jumlah_nilai.', Rata-Rata Nilai Akademik : '.substr($rata, 0,5).'</b></td>';
                    
                echo '</tbody>
                </table><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                <table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="50">Mengetahui,</td>
                    </tr>
                    <tr>
                        <td width="150">Orang Tua / Wali </td>
                        <td width="400"></td>
                        <td>Wali Kelas</td>
                    </tr>
                    <tr>
                        <td height="35" width="150"></td>
                        <td width="400"></td>
                        <td height="35"></td>
                    </tr>
                    <tr>
                        <td width="150">............................</td>
                        <td width="380"></td>
                        <td>'.$kel_raport['nama'].'</td>
                    </tr>
                    <tr>
                        <td width="150"></td>
                        <td width="350"></td>
                        <td>NIP : '.$kel_raport['nip'].'</td>
                    </tr>
                </tbody>';
            echo '</table><br><br><br><br><br><br><br>
            <div><br><br>
            <img src="mi_alhuda.png" width="50" style="margin-left:15px;">
            <label style="margin-top:-25px; margin-left:145px; font-size:18px">LAPORAN HASIL BELAJAR</label><br><br>
            <label style="margin-top:-40px; margin-left:195px; font-size:18px">MI AL HUDA KARANGNONGKO</label>
        </div>
        <div style="margin-left:13px;">
            <table align="center" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="55">Nama</td>
                        <td width="10">:</td>
                        <td width="250">'.$sis['nama_siswa'].'</td>
                        <td>Kelas</td>
                        <td width="15">:</td>
                        <td width="300">'.$kel_raport['id_kelas'].'</td>
                    </tr>
                    <tr>
                        <td width="55">No. Abs</td>
                        <td width="10">:</td>
                        <td width="250">'.$no_absen.'</td>
                        <td>Semester</td>
                        <td width="10">:</td>
                        <td width="300">'.$semester_tampil.'</td>
                    </tr>
                    <tr>
                        <td width="55">NISN/NIS</td>
                        <td width="10">:</td>
                        <td width="250">'.substr($sis['nis_lokal'],-4).'</td>
                        <td>Tahun Pelajaran</td>
                        <td width="10">:</td>
                        <td width="300">'.$thn_ajaran.'</td>
                    </tr>
                </tbody>
            </table>
        </div><br><br>';
            echo '<table  style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <thead>
                <tr>
                    <th style="padding: 5px; width:20px; text-align:center; ">No</th>
                    <th style="padding: 5px; width:200px; text-align:center; ">PEMBIASAAN</th>
                    <th style="padding: 5px; width:88px; text-align:center; ">NILAI</th>
                    <th style="padding: 5px; width:265px; text-align:center; ">KETERANGAN</th>
                </tr>
                </thead>
                <tbody>';
                 
                    $thn_ajaran = $_POST['thn_ajaran'];
                    $semester = $_POST['semester'];
                    $nisn = $_POST['nis_lokal'];
                    $kelas =$_POST['kelas'];
                    $no_absen = $_POST['no_absen'];

                    $nilai_raport = mysql_query("SELECT * FROM tbl_nilai_pembiasaan
                                                 INNER JOIN tbl_pembiasaan ON tbl_pembiasaan.id_pembiasaan = tbl_nilai_pembiasaan.id_pembiasaan
                                                 WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' ORDER BY id ");
                    
                    $no=1;
                    while ($data = mysql_fetch_array($nilai_raport)) {
                    
                    echo '<tr>
                    <td style="padding: 5px; text-align:center;">'.$no.'</td>
                    <td style="padding: 5px;">'.$data['nama_pembiasaan'].'</td>
                    <td style="padding: 5px; text-align:center;">'.$data['nilai'].'</td>
                    <td style="padding: 5px;">'.$data['nilai_huruf'].'</td>
                    </tr>';
                    
                        $no++;
                    }
                    
                    
            echo '</tbody>
            </table><br>
            <table  style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <thead>
                <tr>
                    <th style="padding: 5px; width:20px; text-align:center; ">No</th>
                    <th style="padding: 5px; width:200px; text-align:center; ">PENGEMBANGAN DIRI</th>
                    <th style="padding: 5px; width:88px; text-align:center; ">NILAI</th>
                    <th style="padding: 5px; width:265px; text-align:center; ">KETERANGAN</th>
                </tr>
                </thead>
                <tbody>';
                    

                    $thn_ajaran = $_POST['thn_ajaran'];
                    $semester = $_POST['semester'];
                    $nisn = $_POST['nis_lokal'];
                    $kelas =$_POST['kelas'];
                    $no_absen = $_POST['no_absen'];

                    $nilai_raport = mysql_query("SELECT * FROM tbl_nilai_pengembangan_diri
                                                 INNER JOIN tbl_ekskul ON tbl_ekskul.id_ekstra = tbl_nilai_pengembangan_diri.id_ekstra
                                                 WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' ORDER BY id ");
                    
                    $no=1;
                    while ($data = mysql_fetch_array($nilai_raport)) {
                        if ($data['nilai'] == 0) {
                            $nilai_pengembangan = '';
                            $huruf_pengembangan = '';
                        }
                        else{
                            $nilai_pengembangan = $data['nilai'];
                            $huruf_pengembangan = $data['nilai_huruf'];
                        }
                    
                    echo '<tr>
                    <td style="padding: 5px; text-align:center;">'.$no.'</td>
                    <td style="padding: 5px;">'.$data['nama_ekstra'].'</td>
                    <td style="padding: 5px; text-align:center;">'.$nilai_pengembangan.'</td>
                    <td style="padding: 5px;">'.$huruf_pengembangan.'</td>
                    </tr>';
                    
                        $no++;
                    }
                   
                    
            echo '</tbody>
            </table><br>
            <table  style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <thead>
                <tr>
                    <th style="padding: 5px; width:20px; text-align:center; ">No</th>
                    <th style="padding: 5px; width:200px; text-align:center; ">PROGRAM UNGGULAN</th>
                    <th style="padding: 5px; width:88px; text-align:center; ">NILAI</th>
                    <th style="padding: 5px; width:265px; text-align:center; ">KETERANGAN</th>
                </tr>
                </thead>
                <tbody>';


                    $thn_ajaran = $_POST['thn_ajaran'];
                    $semester = $_POST['semester'];
                    $nisn = $_POST['nis_lokal'];
                    $kelas =$_POST['kelas'];

                    $nilai_tid = mysql_query("SELECT * FROM tbl_nilai_rata_tid WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester'");
                    $tid = mysql_fetch_array($nilai_tid);

                    $nilai_kp = mysql_query("SELECT * FROM tbl_nilai_rata_kepribadian WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester'");
                    $kp = mysql_fetch_array($nilai_kp);

                    
                   
                    echo '<tr>
                    <td style="padding: 5px; text-align:center;">1</td>
                    <td style="padding: 5px;">Tahfid dan Doa Sehari-hari</td>
                    <td style="padding: 5px; text-align:center;">'.substr($tid['nilai_rata_tid'], 0,2).'</td>
                    <td style="padding: 5px; width:265px;">'.$tid['keterangan_tid'].'</td>
                    </tr>

                    <tr>
                    <td style="padding: 5px; text-align:center;">2</td>
                    <td style="padding: 5px;">Kepribadian</td>
                    <td style="padding: 5px; text-align:center;">'.substr($kp['nilai_rata_kp'], 0,2).'</td>
                    <td style="padding: 5px; width:265px;">'.$kp['keterangan_kp'].'</td>
                    </tr>';
                    
                    $nol = 0;
                    if ($hadir['ijin'] < 1) {
                        $ijin = '-';
                    }
                    elseif ($hadir['ijin'] > $nol) {
                        $ijin = $hadir['ijin'];
                    }
                    if ($hadir['sakit'] == $nol) {
                        $sakit = '-';
                    }
                    elseif ($hadir['sakit'] > $nol) {
                        $sakit = $hadir['sakit'];
                    }
                    if ($hadir['alpha'] == $nol) {
                        $alpha = '-';
                    }
                    elseif ($hadir['alpha'] > $nol) {
                        $alpha = $hadir['alpha'];
                    }
            echo '</tbody>
            </table><br>
            <table  style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <tr>
                    <th rowspan="2" style="padding: 5px; width:200px; text-align:center; ">Ketidak Hadiran <br> (hari)</th>
                    <th style="padding: 5px; width:125px; text-align:center; ">Ijin</th>
                    <th style="padding: 5px; width:125px; text-align:center; ">Sakit</th>
                    <th style="padding: 5px; width:125px; text-align:center; ">Alpha</th>
                </tr>
                <tr>

                <th style="padding: 5px; width:50px; text-align:center; ">'.$ijin.'</th>
                    <th style="padding: 5px; width:50px; text-align:center; ">'.$sakit.'</th>
                    <th style="padding: 5px; width:50px; text-align:center; ">'.$alpha.'</th>
                </tr>
                
            </table>';

            $ranking = mysql_query("SELECT * FROM tbl_nilai_raport_rata
                                    WHERE id_kelas = '$kel' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' ORDER BY jumlah_nilai DESC");
            $no_rank = 1;

            while ($data_rank = mysql_fetch_array($ranking)) {

                $rank = $no_rank;
                $ns_lok = $data_rank['nis_lokal'];

                if ($ns_lok == $nisn) {
                    $rank_kls = $rank;
                }
                else{

                }
                $no_rank++;
            }

            echo '
            <p><i>Jumlah Nilai Akademik, Nilai Pembiasaan, Pengembangan Diri, dan Program Unggulan adalah : </i><b>'.substr($jum_nilsem['jumlah_nilai'], 0,7).'</b> <br><i>Rata-rata : </i><b> '.substr($jum_nilsem['nilai_rata'], 0,5).'</b>
                <br><i>Ananda mendapat peringkat ke- </i><b>'.$rank_kls.' dari '.mysql_num_rows($jumlah_siswa).' siswa</b></p>
            
            <table style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <tr>
                    <td style="padding: 5px; width:648px; text-align:left; "><b>Catatan Wali Kelas :</b><br>'.$catatan['catatan'].'</td>
                </tr>
            </table><br>
            
            <table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="100">Diberikan di</td>
                        <td width="10"> :</td>
                        <td width="250"> Sleman</td>
                    </tr>
                    <tr>
                        <td width="100">Pada Tanggal</td>
                        <td width="10"> :</td>
                        <td width="250">'.date("d F Y", strtotime($tgl)).'</td>
                    </tr>
                </tbody>
            </table><br>';
            echo '
            <table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="50">Mengetahui,</td>
                    </tr>
                    <tr>
                        <td width="150">Orang Tua / Wali </td>
                        <td width="400"></td>
                        <td>Wali Kelas</td>
                    </tr>
                    <tr>
                        <td height="35" width="150"></td>
                        <td width="400"></td>
                        <td height="35"></td>
                    </tr>
                    <tr>
                        <td width="150">............................</td>
                        <td width="380"></td>
                        <td>'.$kel_raport['nama'].'</td>
                    </tr>
                    <tr>
                        <td width="150"></td>
                        <td width="350"></td>
                        <td>NIP : '.$kel_raport['nip'].'</td>
                    </tr>
                </tbody>
            </table>';
                
            }
            elseif ($semester == 'Genap') {
                
                echo '<table  style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <thead>
                <tr>
                    <th rowspan="2" style="padding: 5px; width:20px; text-align:center; ">No</th>
                    <th rowspan="2" style="padding: 5px; width:200px; text-align:center; ">Mata Pelajaran</th>
                    <th rowspan="2" style="padding: 5px; width:30px; text-align:center; ">KKM</th>
                    <th colspan="2" style="padding: 5px; width:150px; text-align:center; ">NILAI PRESTASI</th>
                    <th rowspan="2" style="padding: 5px; width:40px; text-align:center; ">Rata-rata Kelas</th>
                </tr>
                <tr>
                    <th style="padding: 5px; width:35px; text-align:center; ">Angka</th>
                    <th style="padding: 5px; width:200px; text-align:center; ">Huruf</th>
                </tr>
                </thead>
                <tbody>';
                    
                    $thn_ajaran = $_POST['thn_ajaran'];
                    $semester = $_POST['semester'];
                    $nisn = $_POST['nis_lokal'];
                    $kelas =$_POST['kelas'];
                    $no_absen = $_POST['no_absen'];

                    $nilai_raport = mysql_query("SELECT * FROM tbl_nilai_raport
                                                 INNER JOIN tbl_mapel ON tbl_mapel.id_mapel = tbl_nilai_raport.id_mapel
                                                 WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' ORDER BY id ");
                    $jumlah_mapel = mysql_num_rows($nilai_raport);
                    $jumlah_nilai=0;
                    $rata = 0;
                    $no=1;
                    while ($data = mysql_fetch_array($nilai_raport)) {
                   
                    echo '<tr>';
                    echo '<td style="padding: 5px; text-align:center;">'.$no.'</td>
                    <td style="padding: 5px;">'.$data['nama_mapel'].'</td>
                    <td style="padding: 5px; text-align:center;">'.$data['kkm'].'</td>
                    <td style="padding: 5px; text-align:center;">'.$data['nilai'].'</td>
                    <td style="padding: 5px;">'.$data['nilai_huruf'].'</td>';

                    $mapel_id = $data['id_mapel'];

                    $rata_nilai = mysql_query("SELECT SUM(nilai) as jml FROM tbl_nilai_raport
                                               WHERE id_kelas = '$kel' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' AND id_mapel ='$mapel_id' ");
                    $rt_nilai = mysql_fetch_array($rata_nilai);
                    $hsl_rata = $rt_nilai['jml'] / mysql_num_rows($jumlah_siswa);

                    echo '<td style="padding: 5px; text-align:center;">'.substr($hsl_rata, 0,4).'</td>
                    </tr>';
                    
                        $jumlah_nilai = $jumlah_nilai + $data['nilai'];
                        $no++;
                    }
                    $rata = $jumlah_nilai / $jumlah_mapel;
                    echo '<td style="padding: 10px; text-align:center;" border="2" colspan="6" rowspan="2" width="622"><b>Jumlah Nilai Akademik : '.$jumlah_nilai.', Rata-Rata Nilai Akademik : '.substr($rata, 0,5).'</b></td>';
                    
                echo '</tbody>
                </table><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                <table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="50">Mengetahui,</td>
                    </tr>
                    <tr>
                        <td width="150">Orang Tua / Wali </td>
                        <td width="400"></td>
                        <td>Wali Kelas</td>
                    </tr>
                    <tr>
                        <td height="35" width="150"></td>
                        <td width="400"></td>
                        <td height="35"></td>
                    </tr>
                    <tr>
                        <td width="150">............................</td>
                        <td width="380"></td>
                        <td>'.$kel_raport['nama'].'</td>
                    </tr>
                    <tr>
                        <td width="150"></td>
                        <td width="350"></td>
                        <td>NIP : '.$kel_raport['nip'].'</td>
                    </tr>
                </tbody>';
            echo '</table><br><br><br><br><br><br><br>
            <div><br><br>
            <img src="mi_alhuda.png" width="50" style="margin-left:15px;">
            <label style="margin-top:-25px; margin-left:145px; font-size:18px">LAPORAN HASIL BELAJAR</label><br><br>
            <label style="margin-top:-40px; margin-left:195px; font-size:18px">MI AL HUDA KARANGNONGKO</label>
        </div>
        <div style="margin-left:13px;">
            <table align="center" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="55">Nama</td>
                        <td width="10">:</td>
                        <td width="250">'.$sis['nama_siswa'].'</td>
                        <td>Kelas</td>
                        <td width="15">:</td>
                        <td width="300">'.$kel_raport['id_kelas'].'</td>
                    </tr>
                    <tr>
                        <td width="55">No. Abs</td>
                        <td width="10">:</td>
                        <td width="250">'.$no_absen.'</td>
                        <td>Semester</td>
                        <td width="10">:</td>
                        <td width="300">'.$semester_tampil.'</td>
                    </tr>
                    <tr>
                        <td width="55">NISN/NIS</td>
                        <td width="10">:</td>
                        <td width="250">'.substr($sis['nis_lokal'],-4).'</td>
                        <td>Tahun Pelajaran</td>
                        <td width="10">:</td>
                        <td width="300">'.$thn_ajaran.'</td>
                    </tr>
                </tbody>
            </table>
        </div><br><br>';
            echo '<table  style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <thead>
                <tr>
                    <th style="padding: 5px; width:20px; text-align:center; ">No</th>
                    <th style="padding: 5px; width:200px; text-align:center; ">PEMBIASAAN</th>
                    <th style="padding: 5px; width:88px; text-align:center; ">NILAI</th>
                    <th style="padding: 5px; width:265px; text-align:center; ">KETERANGAN</th>
                </tr>
                </thead>
                <tbody>';
                 
                    $thn_ajaran = $_POST['thn_ajaran'];
                    $semester = $_POST['semester'];
                    $nisn = $_POST['nis_lokal'];
                    $kelas =$_POST['kelas'];
                    $no_absen = $_POST['no_absen'];

                    $nilai_raport = mysql_query("SELECT * FROM tbl_nilai_pembiasaan
                                                 INNER JOIN tbl_pembiasaan ON tbl_pembiasaan.id_pembiasaan = tbl_nilai_pembiasaan.id_pembiasaan
                                                 WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' ORDER BY id ");
                    
                    $no=1;
                    while ($data = mysql_fetch_array($nilai_raport)) {
                    
                    echo '<tr>
                    <td style="padding: 5px; text-align:center;">'.$no.'</td>
                    <td style="padding: 5px;">'.$data['nama_pembiasaan'].'</td>
                    <td style="padding: 5px; text-align:center;">'.$data['nilai'].'</td>
                    <td style="padding: 5px;">'.$data['nilai_huruf'].'</td>
                    </tr>';
                    
                        $no++;
                    }
                    
                    
            echo '</tbody>
            </table><br>
            <table  style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <thead>
                <tr>
                    <th style="padding: 5px; width:20px; text-align:center; ">No</th>
                    <th style="padding: 5px; width:200px; text-align:center; ">PENGEMBANGAN DIRI</th>
                    <th style="padding: 5px; width:88px; text-align:center; ">NILAI</th>
                    <th style="padding: 5px; width:265px; text-align:center; ">KETERANGAN</th>
                </tr>
                </thead>
                <tbody>';
                    

                    $thn_ajaran = $_POST['thn_ajaran'];
                    $semester = $_POST['semester'];
                    $nisn = $_POST['nis_lokal'];
                    $kelas =$_POST['kelas'];
                    $no_absen = $_POST['no_absen'];

                    $nilai_raport = mysql_query("SELECT * FROM tbl_nilai_pengembangan_diri
                                                 INNER JOIN tbl_ekskul ON tbl_ekskul.id_ekstra = tbl_nilai_pengembangan_diri.id_ekstra
                                                 WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' ORDER BY id ");
                    
                    $no=1;
                    while ($data = mysql_fetch_array($nilai_raport)) {
                        if ($data['nilai'] == 0) {
                            $nilai_pengembangan = '';
                            $huruf_pengembangan = '';
                        }
                        else{
                            $nilai_pengembangan = $data['nilai'];
                            $huruf_pengembangan = $data['nilai_huruf'];
                        }
                    
                    echo '<tr>
                    <td style="padding: 5px; text-align:center;">'.$no.'</td>
                    <td style="padding: 5px;">'.$data['nama_ekstra'].'</td>
                    <td style="padding: 5px; text-align:center;">'.$nilai_pengembangan.'</td>
                    <td style="padding: 5px;">'.$huruf_pengembangan.'</td>
                    </tr>';
                    
                        $no++;
                    }
                   
                    
            echo '</tbody>
            </table><br>
            <table  style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <thead>
                <tr>
                    <th style="padding: 5px; width:20px; text-align:center; ">No</th>
                    <th style="padding: 5px; width:200px; text-align:center; ">PROGRAM UNGGULAN</th>
                    <th style="padding: 5px; width:88px; text-align:center; ">NILAI</th>
                    <th style="padding: 5px; width:265px; text-align:center; ">KETERANGAN</th>
                </tr>
                </thead>
                <tbody>';

                    $thn_ajaran = $_POST['thn_ajaran'];
                    $semester = $_POST['semester'];
                    $nisn = $_POST['nis_lokal'];
                    $kelas =$_POST['kelas'];

                    $nilai_tid = mysql_query("SELECT * FROM tbl_nilai_rata_tid WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester'");
                    $tid = mysql_fetch_array($nilai_tid);

                    $nilai_kp = mysql_query("SELECT * FROM tbl_nilai_rata_kepribadian WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester'");
                    $kp = mysql_fetch_array($nilai_kp);

                    
                   
                    echo '<tr>
                    <td style="padding: 5px; text-align:center;">1</td>
                    <td style="padding: 5px;">Tahfid dan Doa Sehari-hari</td>
                    <td style="padding: 5px; text-align:center;">'.substr($tid['nilai_rata_tid'], 0,2).'</td>
                    <td style="padding: 5px; width:265px;">'.$tid['keterangan_tid'].'</td>
                    </tr>

                    <tr>
                    <td style="padding: 5px; text-align:center;">2</td>
                    <td style="padding: 5px;">Kepribadian</td>
                    <td style="padding: 5px; text-align:center;">'.substr($kp['nilai_rata_kp'], 0,2).'</td>
                    <td style="padding: 5px; width:265px;">'.$kp['keterangan_kp'].'</td>
                    </tr>';
                    
                    
            echo '</tbody>
            </table><br>';

            $nol = 0;
                    if ($hadir['ijin'] < 1) {
                        $ijin = '-';
                    }
                    elseif ($hadir['ijin'] > $nol) {
                        $ijin = $hadir['ijin'];
                    }
                    if ($hadir['sakit'] == $nol) {
                        $sakit = '-';
                    }
                    elseif ($hadir['sakit'] > $nol) {
                        $sakit = $hadir['sakit'];
                    }
                    if ($hadir['alpha'] == $nol) {
                        $alpha = '-';
                    }
                    elseif ($hadir['alpha'] > $nol) {
                        $alpha = $hadir['alpha'];
                    }

            echo '
            <table  style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <tr>
                    <th rowspan="2" style="padding: 5px; width:200px; text-align:center; ">Ketidak Hadiran <br> (hari)</th>
                    <th style="padding: 5px; width:125px; text-align:center; ">Ijin</th>
                    <th style="padding: 5px; width:125px; text-align:center; ">Sakit</th>
                    <th style="padding: 5px; width:125px; text-align:center; ">Alpha</th>
                </tr>
                <tr>
                    <th style="padding: 5px; width:50px; text-align:center; ">'.$ijin.'</th>
                    <th style="padding: 5px; width:50px; text-align:center; ">'.$sakit.'</th>
                    <th style="padding: 5px; width:50px; text-align:center; ">'.$alpha.'</th>
                </tr>
                
            </table>';

            $ranking = mysql_query("SELECT * FROM tbl_nilai_raport_rata
                                    WHERE id_kelas = '$kel' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' ORDER BY jumlah_nilai DESC");
            $no_rank = 1;

            while ($data_rank = mysql_fetch_array($ranking)) {

                $rank = $no_rank;
                $ns_lok = $data_rank['nis_lokal'];

                if ($ns_lok == $nisn) {
                    $rank_kls = $rank;
                }
                else{

                }
                $no_rank++;
            }

            echo '
            <p><i>Jumlah Nilai Akademik, Nilai Pembiasaan, Pengembangan Diri, dan Program Unggulan adalah : </i><b>'.substr($jum_nilsem['jumlah_nilai'], 0,7).'</b><br><i>Rata-rata : </i><b> '.substr($jum_nilsem['nilai_rata'], 0,5).'</b>
                <br><i>Ananda mendapat peringkat ke- </i><b>'.$rank_kls.' dari '.mysql_num_rows($jumlah_siswa).' siswa</b></p>
            
            <table style="font-size:13px;" border="1" cellpadding="20" cellspacing="0">
                <tr>
                    <td style="padding: 5px; width:648px; text-align:left; "><b>Catatan Wali Kelas :</b><br>'.$catatan['catatan'].'</td>
                </tr>
            </table><br>
            
            <table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="100">Diberikan di</td>
                        <td width="10"> :</td>
                        <td width="250"> Sleman</td>
                    </tr>
                    <tr>
                        <td width="100">Pada Tanggal</td>
                        <td width="10"> :</td>
                        <td width="250">'.date("d F Y", strtotime($tgl)).'</td>
                    </tr>
                    <tr>
                        <td width="100"></td>
                        <td width="10"></td>
                        <td width="500">Keputusan berdasarkan hasil yang dicapai pada semester 1 (satu) dan 2 (dua) maka ditetapkan siswa bersangkutan:</td>
                    </tr>';

                    $thn_ajaran = $_POST['thn_ajaran'];
                    $semester = $_POST['semester'];
                    $nisn = $_POST['nis_lokal'];
                    $kelas =$_POST['kelas'];
                    $no_absen = $_POST['no_absen'];

                    $naik_kelas = mysql_query("SELECT * FROM tbl_kenaikan_kls WHERE nis_lokal = '$nisn' AND thn_ajaran = '$thn_ajaran' AND semester = '$semester' ");
                    $naik = mysql_fetch_array($naik_kelas);

                    if ($naik['keterangan'] == 'Naik Kelas') {
                        echo '<tr>
                        <td width="100">Naik Ke Kelas</td>
                        <td width="10"> :</td>
                        <td width="250"><b>'.$naik['naik_kelas'].' ( '.$naik['ket_huruf_kls'].' )</b></td>
                        </tr>
                        <tr>
                        <td width="100">Tinggal di Kelas</td>
                        <td width="10"> :</td>
                        <td width="250"><b>- ( - )</b></td>
                        </tr>';
                    }
                    elseif ($naik['keterangan'] == 'Tinggal Kelas') {
                        echo '<tr>
                        <td width="100">Naik Ke Kelas</td>
                        <td width="10"> :</td>
                        <td width="250"><b>- ( - )</b></td>
                        </tr>
                        <tr>
                        <td width="100">Tinggal di Kelas</td>
                        <td width="10"> :</td>
                        <td width="250"><b>'.$naik['naik_kelas'].' ( '.$naik['ket_huruf_kls'].' )</b></td>
                        </tr>';
                    }
                    echo '
                </tbody>
            </table><br>';
            echo '
            <table align="left" style="font-size:13px;" border="0">
                <tbody>
                    <tr>
                        <td width="50">Mengetahui,</td>
                    </tr>
                    <tr>
                        <td width="250">Orang Tua / Wali </td>
                        <td width="200">Wali Kelas</td>
                        <td width="200">Kepala Madrasah</td>
                    </tr>
                    <tr>
                        <td height="35" width="250"></td>
                        <td height="35" width="200"></td>
                        <td height="35" width="200"></td>
                    </tr>
                    <tr>
                        <td width="250">............................</td>
                        <td width="200">'.$kel_raport['nama'].'</td>
                        <td>'.$kemad['nama'].'</td>
                    </tr>
                    <tr>
                        <td width="250"></td>
                        <td width="200">NIP : '.$kel_raport['nip'].'</td>
                        <td>NIP : '.$kemad['nip'].'</td>
                    </tr>
                </tbody>
            </table>';

            }
            }
        ?>

            
            
    </body>
</html>
<?php
    include('../../settings/config.php');

    $thn_ajaran = $_POST['thn_ajaran'];
    $semester = $_POST['semester'];
    $nisn = $_POST['nis_lokal'];
    $kelas =$_POST['kelas'];
    $no_absen = $_POST['no_absen'];

    $siswa = mysql_query("SELECT * FROM tbl_siswa1 WHERE nis_lokal = '$nisn' ");
    $sis = mysql_fetch_array($siswa);
   
    
    $filename="".$sis['nama_siswa']."_nilai_raport_".$thn_ajaran."_".$semester.".pdf";
    $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15',array(15, 0, 20, 0));  
        $html2pdf->setDefaultFont('Arial');  
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));  
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

?>