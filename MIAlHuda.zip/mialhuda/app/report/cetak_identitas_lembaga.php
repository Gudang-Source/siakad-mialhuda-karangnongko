<?php
session_start();
include('../../settings/config.php');

ob_start();

$identitas_lembaga = mysql_query("SELECT * FROM tbl_identitas_lembaga");
$identitas = mysql_fetch_array($identitas_lembaga);

?>

<html>
    <head>
        
    </head>

    <body><br><br><br><br><br><br><br><br><br><br>
        <table  align="center" border="0">
            <tbody>
                <tr>
                <td>
                     <img src="mi_alhuda.png" width='150' ><br><br><br><br>
                </td>
                </tr>
            </tbody>
        </table>
        <table align="center"  border="0">
            <tbody>
                <tr>
                <td>
                <label style="font-size: 18px;">IDENTITAS LEMBAGA</label><br><br>
                </td>
                </tr>
            </tbody>
        </table>
        <table  align="center"  border="0">
            <tbody>
                <tr>
                <td>
                <label style="font-size: 18px;">MI AL HUDA KARANGNONGKO</label><br><br><br><br><br><br><br>
                </td>
                </tr>
            </tbody>
        </table>
        <table align="center" style="font-size:17px;" border="0">
            <tbody>
            <tr>
                <td style="padding:5px;" width="200">Nama Lembaga</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $identitas['nama_lembaga'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="200">NIM / NSM / NILEM</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $identitas['nsm'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="200">Alamat Lembaga</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $identitas['alamat_lembaga'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="200">Jalan / Desa / Kelurahan</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $identitas['desa'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="200">Kecamatan</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $identitas['kecamatan'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="200">No.Telp / HP</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $identitas['no_tlp'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="200">Kabupaten / Kota</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $identitas['kabupaten'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="200">Provinsi</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $identitas['provinsi'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="200">Website</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $identitas['website'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="200">Email</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $identitas['email'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="200">Kode Pos</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $identitas['kode_pos'];?></td>
            </tr>
            </tbody>
        </table>
            
    </body>
</html>
<?php
    include('../../settings/config.php');
    
    $filename="Identitas Lembaga.pdf";
    $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15',array(15, 0, 20, 0));  
        $html2pdf->setDefaultFont('Arial');  
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));  
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

?>