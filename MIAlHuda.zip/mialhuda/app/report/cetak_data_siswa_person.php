<?php
session_start();
include('../../settings/config.php');

ob_start();

$nis_lokal = $_GET['id'];
$data_siswa = mysql_query("SELECT * FROM tbl_siswa1
                           INNER JOIN tbl_ortu ON tbl_ortu.no_induk = tbl_siswa1.nis_lokal
                           WHERE tbl_siswa1.nis_lokal = '$nis_lokal' ");
$siswa = mysql_fetch_array($data_siswa);

if ($siswa['status_kel'] == 'AK') {
    $status = 'Anak Kandung';
}
elseif ($siswa['status_kel'] == 'AT') {
    $status = 'Anak Tiri';
}
elseif ($siswa['status_kel'] == 'AA') {
    $status = 'Anak Angkat';
}
else{
    $status = $siswa['status_kel'];
}

if ($siswa['jk_siswa'] == 'L') {
    $JK = 'Laki-laki';
}
elseif ($siswa['jk_siswa'] == 'P') {
    $JK = 'Perempuan';
}

?>

<html>
    <head>
        
    </head>

    <body><br><br>
        <div>
            <img src='mi_alhuda.png' width='50' style="margin-left:10px;">
            <label style="font-size: 18px; margin-left:200px; margin-top:-30px;">Biodata Peserta Didik</label><br>
            <label style="font-size: 18px; margin-left:220px; margin-top:-30px;">MI AL HUDA KARANGNONGKO</label><br><br>
        </div>
        <table align="left" style="font-size:14px;" border="0">
            <tbody>
            <tr>
                <td style="padding:5px;" width="150">No.Induk Lokal</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['nis_lokal'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">No.Induk Nasional</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['nis_nasional'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Kelas</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['kelas'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Nama Lengkap</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['nama_siswa'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Tempat, Tanggal Lahir</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['tempat_lahir'];?>, <?php echo date("d F Y", strtotime($siswa['tanggal_lahir']));?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Alamat</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['alamat_siswa'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Kecamatan</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['kecamatan_siswa'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Kabupaten / Kota</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['kab_kota'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Provinsi</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['propinsi'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Jenis Kelamin</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $JK;?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Agama</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['agama'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Status Keluarga</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $status;?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Keterangan Siswa</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['keterangan'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Nama Ayah</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['nama_ayah'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Pekerjaan Ayah</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['pekerjaan_ayah'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Nama Ibu</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['nama_ibu'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Pekerjaan Ibu</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['pekerjaan_ibu'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Alamat Lengkap</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['alamat_ortu'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">No.Telepon</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['no_tlp_ortu'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Nama Wali</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['nama_wali'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Pekerjaan Wali</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['pekerjaan_wali'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">Alamat Wali</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['alamat_wali'];?></td>
            </tr>
            <tr>
                <td style="padding:5px;" width="150">No.Telepon Wali</td>
                <td style="padding:5px;" width="5">:</td>
                <td style="padding:5px;"><?php echo $siswa['no_tlp_wali'];?></td>
            </tr>
            </tbody>
        </table>
            
    </body>
</html>
<?php
    include('../../settings/config.php');

    $nis_lokal = $_GET['id'];
    $data_siswa = mysql_query("SELECT * FROM tbl_siswa1
                               INNER JOIN tbl_ortu ON tbl_ortu.nis_lokal = tbl_siswa1.nis_lokal
                               WHERE tbl_siswa1.nis_lokal = '$nis_lokal' ");
    $siswa = mysql_fetch_array($data_siswa);
    
    $filename="".$siswa['nama_siswa'].".pdf";
    $content = ob_get_clean();

    // convert
    require_once(dirname(__FILE__).'./html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF('P','A4','en', false, 'ISO-8859-15',array(20, 0, 20, 20));  
        $html2pdf->setDefaultFont('Arial');  
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));  
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

?>