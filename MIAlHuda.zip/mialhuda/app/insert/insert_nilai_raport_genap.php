<?php
include('../../settings/config.php');

$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];
$nis_lokal = $_POST['nis_lokal'];
$id_kelas = $_POST['kelas'];
$id_wali_kls = $_POST['wali_kls'];

$ijin = $_POST['ijin'];
$sakit = $_POST['sakit'];
$alpha = $_POST['alpha'];

$jml_mapel = $_POST['jumlah_mapel'];
$jml_pembiasaan = $_POST['jumlah_pembiasaan'];
$jml_ekstra = $_POST['jumlah_ekstra'];

$catatan = addslashes($_POST['catatan']);
$ket_naik = $_POST['ket_naik_tinggal'];

$cek_nilai_raport_genap = mysql_query("SELECT * FROM tbl_nilai_raport WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' GROUP BY nis_lokal");
$cek = mysql_num_rows($cek_nilai_raport_genap);

if ($cek > 0 ) {
	echo "<script>alert('Nilai Raport NIS : ".$nis_lokal.", Tahun Ajaran ".$thn_ajaran." (".$semester.") Sudah Diinputkan');</script>";
	echo "<script>location.replace('../../guru/nilai_raport.php')</script>";
}

else{
	
for ($i=0; $i < $jml_mapel ; $i++) { 

	$id_mapel = addslashes($_POST['id_mapel'][$i]);
	$id_guru = $_POST['id_guru'][$i];
	$kkm = $_POST['kkm_mapel'][$i];
	$cek_ksong_nilai = $_POST['nilai_mapel'][$i];
	if (empty($cek_ksong_nilai)) {
		$nilai = 0;
		$nilai_huruf = ucwords(Terbilang($nilai));
	}
	else{
		$nilai = $_POST['nilai_mapel'][$i];
		$nilai_huruf = ucwords(Terbilang($nilai));
	}

	$query = mysql_query("INSERT INTO tbl_nilai_raport VALUES ('', '$nis_lokal', '$id_kelas', '$id_wali_kls', '$id_guru', '$thn_ajaran', '$semester',
			'$id_mapel','$kkm', '$nilai' ,'$nilai_huruf')");
}

for ($x=0; $x < $jml_pembiasaan ; $x++) { 
	$id_pembiasaan = $_POST['id_pembiasaan'][$x];
	$cek_ksong_pembiasaan = $_POST['nilai_pembiasaan'][$x];
	if (empty($cek_ksong_pembiasaan)) {
		$nilai_pembiasaan = 0;
		$nilai_huruf_pembiasaan = ucwords(Terbilang($nilai_pembiasaan));
	}
	else{
		$nilai_pembiasaan = $_POST['nilai_pembiasaan'][$x];
		$nilai_huruf_pembiasaan = ucwords(Terbilang($nilai_pembiasaan));
	}

	$query1 = mysql_query("INSERT INTO tbl_nilai_pembiasaan VALUES ('', '$nis_lokal', '$id_kelas', '$id_wali_kls','$thn_ajaran', '$semester',
							'$id_pembiasaan', '$nilai_pembiasaan', '$nilai_huruf_pembiasaan')");

}

for ($y=0; $y < $jml_ekstra ; $y++) { 
	$id_ekstra = $_POST['id_ekstra'][$y];
	$cek_ksong_ekstra = $_POST['nilai_ekstra'][$y];
	if (empty($cek_ksong_ekstra)) {
		$nilai_ekstra = 0;
		$nilai_huruf_ekstra = ucwords(Terbilang($nilai_ekstra));
	}
	else{
		$nilai_ekstra = $_POST['nilai_ekstra'][$y];
		$nilai_huruf_ekstra = ucwords(Terbilang($nilai_ekstra));
	}

	$query2 = mysql_query("INSERT INTO tbl_nilai_pengembangan_diri VALUES ('', '$nis_lokal', '$id_kelas', '$id_wali_kls', '$id_guru',
							'$thn_ajaran', '$semester', '$id_ekstra', '$nilai_ekstra', '$nilai_huruf_ekstra')");

}

$query3 = mysql_query("INSERT INTO tbl_kehadiran VALUES ('', '$nis_lokal', '$id_kelas', '$id_wali_kls', '$thn_ajaran', '$semester', '$ijin', '$sakit', '$alpha')");

$query4 = mysql_query("INSERT INTO tbl_catatan_wali VALUES ('',  '$nis_lokal', '$id_kelas', '$id_wali_kls','$thn_ajaran', '$semester', '$catatan')");

if ($ket_naik == 'Naik Kelas') {
	if ($id_kelas == '1A') {
		$ket_kelas = '2';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '1B') {
		$ket_kelas = '2';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '2A') {
		$ket_kelas = '3';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '2B') {
		$ket_kelas = '3';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '3A') {
		$ket_kelas = '4';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '3B') {
		$ket_kelas = '4';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '4A') {
		$ket_kelas = '5';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '4B') {
		$ket_kelas = '5';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '5A') {
		$ket_kelas = '6';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '5B') {
		$ket_kelas = '6';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '6A') {
		$ket_kelas = 'LULUS';
	}
	elseif ($id_kelas == '6B') {
		$ket_kelas = 'LULUS';
	}

}
elseif ($ket_naik == 'Tinggal Kelas') {
	if ($id_kelas == '1A') {
		$ket_kelas = '1';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '1B') {
		$ket_kelas = '1';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '2A') {
		$ket_kelas = '2';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '2B') {
		$ket_kelas = '2';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '3A') {
		$ket_kelas = '3';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '3B') {
		$ket_kelas = '3';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '4A') {
		$ket_kelas = '4';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '4B') {
		$ket_kelas = '4';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '5A') {
		$ket_kelas = '5';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '5B') {
		$ket_kelas = '5';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '6A') {
		$ket_kelas = '6';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kelas == '6B') {
		$ket_kelas = '6';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
}

$query5 = mysql_query("INSERT INTO tbl_kenaikan_kls VALUES ('',  '$nis_lokal', '$id_kelas', '$id_wali_kls','$thn_ajaran', '$semester', '$ket_kelas','$ket_kls_huruf', '$ket_naik')");

if ($query && $query1 && $query2 && $query3 && $query4 && $query5) {
	echo "<script>alert('Nilai Raport Berhasil diTambahkan');</script>";
	echo "<script>location.replace('../../guru/nilai_raport.php')</script>";

	$cek_akademik = mysql_query("SELECT SUM(nilai) as rata_akademik FROM tbl_nilai_raport 
								 WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' ");
	$nil_akademik = mysql_fetch_array($cek_akademik);

	$cek_pembiasaan = mysql_query("SELECT SUM(nilai) as rata_pembiasaan FROM tbl_nilai_pembiasaan
								   WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");	
	$jmlh_pembiasaan = mysql_query("SELECT * FROM tbl_nilai_pembiasaan
								   WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");	
	$nil_pembiasaan = mysql_fetch_array($cek_pembiasaan);
	$rata_pembiasaan =$nil_pembiasaan['rata_pembiasaan'] / mysql_num_rows($jmlh_pembiasaan);

	$cek_ekstra = mysql_query("SELECT SUM(nilai) as rata_ekstra FROM tbl_nilai_pengembangan_diri
							    WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' ");
	$jmlh_ekstra = mysql_query("SELECT * FROM tbl_nilai_pengembangan_diri
							    WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' AND nilai != 0 ");
	$nil_ekstra = mysql_fetch_array($cek_ekstra);
	$rata_ekstra = $nil_ekstra['rata_ekstra'] / mysql_num_rows($jmlh_ekstra);

	$cek_kepribadian = mysql_query("SELECT * FROM tbl_nilai_rata_kepribadian WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");
	$nil_kp = mysql_fetch_array($cek_kepribadian);

	$cek_tid = mysql_query("SELECT * FROM tbl_nilai_rata_tid WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");
	$nil_tid = mysql_fetch_array($cek_tid);

	$cek_jumlah_mapel = mysql_query("SELECT * FROM tbl_nilai_raport 
									 WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");

	$jumlah_nilai = $nil_akademik['rata_akademik'] + $rata_pembiasaan + $rata_ekstra + substr($nil_kp['nilai_rata_kp'], 0,2) + substr($nil_tid['nilai_rata_tid'], 0,2);
	$rata_nilai = $jumlah_nilai / (mysql_num_rows($cek_jumlah_mapel) + 1 + 1 + 1 + 1);

	$query_ranking = mysql_query("INSERT INTO tbl_nilai_raport_rata VALUES ('', '$nis_lokal', '$id_kelas', '$id_wali_kls', '$thn_ajaran', '$semester', '$jumlah_nilai', '$rata_nilai')");
}
else{
	echo "<script>alert('Nilai Semester Gagal diTambahkan');</script>";
	echo "<script>location.replace('../../guru/nilai_raport.php')</script>";
}
}
?>

<?php
	function Terbilang($x){
		$abil = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");

		if ($x < 12) {
			return " " . $abil[$x];
		}
		elseif ($x < 20) {
			return Terbilang($x - 10). " belas";
		}
		elseif ($x < 100) {
			return Terbilang($x / 10). " puluh " . Terbilang($x % 10);
		}
		elseif ($x < 200) {
			return "seratus ". Terbilang($x - 100);
		}
	}
	
?>