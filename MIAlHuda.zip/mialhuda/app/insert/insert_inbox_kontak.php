<?php
session_start();
include('../../settings/config.php');

//cek apakah captha benar
//jika captcha benar
if(($_REQUEST['captcha'] == $_SESSION['vercode'])){
	$nama = $_POST['name'];
	$email = $_POST['email'];
	$subjek = $_POST['subjek'];
	$pesan = $_POST['pesan'];
	$tanggal = date('Y-m-d');
	 
	//simpan ke database
	$query = mysql_query("INSERT INTO tbl_inbox_kontak VALUES('', '$nama', '$email', '$subjek', '$pesan', '$tanggal', 'Belum Terbaca')");
	if ($query) {
    	echo "<script>alert('Pesan Anda Berhasil Dikirim');</script>";
    	echo "<script>location.replace('../../index.php')</script>";
	}
	else{
		echo "<script>alert('Gagal Disimpan');</script>";
	}
//jika captcha salah	
}else{
	echo "<script>alert('Kode Captcha Salah');window.location='javascript:history.go(-1)';</script>";
}

?>
?>