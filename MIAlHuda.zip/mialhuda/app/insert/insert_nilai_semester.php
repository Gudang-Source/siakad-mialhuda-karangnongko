<?php
include('../../settings/config.php');

$no = $_POST['nomer'];
$nis_lokal = $_POST['nis_lok'];
$id_kelas = $_POST['kls'];
$id_wali_kls = $_POST['id_wali_kls'];
$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];
$keterangan = $_POST['keterangan'];

$cek_nilai_semester = mysql_query("SELECT * FROM tbl_nilai_semester WHERE nis_lokal= '$nis_lokal' 
								   AND thn_ajaran='$thn_ajaran' AND keterangan='$keterangan' AND semester='$semester' 
								   GROUP BY nis_lokal ");
$cek = mysql_num_rows($cek_nilai_semester);

if ($cek > 0) {
	echo "<script>alert('Nilai Semester NIS : ".$nis_lokal.",  Tahun Ajaran ".$thn_ajaran." (".$semester.") Sudah Diinputkan');</script>";
	echo "<script>location.replace('../../guru/tampil_siswa_nilai1.php?id=$id_kelas')</script>";
}

else{
for ($i=0; $i < $no ; $i++) { 

	$id_mapel = addslashes($_POST['id_mapel'][$i]);
	$id_guru = $_POST['id_guru'][$i];
	$cek_kosong = $_POST['nilai_mapel'][$i];
	if (empty($cek_kosong)) {
		$nilai = 0;
		$nilai_huruf = ucwords(Terbilang($nilai));
	}
	else{
		$nilai = $_POST['nilai_mapel'][$i];
		$nilai_huruf = ucwords(Terbilang($nilai));
	}

	$query = mysql_query("INSERT INTO tbl_nilai_semester VALUES ('', '$nis_lokal', '$id_kelas', '$id_wali_kls', '$id_guru', '$thn_ajaran', '$semester',
			'$keterangan', '$id_mapel', '$nilai' ,'$nilai_huruf')");
	
}

if ($query) {
	echo "<script>alert('Nilai Semester Berhasil diTambahkan');</script>";
	echo "<script>location.replace('../../guru/tampil_siswa_nilai1.php?id=$id_kelas')</script>";
}
else{
	echo "<script>alert('Nilai Semester Gagal diTambahkan');</script>";
	echo "<script>location.replace('../../guru/tampil_siswa_nilai1.php?id=$id_kelas')</script>";
}
}
?>

<?php
	function Terbilang($x){
		$abil = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");

		if ($x < 12) {
			return "".$abil[$x];
		}
		elseif ($x < 20) {
			return Terbilang($x - 10). " belas";
		}
		elseif ($x < 100) {
			return Terbilang($x / 10). " puluh " . Terbilang($x % 10);
		}
		elseif ($x < 200) {
			return "seratus ". Terbilang($x - 100);
		}
	}
	
?>