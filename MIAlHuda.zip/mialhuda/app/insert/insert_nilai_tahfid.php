<?php
include('../../settings/config.php');

$no = $_POST['nomer'];
$nis_lokal = $_POST['nis_lok'];
$id_kelas = $_POST['kls'];
$id_wali_kls = $_POST['id_wali_kls'];
$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];
$keterangan = $_POST['keterangan'];

$cek_nilai_tahfid = mysql_query("SELECT * FROM tbl_nilai_tahfid_doa WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' 
								 AND semester='$semester' GROUP BY nis_lokal");
$cek = mysql_num_rows($cek_nilai_tahfid);

if ($cek > 0) {
	echo "<script>alert('Nilai Tahfid/Doa NIS : ".$nis_lokal.", Tahun Ajaran ".$thn_ajaran." (".$semester.") Sudah Diinputkan');</script>";
	echo "<script>location.replace('../../guru/nilai_tahfid.php')</script>";
}

else{

for ($i=0; $i < $no ; $i++) { 

	$id_tahfid = addslashes($_POST['id_tahfid_doa'][$i]);
	$nilai_tahfid = $_POST['nilai_tahfid'][$i];

	$query = mysql_query("INSERT INTO tbl_nilai_tahfid_doa VALUES ('', '$nis_lokal', '$id_kelas', '$id_wali_kls', '$thn_ajaran', '$semester', '$id_tahfid', '$nilai_tahfid')");

}

if ($query) {
	echo "<script>alert('Nilai Tahfid / Doa Berhasil diTambahkan');</script>";
	echo "<script>location.replace('../../guru/nilai_tahfid.php')</script>";

	$cek_tid = mysql_query("SELECT SUM(nilai_tahfid) as jml_tahfid FROM tbl_nilai_tahfid_doa
								 WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' ");
	$nil_tid = mysql_fetch_array($cek_tid);

	$daftar_tid = mysql_query("SELECT * FROM tbl_tahfid_doa ORDER BY id_tahfid_doa ASC");

	$jml_tahfid = $nil_tid['jml_tahfid'];
	$rata_tid = $jml_tahfid / mysql_num_rows($daftar_tid);

	$query_rata_kp = mysql_query("INSERT INTO tbl_nilai_rata_tid VALUES ('', '$nis_lokal', '$id_kelas', '$id_wali_kls', '$thn_ajaran', '$semester', '$jml_tahfid', '$rata_tid', '$keterangan')");

}
else{
	echo "<script>alert('Nilai  Tahfid / Doa Gagal diTambahkan');</script>";
	echo "<script>location.replace('../../guru/nilai_tahfid.php')</script>";
}
}
?>
