<?php
include('../../settings/config.php');

$no = $_POST['nomer'];
$nis_lokal = $_POST['nis_lok'];
$id_kelas = $_POST['kls'];
$id_wali_kls = $_POST['id_wali_kls'];
$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];
$keterangan = $_POST['keterangan'];

$cek_nilai_kepribadian = mysql_query("SELECT * FROM tbl_nilai_kepribadian WHERE nis_lokal = '$nis_lokal' 
									  AND thn_ajaran='$thn_ajaran' AND semester='$semester' GROUP BY nis_lokal ");
$cek = mysql_num_rows($cek_nilai_kepribadian);

if ($cek > 0) {
	echo "<script>alert('Nilai Kepribadian NIS : ".$nis_lokal.", Tahun Ajaran ".$thn_ajaran." (".$semester.") Sudah Diinputkan');</script>";
	echo "<script>location.replace('../../guru/nilai_kepribadian.php')</script>";
}

else{

for ($i=0; $i < $no ; $i++) { 

	$id_kepribadian = addslashes($_POST['id_kepribadian'][$i]);
	$nilai_kepribadian = $_POST['nilai_kepribadian'][$i];

	$query = mysql_query("INSERT INTO tbl_nilai_kepribadian VALUES ('', '$nis_lokal', '$id_kelas', '$id_wali_kls', '$thn_ajaran', '$semester', '$id_kepribadian', '$nilai_kepribadian')");

}

if ($query) {
	echo "<script>alert('Nilai Kepribadian Berhasil diTambahkan');</script>";
	echo "<script>location.replace('../../guru/nilai_kepribadian.php')</script>";

	$cek_kepribadian = mysql_query("SELECT SUM(nilai_kepribadian) as jml_kepribadian FROM tbl_nilai_kepribadian
								 WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' ");
	$nil_kepribadian = mysql_fetch_array($cek_kepribadian);

	$daftar_kp = mysql_query("SELECT * FROM tbl_kepribadian ORDER BY id_kepribadian ASC");

	$jml_kepribadian = $nil_kepribadian['jml_kepribadian'];
	$rata_kp = $jml_kepribadian / mysql_num_rows($daftar_kp);

	$query_rata_kp = mysql_query("INSERT INTO tbl_nilai_rata_kepribadian VALUES ('', '$nis_lokal', '$id_kelas', '$id_wali_kls', '$thn_ajaran', '$semester', '$jml_kepribadian', '$rata_kp', '$keterangan')");

}
else{
	echo "<script>alert('Nilai Kepribadian Gagal diTambahkan');</script>";
	echo "<script>location.replace('../../guru/nilai_kepribadian.php')</script>";
}
}
?>
