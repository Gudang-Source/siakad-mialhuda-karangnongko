<?php
include('../../settings/config.php');

$nis_lokal= $_POST['nis_lokal'];
$password_lama = md5($_POST['password_lama']);
$password_baru = $_POST['password_baru'];
$password_md5 = md5($password_baru);
$ulang_password = $_POST['ulang_password'];

$passwd = mysql_query("SELECT * FROM tbl_user_login WHERE nip_nisn = '$nis_lokal' ");
$passwd_tampil = mysql_fetch_array($passwd);

if ($password_lama != $passwd_tampil['password']) {
	echo "<script>alert('Password Lama Tidak Sama, Silahkan Ulangi Lagi');</script>";
	echo "<script>location.replace('../../siswa/ubah_password.php')</script>";
}

elseif ($password_lama = $passwd_tampil['password']) {
	$query = mysql_query("UPDATE tbl_user_login SET password = '$password_md5', password_tampil = '$password_baru' WHERE nip_nisn= '$nis_lokal' ");

	if ($query) {
		echo "<script>alert('Password Berhasil diUpdate');</script>";
		echo "<script>location.replace('../../siswa/ubah_password.php')</script>";
	}
	else{
		echo "<script>alert('Password Gagal Diupdate');</script>";
		echo "<script>location.replace('../../siswa/ubah_password.php')</script>";
	}
}

?>