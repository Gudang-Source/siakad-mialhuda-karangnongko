<?php
include('../../settings/config.php');

$nopeg = $_POST['nopeg'];
$alamat = $_POST['alamat'];
$nama_ibu = $_POST['nama_ibu'];
$tmt_capeg = $_POST['tmt_capeg_honor'];
$gol_ruang = $_POST['gol_ruang'];
$tmt_gol = $_POST['tmt_gol'];
$thn_pendidikan = $_POST['thn_pendidikan'];
$jurusan = $_POST['jurusan'];
$no_tlp = $_POST['no_tlp'];
$email = $_POST['email'];

$query = mysql_query("UPDATE tbl_guru SET alamat = '$alamat', nama_ibu = '$nama_ibu', tmt_capeg_honor = '$tmt_capeg', 
		 gol_ruang = '$gol_ruang', tmt_gol_ruang = '$tmt_gol', thn_pendidikan = '$thn_pendidikan', jurusan_pendidikan = '$jurusan',
		 no_tlp = '$no_tlp', email = '$email' WHERE nomer_pegawai = '$nopeg' ");

if ($query) {
	echo "<script>alert('Data Pribadi Berhasil diUpdate');</script>";
	echo "<script>location.replace('../../guru/data_diri_guru.php')</script>";
}
else{
	echo "<script>alert('Data Pribadi Gagal diUpdate');</script>";
	echo "<script>location.replace('../../guru/data_diri_guru.php')</script>";
}
?>