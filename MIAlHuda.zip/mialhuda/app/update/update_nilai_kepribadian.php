<?php
include('../../settings/config.php');

$no = $_POST['nomer'];
$nis_lokal = $_POST['nisn'];
$id_kelas = $_POST['kls'];
$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];
$id_wali_kls = $_POST['wali_kls'];
$keterangan = $_POST['keterangan'];

for ($i=0; $i < $no ; $i++) { 

	$id_kepribadian = addslashes($_POST['id_kepribadian'][$i]);
	$nilai = $_POST['nilai_kepribadian'][$i];

	$query = mysql_query("UPDATE tbl_nilai_kepribadian SET nilai_kepribadian = '$nilai'
	 					  WHERE nis_lokal= '$nis_lokal' AND id_wali='$id_wali_kls' AND thn_ajaran='$thn_ajaran'
	 					  AND semester ='$semester' AND id_kepribadian = '$id_kepribadian' ");
}

if ($query) {
	echo "<script>alert('Nilai Kepribadian Berhasil diUpdate');</script>";
	echo "<script>location.replace('../../guru/nilai_kepribadian.php')</script>";

	$cek_kepribadian = mysql_query("SELECT SUM(nilai_kepribadian) as jml_kepribadian FROM tbl_nilai_kepribadian
								 WHERE nis_lokal='$nis_lokal' AND id_wali = '$id_wali_kls' AND thn_ajaran='$thn_ajaran' AND semester='$semester' ");
	$nil_kepribadian = mysql_fetch_array($cek_kepribadian);

	$daftar_kp = mysql_query("SELECT * FROM tbl_kepribadian ORDER BY id_kepribadian ASC");

	$jml_kepribadian = $nil_kepribadian['jml_kepribadian'];
	$rata_kp = $jml_kepribadian / mysql_num_rows($daftar_kp);

	$query_rata_kp = mysql_query("UPDATE tbl_nilai_rata_kepribadian SET jml_nilai_Kp = '$jml_kepribadian', nilai_rata_kp = '$rata_kp', keterangan_kp = '$keterangan'
								  WHERE nis_lokal='$nis_lokal' AND id_wali='$id_wali_kls' AND thn_ajaran='$thn_ajaran' AND semester='$semester' ");

	echo '<!--===Update Rata-rata Raport===---->';

	$cek_akademik = mysql_query("SELECT SUM(nilai) as rata_akademik FROM tbl_nilai_raport 
								 WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' ");
	$nil_akademik = mysql_fetch_array($cek_akademik);

	$cek_pembiasaan = mysql_query("SELECT SUM(nilai) as rata_pembiasaan FROM tbl_nilai_pembiasaan
								   WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");	
	$jmlh_pembiasaan = mysql_query("SELECT * FROM tbl_nilai_pembiasaan
								   WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");	
	$nil_pembiasaan = mysql_fetch_array($cek_pembiasaan);
	$rata_pembiasaan =$nil_pembiasaan['rata_pembiasaan'] / mysql_num_rows($jmlh_pembiasaan);

	$cek_ekstra = mysql_query("SELECT SUM(nilai) as rata_ekstra FROM tbl_nilai_pengembangan_diri
							    WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' ");
	$jmlh_ekstra = mysql_query("SELECT * FROM tbl_nilai_pengembangan_diri
							    WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' AND nilai != 0 ");
	$nil_ekstra = mysql_fetch_array($cek_ekstra);
	$rata_ekstra = $nil_ekstra['rata_ekstra'] / mysql_num_rows($jmlh_ekstra);

	$cek_kepribadian = mysql_query("SELECT * FROM tbl_nilai_rata_kepribadian WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");
	$nil_kp = mysql_fetch_array($cek_kepribadian);

	$cek_tid = mysql_query("SELECT * FROM tbl_nilai_rata_tid WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");
	$nil_tid = mysql_fetch_array($cek_tid);

	$cek_jumlah_mapel = mysql_query("SELECT * FROM tbl_nilai_raport 
									 WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");

	$jumlah_nilai = $nil_akademik['rata_akademik'] + $rata_pembiasaan + $rata_ekstra +  substr($nil_kp['nilai_rata_kp'], 0,2) + substr($nil_tid['nilai_rata_tid'], 0,2);
	$rata_nilai = $jumlah_nilai / (mysql_num_rows($cek_jumlah_mapel) + 1 + 1 + 1 + 1);

	$query_ranking = mysql_query("UPDATE tbl_nilai_raport_rata SET jumlah_nilai = '$jumlah_nilai', nilai_rata = '$rata_nilai' WHERE nis_lokal = '$nis_lokal' AND thn_ajaran ='$thn_ajaran' AND semester='$semester' ");

}
else{
	echo "<script>alert('Nilai Kepribadian Gagal diUpdate');</script>";
	echo "<script>location.replace('../../guru/nilai_kepribadian.php')</script>";
}

?>
