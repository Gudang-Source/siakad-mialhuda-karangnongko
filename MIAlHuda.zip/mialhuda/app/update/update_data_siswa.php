<?php
include('../../settings/config.php');

$nis_lokal = $_POST['nis_lokal'];

$alamat_siswa = $_POST['alamat_siswa'];
$kecamatan_siswa = $_POST['kecamatan_siswa'];
$kabupaten = $_POST['kabupaten'];
$provinsi = $_POST['provinsi'];

$no_kartu_keluarga = $_POST['no_kartu_keluarga'];
$tmp_lahir_ayah = $_POST['tmp_lahir_ayah'];
$tgl_lahir_ayah = $_POST['tgl_lahir_ayah'];
$tmp_lahir_ibu = $_POST['tmp_lahir_ibu'];
$tgl_lahir_ayah = $_POST['tgl_lahir_ibu'];
$alamat_ortu = $_POST['alamat_ortu'];
$pekerjaan_ayah = $_POST['pekerjaan_ayah'];
$pekerjaan_ibu = $_POST['pekerjaan_ibu'];
$penghasilan_ayah = $_POST['penghasilan_ayah'];
$penghasilan_ibu = $_POST['penghasilan_ibu'];
$kethidupayah = $_POST['kethidupayah'];
$kethidupibu = $_POST['kethidupibu'];
$no_tlp_ortu = $_POST['no_tlp_ortu'];

$nama_wali = $_POST['nama_wali'];
$tmp_lahir_wali = $_POST['tmp_lahir_wali'];
$tgl_lahir_wali = $_POST['tgl_lahir_wali'];
$alamat_wali = $_POST['alamat_wali'];
$jk_wali = $_POST['jk_wali'];
$agama_wali = $_POST['agama_wali'];
$pekerjaan_wali = $_POST['pekerjaan_wali'];
$gaji_wali = $_POST['gaji_wali'];
$no_tlp_wali = $_POST['no_tlp_wali'];

$siswa = mysql_query("UPDATE tbl_siswa1 SET alamat_siswa='$alamat_siswa', kecamatan_siswa='$kecamatan_siswa', kab_kota='$kabupaten', propinsi='$provinsi' 
					  WHERE nis_lokal='$nis_lokal' ");

$ortu = mysql_query("UPDATE tbl_ortu SET no_kartu_keluarga='$no_kartu_keluarga' ,tempat_lahir_ayah='$tmp_lahir_ayah', tgl_lahir_ayah ='$tgl_lahir_ayah', tempat_lahir_ibu ='$tmp_lahir_ibu', 
					alamat_ortu='$alamat_ortu', pekerjaan_ayah='$pekerjaan_ayah', pekerjaan_ibu='$pekerjaan_ibu', penghasilan_ayah='$penghasilan_ayah', 
					penghasilan_ibu='$penghasilan_ibu', ket_hidup_ayah='$kethidupayah', ket_hidup_ibu='$kethidupibu', no_tlp_ortu='$no_tlp_ortu', 
					nama_wali='$nama_wali', tempat_lahir_wali='$tmp_lahir_wali', tgl_lahir_wali='$tgl_lahir_wali', alamat_wali='$alamat_wali', 
					jenis_kel_wali='$jk_wali', agama_wali='$agama_wali', pekerjaan_wali='$pekerjaan_wali', penghasilan_wali='$gaji_wali', 
					no_tlp_wali='$no_tlp_wali' WHERE no_induk='$nis_lokal' ");

if ($siswa && $ortu) {
	echo "<script>alert('Data Pribadi Berhasil diUpdate');</script>";
	echo "<script>location.replace('../../siswa/data_pribadi_siswa.php')</script>";
}
else{
	echo "<script>alert('Data Pribadi Gagal diUpdate');</script>";
	echo "<script>location.replace('../../siswa/data_pribadi_siswa.php')</script>";
}
?>