<?php
include('../../settings/config.php');

$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];
$nis_lokal = $_POST['nis_lokal'];
$id_kelas = $_POST['kelas'];
$id_kls_sekarang = $_POST['kelas_sekarang'];
$id_wali_kls = $_POST['wali_kls'];

$ijin = $_POST['ijin'];
$sakit = $_POST['sakit'];
$alpha = $_POST['alpha'];

$jml_mapel = $_POST['jumlah_mapel'];
$jml_pembiasaan = $_POST['jumlah_pembiasaan'];
$jml_ekstra = $_POST['jumlah_ekstra'];

$catatan = addslashes($_POST['catatan']);
$ket_naik = $_POST['ket_naik_tinggal'];


for ($i=0; $i < $jml_mapel ; $i++) { 

	$id_mapel = addslashes($_POST['id_mapel'][$i]);
	$id_guru = $_POST['id_guru'][$i];
	$nilai = $_POST['nilai_mapel'][$i];
	$kkm = $_POST['kkm_mapel'][$i];
	$nilai_huruf = ucwords(Terbilang($nilai));

	$query = mysql_query("UPDATE tbl_nilai_raport SET kkm = '$kkm', nilai = '$nilai', nilai_huruf = '$nilai_huruf'
	 					  WHERE nis_lokal= '$nis_lokal' AND id_guru='$id_guru' AND thn_ajaran='$thn_ajaran'
	 					  AND semester ='$semester' AND id_mapel = '$id_mapel' ") ;
}

for ($x=0; $x < $jml_pembiasaan ; $x++) { 
	$id_pembiasaan = $_POST['id_pembiasaan'][$x];
	$nilai_pembiasaan = $_POST['nilai_pembiasaan'][$x];
	$nilai_huruf_pembiasaan = ucwords(Terbilang($nilai_pembiasaan));

	$query1 = mysql_query("UPDATE tbl_nilai_pembiasaan SET nilai = '$nilai_pembiasaan', nilai_huruf = '$nilai_huruf_pembiasaan'
						   WHERE nis_lokal = '$nis_lokal' AND id_wali = '$id_wali_kls' AND 
						  thn_ajaran = '$thn_ajaran' AND semester= '$semester' AND id_pembiasaan = '$id_pembiasaan' ");

}

for ($y=0; $y < $jml_ekstra ; $y++) { 
	$id_ekstra = $_POST['id_ekstra'][$y];
	$nilai_ekstra = $_POST['nilai_ekstra'][$y];
	$nilai_huruf_ekstra = ucwords(Terbilang($nilai_ekstra));

	$query2 = mysql_query("UPDATE tbl_nilai_pengembangan_diri SET nilai = '$nilai_ekstra', nilai_huruf = '$nilai_huruf_ekstra'
						   WHERE  nis_lokal = '$nis_lokal' AND id_wali = '$id_wali_kls' AND 
						  thn_ajaran = '$thn_ajaran' AND semester= '$semester' AND id_ekstra = '$id_ekstra'") ;

}
$query3 = mysql_query("UPDATE tbl_kehadiran SET ijin='$ijin', sakit='$sakit', alpha='$alpha' WHERE  nis_lokal = '$nis_lokal' 
					   AND id_wali = '$id_wali_kls' AND thn_ajaran = '$thn_ajaran' AND semester= '$semester' ");

$query4 = mysql_query("UPDATE tbl_catatan_wali SET catatan = '$catatan' WHERE  nis_lokal = '$nis_lokal' 
					   AND id_wali = '$id_wali_kls' AND thn_ajaran = '$thn_ajaran' AND semester= '$semester' ");

if ($ket_naik == 'Naik Kelas' OR $ket_naik == 'Tinggal Kelas') {

	if ($ket_naik == 'Naik Kelas') {
	if ($id_kls_sekarang == '1') {
		$ket_kelas = '2';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '1') {
		$ket_kelas = '2';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '2') {
		$ket_kelas = '3';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '2') {
		$ket_kelas = '3';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '3') {
		$ket_kelas = '4';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '3') {
		$ket_kelas = '4';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '4') {
		$ket_kelas = '5';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '4') {
		$ket_kelas = '5';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '5') {
		$ket_kelas = '6';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '5') {
		$ket_kelas = '6';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '6') {
		$ket_kelas = 'LULUS';
	}
	elseif ($id_kls_sekarang == '6') {
		$ket_kelas = 'LULUS';
	}

}

elseif ($ket_naik == 'Tinggal Kelas') {
	if ($id_kls_sekarang == '1') {
		$ket_kelas = '1';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '1') {
		$ket_kelas = '1';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '2') {
		$ket_kelas = '1';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '2') {
		$ket_kelas = '1';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '3') {
		$ket_kelas = '2';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '3') {
		$ket_kelas = '2';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '4') {
		$ket_kelas = '3';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '4') {
		$ket_kelas = '3';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '5') {
		$ket_kelas = '4';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '5') {
		$ket_kelas = '4';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '6') {
		$ket_kelas = '5';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == '6') {
		$ket_kelas = '5';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == 'LULUS') {
		$ket_kelas = '6';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
	elseif ($id_kls_sekarang == 'LULUS') {
		$ket_kelas = '6';
		$ket_kls_huruf = ucwords(Terbilang($ket_kelas));
	}
}

$query5 = mysql_query("UPDATE tbl_kenaikan_kls SET naik_kelas = '$ket_kelas', ket_huruf_kls = '$ket_kls_huruf', keterangan = '$ket_naik'
					   WHERE  nis_lokal = '$nis_lokal' AND id_wali = '$id_wali_kls' AND thn_ajaran = '$thn_ajaran' AND semester= '$semester' ");
	
}
elseif ($ket_naik == 'Tetap') {
	
}

if ($query && $query1 && $query2 && $query3 && $query4) {
	echo "<script>alert('Nilai Raport Berhasil diUpdate');</script>";
	echo "<script>location.replace('../../guru/nilai_raport.php')</script>";

	$cek_akademik = mysql_query("SELECT SUM(nilai) as rata_akademik FROM tbl_nilai_raport 
								 WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' ");
	$nil_akademik = mysql_fetch_array($cek_akademik);

	$cek_pembiasaan = mysql_query("SELECT SUM(nilai) as rata_pembiasaan FROM tbl_nilai_pembiasaan
								   WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");	
	$jmlh_pembiasaan = mysql_query("SELECT * FROM tbl_nilai_pembiasaan
								   WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");	
	$nil_pembiasaan = mysql_fetch_array($cek_pembiasaan);
	$rata_pembiasaan =$nil_pembiasaan['rata_pembiasaan'] / mysql_num_rows($jmlh_pembiasaan);

	$cek_ekstra = mysql_query("SELECT SUM(nilai) as rata_ekstra FROM tbl_nilai_pengembangan_diri
							    WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' ");
	$jmlh_ekstra = mysql_query("SELECT * FROM tbl_nilai_pengembangan_diri
							    WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester' AND nilai != 0 ");
	$nil_ekstra = mysql_fetch_array($cek_ekstra);
	$rata_ekstra = $nil_ekstra['rata_ekstra'] / mysql_num_rows($jmlh_ekstra);

	$cek_kepribadian = mysql_query("SELECT * FROM tbl_nilai_rata_kepribadian WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");
	$nil_kp = mysql_fetch_array($cek_kepribadian);

	$cek_tid = mysql_query("SELECT * FROM tbl_nilai_rata_tid WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");
	$nil_tid = mysql_fetch_array($cek_tid);

	$cek_jumlah_mapel = mysql_query("SELECT * FROM tbl_nilai_raport 
									 WHERE nis_lokal='$nis_lokal' AND thn_ajaran='$thn_ajaran' AND semester='$semester'");

	$jumlah_nilai = $nil_akademik['rata_akademik'] + $rata_pembiasaan + $rata_ekstra + substr($nil_kp['nilai_rata_kp'], 0,2) + substr($nil_tid['nilai_rata_tid'], 0,2);
	$rata_nilai = $jumlah_nilai / (mysql_num_rows($cek_jumlah_mapel) + 1 + 1 + 1 + 1);

	$query_ranking = mysql_query("UPDATE tbl_nilai_raport_rata SET jumlah_nilai = '$jumlah_nilai', nilai_rata = '$rata_nilai' WHERE nis_lokal = '$nis_lokal' AND thn_ajaran ='$thn_ajaran' AND semester='$semester' ");
}
else{
	echo "<script>alert('Nilai Semester Gagal diUpdate');</script>";
	echo "<script>location.replace('../../guru/nilai_raport.php')</script>";
}

?>

<?php
	function Terbilang($x){
		$abil = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");

		if ($x < 12) {
			return "".$abil[$x];
		}
		elseif ($x < 20) {
			return Terbilang($x - 10). " belas";
		}
		elseif ($x < 100) {
			return Terbilang($x / 10). " puluh " . Terbilang($x % 10);
		}
		elseif ($x < 200) {
			return "seratus ". Terbilang($x - 100);
		}
	}
	
?>