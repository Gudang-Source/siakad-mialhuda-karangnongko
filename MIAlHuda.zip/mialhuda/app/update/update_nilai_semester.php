<?php
include('../../settings/config.php');

$no = $_POST['nomer'];
$nis_lokal = $_POST['nisn'];
$id_kelas = $_POST['kls'];
$thn_ajaran = $_POST['thn_ajaran'];
$semester = $_POST['semester'];
$keterangan = $_POST['keterangan'];

for ($i=0; $i < $no ; $i++) { 

	$id_mapel = addslashes($_POST['id_mapel'][$i]);
	$id_guru = $_POST['id_guru'][$i];
	$nilai = $_POST['nilai_mapel'][$i];
	$nilai_huruf = ucwords(Terbilang($nilai));

	$query = mysql_query("UPDATE tbl_nilai_semester SET nilai = '$nilai', nilai_huruf = '$nilai_huruf'
	 					  WHERE nis_lokal= '$nis_lokal' AND id_guru='$id_guru' AND thn_ajaran='$thn_ajaran'
	 					  AND semester ='$semester' AND keterangan='$keterangan' AND id_mapel = '$id_mapel' ");
}

if ($query) {
	echo "<script>alert('Nilai Semester Berhasil diUpdate');</script>";
	echo "<script>location.replace('../../guru/tampil_siswa_nilai1.php?id=$id_kelas')</script>";
}
else{
	echo "<script>alert('Nilai Semester Gagal diUpdate');</script>";
	echo "<script>location.replace('../../guru/tampil_siswa_nilai1.php?id=$id_kelas')</script>";
}

?>

<?php
	function Terbilang($x){
		$abil = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");

		if ($x < 12) {
			return "".$abil[$x];
		}
		elseif ($x < 20) {
			return Terbilang($x - 10). " belas";
		}
		elseif ($x < 100) {
			return Terbilang($x / 10). " puluh " . Terbilang($x % 10);
		}
		elseif ($x < 200) {
			return "seratus ". Terbilang($x - 100);
		}
	}
	
?>