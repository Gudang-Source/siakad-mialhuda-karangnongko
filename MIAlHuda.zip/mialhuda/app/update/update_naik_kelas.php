<?php
	include('../../settings/config.php');

	$nis_lokal = $_GET['nis'];
	$naik_kelas = $_GET['naik_kls'];

	if ($naik_kelas == 'LULUS') {
		$cek_siswa = mysql_query("SELECT * FROM tbl_siswa1 WHERE nis_lokal = '$nis_lokal' ");
		$siswa = mysql_fetch_array($cek_siswa);

		$nama_siswa = $siswa['nama_siswa'];
		$jk_siswa = $siswa['jk_siswa'];
		$tempat_lahir = $siswa['tempat_lahir'];
		$tanggal_lahir = $siswa['tanggal_lahir'];
		$nis_nasional = $siswa['nis_nasional'];
		$alamat_siswa = $siswa['alamat_siswa'];
		$kecamatan_siswa = $siswa['kecamatan_siswa'];
		$kab_kota = $siswa['kab_kota'];
		$propinsi = $siswa['propinsi'];
		$agama = $siswa['agama'];
		$status_kel = $siswa['status_kel'];
		$terima_tgl = $siswa['terima_tgl'];
		$keterangan = 'Tidak Aktif';
		$foto = $siswa['foto'];

		$query = mysql_query("INSERT INTO tbl_alumni VALUES ('', '$nis_lokal', '$nama_siswa', '$jk_siswa', '$tempat_lahir', '$tanggal_lahir',
							  '$nis_nasional', '$alamat_siswa', '$kecamatan_siswa', '$kab_kota', '$propinsi', '$agama', '$status_kel', '$terima_tgl', '$keterangan', '$foto')");

		$hapus_tbl_siswa = mysql_query("DELETE FROM tbl_siswa1 WHERE nis_lokal = '$nis_lokal' ");
		$hapus_tbl_ortu = mysql_query("DELETE FROM tbl_ortu WHERE no_induk ='$nis_lokal' ");
		$hapus_tbl_user = mysql_query("DELETE FROM tbl_user_login WHERE nip_nisn = '$nis_lokal' ");

		if ($query && $hapus_tbl_siswa && $hapus_tbl_ortu && $hapus_tbl_user) {
				echo "<script>alert('Siswa Lulus');</script>";
				echo "<script>location.replace('../../guru/data_peserta_didik.php')</script>";
		}
		else{
			echo "<script>alert('Siswa Lulus !');</script>";
			echo "<script>location.replace('../../guru/data_peserta_didik.php')</script>";
		}
	}
	else {
		$query = mysql_query("UPDATE tbl_siswa1 SET kelas = '$naik_kelas' WHERE nis_lokal = '$nis_lokal' ");

		if (mysql_query($query)) {
				echo "<script>alert('Naik Kelas Siswa Berhasil');</script>";
				echo "<script>location.replace('../../guru/data_peserta_didik.php')</script>";
		}
		else{
			echo "<script>alert('Naik Kelas Siswa Berhasil !');</script>";
			echo "<script>location.replace('../../guru/data_peserta_didik.php')</script>";
		}
		
	}


?>