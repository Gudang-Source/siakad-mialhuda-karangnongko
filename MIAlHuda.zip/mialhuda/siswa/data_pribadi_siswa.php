<?php
session_start();
include('../check_login.php');
include('../settings/config.php');
?>
<!DOCTYPE html>
<html>
<head>
<title>Selamat Datang</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Education Tutorial Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--bootstrap-->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!--coustom css-->
<link href="../css/style.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="../css/menu-profil.css">
<!--script-->
<script src="../js/jquery-1.11.0.min.js"></script>
<!-- js -->
<script src="../js/bootstrap.js"></script>
<!-- /js -->
<script type="text/javascript" src="../js/move-top.js"></script>
<script type="text/javascript" src="../js/easing.js"></script>
<script src="../bootstrap/js/jquery.validate.js"></script>
</head>
	<body>
<!--header-->
		<div class="header" id="home">
			<nav class="navbar navbar-default">
				<div class="container">
          <div class="col-md-1" style="margin-right:30px;">
            <img style="margin-top:15px; height:95px;" src="../images/logo.png">
          </div>
          <div class="col-md-10">
            <label style="margin-top:25px; color:#fff; font-size:25px">Sistem Informasi Akademik</label><br>
            <label style="color:#fff; font-size:25px">MI AL-HUDA</label>
          </div>
        </div>
			</nav>
<!--/script-->
		   <div class="clearfix"> </div>
		</div>
<!-- Top Navigation -->
<!--header-->
<!-- About -->
<section class="box-profil">

	 <?php
	 	  $user1 = $_SESSION['nip_nisn'];
   		$query = mysql_query("SELECT * FROM tbl_siswa1 
   							  INNER JOIN tbl_kelas ON tbl_kelas.id_kelas=tbl_siswa1.kelas 
   							  INNER JOIN tbl_guru ON tbl_guru.nomer_pegawai = tbl_kelas.wali_kelas 
   							  INNER JOIN tbl_ortu ON tbl_ortu.no_induk = tbl_siswa1.nis_lokal
   							  WHERE substr(nis_lokal, -8)  = $user1");
      	$user  = mysql_fetch_array($query);
      	$nama = $user['nama_siswa'];
      	$nisn = $user['nis_lokal'];
      	$kelas =$user['kelas'];
      	$wali = $user['nama'];
      	$alamat = $user['alamat'];
        $foto_profil = mysql_query("SELECT foto FROM tbl_siswa1 WHERE substr(nis_lokal, -8) = '$user1' ");
        $foto = mysql_fetch_array($foto_profil);
    ?>

	<div class="container">
		<div class="about-info-grids" style="margin-top:70px;">
			 <div class="col-md-3 abt-profil">
        <?php
          if ($foto['foto'] == 'Belum Ada') {
            if ($user['jk_siswa'] == 'L') {
              $foto_tampil = '../../AdminKP/Admin/app/insert/foto/laki-laki.png';
              
            }
            elseif ($user['jk_siswa'] == 'P') {
              $foto_tampil = '../../AdminKP/Admin/app/insert/foto/perempuan.png';
            }
          }
          else{
            $foto_tampil = '../../AdminKP/Admin/app/insert/'.$foto['foto'].'';
          }
        ?>
			 	 <div class="testi-profile">
				 	<center><img src="<?php echo $foto_tampil;?>" class="img-responsive" alt=""/></center><br>
				 	<p class="text-center"><?php echo $nama;?></p>
				 	<p class="text-center"><?php echo $nisn;?></p>
				 </div>
			 </div>
			
			 <div class="col-md-9">
			 		<div class="row"></div>
			 		<div class="row">
			 			<div class="alert alert-info alert-dismissible" role="alert" style="border-radius:0px">
  							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  							<strong>Assalamu'alaikum,</strong> <?php echo $nama; ?>
						</div>
			 		</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">Nama</div>
			 	 			<div class="col-md-10"> : <?php echo $nama; ?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Kelas</div>
			 	 			<div class="col-md-8"> : <?php echo $kelas; ?> </div>
			 	 		</div>
			 	 	</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">NIS</div>
			 	 			<div class="col-md-10"> : <?php echo $nisn;?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Wali Kelas</div>
			 	 			<div class="col-md-8"> : <?php echo $wali;?></div>
			 	 		</div>
			 	 	</div><br>
			 	 	<div class="row">	
						<ol class="breadcrumb" style="background-color:#dff0d8; border-radius:0px;">
  							<li style="font-size:15px">Dashboard</li>
  							<li style="font-size:15px">Akademik</li>
  							<li class="active" style="font-size:15px">Lihat Data Pribadi Siswa</li>
						</ol>
			 	 	</div>
				 <!--<h3>Vestibulum congue neque quis ex fringilla, in pellentesque massa gravida.</h3>-->
			 </div>
			 <div class="clearfix"> </div>
		 </div>
	</div>
</section>
<section class="box-profil">
	<div class="container"><br>
		<div class="col-md-3 abt-profil">
				 <div>
			 		<ul class="nav nav-pills nav-stacked">
  						<li role="presentation" style="background-color:#006600;"><a href="profil.php" style="background-color:#006600; color:#fff"><span class="glyphicon glyphicon-home">
                            </span> Dashboard</a></li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"><span class="glyphicon glyphicon-th">
                            </span> Data Pribadi Siswa</a>
                    		<div id="collapseTwo" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a style="color: #4d4d4d; font-size:14px" href="data_pribadi_siswa.php">Lihat Data Pribadi Siswa</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTw"><span class="glyphicon glyphicon-th">
                            </span> Akademik</a>
                            <div id="collapseTw" class="panel-collapse collapse">
                            <div class="panel-body">
                              <div class="row"><a href="data_guru.php" style="color: #4d4d4d; font-size:14px">Guru</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="data_jadwal_pelajaran.php" style="color: #4d4d4d; font-size:14px">Jadwal Pelajaran</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_kepribadian.php" style="color: #4d4d4d; font-size:14px">Nilai Kepribadian</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_tahfid.php" style="color: #4d4d4d; font-size:14px">Nilai Tahfid / Doa</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_semester.php" style="color: #4d4d4d; font-size:14px">Nilai Semester</a></div>
                              <div style="color:#9A9598">-------------------------------</div>
                              <div class="row"><a href="nilai_raport.php" style="color: #4d4d4d; font-size:14px">Nilai Raport</a></div>
                            </div>
                        </div>
              </li>
              <li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collap"><span class="glyphicon glyphicon-th">
                            </span> Ganti Password</a>
                        <div id="collap" class="panel-collapse collapse">
                            <div class="panel-body">
                              <div class="row"><a href="ubah_password.php" style="color: #4d4d4d; font-size:14px">Ganti Password</a></div>
                            </div>
                        </div>
              </li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" href="<?php echo '../logout.php';?>"><span class="glyphicon glyphicon-log-out">
                            </span> Logout</a>
  						</li>
					</ul>
			 	</div>
			 </div>
		<div class="col-md-9">
			<div class="row">
			<div class="form-group">
				<div class="col-md-5" style="margin-top:5px"><h3>Data Pribadi Siswa</h3></div>
			</div>
			</div>
			<div class="row">
				<div class="col-md-12" style="border: 2px solid #9A9598">
          <!--Validasi -->
        <script type="text/javascript">
          $(document).ready(function() {

          $('#form-ganti').validate({
            rules: {
              pekerjaan_ayah: {
                
              },
              pekerjaan_ibu : {
                
              },
              penghasilan_ayah: {
                range: [0, 1000000000]
              },
              penghasilan_ibu: {
                range: [0, 1000000000]
              }
            },
            messages: {
              pekerjaan_ayah: {
                required: "Tidak Boleh Kosong",
              },
              pekerjaan_ibu: {
                required: "Tidak Boleh Kosong",
              },
              penghasilan_ayah: {
                range: "Tidak Boleh Minus",
              },
              penghasilan_ibu: {
                range: "Tidak Boleh Minus",
              }
            }
          });
        });
      </script>

					<form class="form-horizontal" name="add_siswa" id="form-ganti" method="POST" action="../app/update/update_data_siswa.php">
                    <input type="hidden" name="nis_lokal" value="<?php echo $nisn;?>">
                    <div class="col-md-12"><br>
                      <label>A. KETERANGAN PESERTA DIDIK</label>
                    </div>
                    <div class="col-md-12">
                      <div class="col-md-12">
                        <div class="form-group">
                          <div class="col-md-3"><br>
                            <p>Nama Lengkap</p>
                          </div>
                          <div class="col-md-6"><br>
                            <label>: <?php echo $user['nama_siswa'];?></label>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Tempat, Tanggal Lahir</p>
                          </div>
                          <div class="col-md-6">
                            <label>: <?php echo $user['tempat_lahir'];?>, <?php echo date("d F Y", strtotime($user['tanggal_lahir']));?></label>
                          </div>
                        </div>
                         <div class="form-group">
                          <div class="col-md-3">
                            <p>Alamat</p>
                          </div>
                          <div class="col-md-6">
                            <input type="text" name="alamat_siswa" class="form-control" value="<?php echo $user['alamat_siswa'];?>">
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Kecamatan</p>
                          </div>
                          <div class="col-md-6">
                            <input type="text" name="kecamatan_siswa" class="form-control" value="<?php echo $user['kecamatan_siswa'];?>">
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Kabupaten / Kota</p>
                          </div>
                          <div class="col-md-6">
                            <input type="text" name="kabupaten" class="form-control" value="<?php echo $user['kab_kota'];?>">
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Provinsi</p>
                          </div>
                          <div class="col-md-6">
                            <input type="text" name="provinsi" class="form-control" value="<?php echo $user['propinsi'];?>">
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Jenis Kelamin</p>
                          </div>
                          <div class="col-md-5">
                          	<?php
                          		if ($user['jk_siswa'] == 'L') {
                          			$kelamin = 'Laki-laki';
                          		}
                          		elseif ($user['jk_siswa'] == 'P') {
                          			$kelamin = 'Perempuan';
                          		}
                          	?>
                          	<label>: <?php echo $kelamin;?></label>
                          </div>
                        </div>
                         <div class="form-group">
                          <div class="col-md-3">
                            <p>Agama</p>
                          </div>
                          <div class="col-md-3">
                              <label>: <?php echo $user['agama'];?></label>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Status</p>
                          </div>
                          <div class="col-md-8">
                          	<?php
                          		if ($user['status_kel'] == 'AA') {
                          			$status = 'Anak Angkat';
                          		}
                          		elseif ($user['status_kel'] == 'AT') {
                          			$status = 'Anak Tiri';
                          		}
                          		elseif ($user['status_kel'] == 'AK') {
                          			$status = 'Anak Kandung';
                          		}
                          		else{
                          			$status = $user['status_kel'];
                          		}
                          	?>
                          	<label>: <?php echo $status;?></label>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                      <div class="col-md-12">
                        <label>B. KETERANGAN ORANG TUA KANDUNG</label>
                      </div><br>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>No. Kartu Keluarga</p>
                          </div>
                          <div class="col-md-5">
                            <input type="text" name="no_kartu_keluarga" class="form-control" value="<?php echo $user['no_kartu_keluarga'];?>">
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>Ayah</p>
                          </div>
                          <div class="col-md-6">
                            <label>: <?php echo $user['nama_ayah'];?></label>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>Ibu</p>
                          </div>
                          <div class="col-md-6">
                            <label>: <?php echo $user['nama_ibu'];?></label>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-5">
                            <label>Tempat, Tanggal Lahir</label>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>Ayah</p>
                          </div>
                          <div class="col-md-3">
                            <input type="text" name="tmp_lahir_ayah" value="<?php echo $user['tempat_lahir_ayah'];?>" class="form-control">
                          </div>
                          <div class="col-md-3">
                            <input type="date" name="tgl_lahir_ayah" value=" <?php echo $user['tgl_lahir_ayah'];?>" class="form-control">
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>Ibu</p>
                          </div>
                          <div class="col-md-3">
                            <input type="text" name="tmp_lahir_ibu" value="<?php echo $user['tempat_lahir_ibu'];?>" class="form-control">
                          </div>
                          <div class="col-md-3">
                            <input type="date" name="tgl_lahir_ibu" value=" <?php echo $user['tgl_lahir_ibu'];?>" class="form-control">
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>Alamat Lengkap</p>
                          </div>
                          <div class="col-md-9">
                            <input type="text" name="alamat_ortu" class="form-control" value="<?php echo $user['alamat_ortu'];?>">
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-4">
                            <label>Pekerjaan Orang Tua</label>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>Ayah</p>
                          </div>
                          <div class="col-md-5">
                            <input type="text" name="pekerjaan_ayah" class="form-control" value="<?php echo $user['pekerjaan_ayah'];?>" required>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>Ibu</p>
                          </div>
                          <div class="col-md-5">
                            <input type="text" name="pekerjaan_ibu" class="form-control" value="<?php echo $user['pekerjaan_ibu'];?>" required>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-4">
                            <label>Penghasilan Perbulan</label>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>Ayah</p>
                          </div>
                          <div class="col-md-5">
                            <input type="text" name="penghasilan_ayah" class="form-control" value="<?php echo $user['penghasilan_ayah'];?>" required>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>Ibu</p>
                          </div>
                          <div class="col-md-5">
                            <input type="text" name="penghasilan_ibu" class="form-control" value="<?php echo $user['penghasilan_ibu'];?>" required>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-2">
                            <label>Keterangan</label>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>Ayah</p>
                          </div>
                          <div class="col-md-5">
                            <div class="radio">
                            <?php
                              if ($user['ket_hidup_ayah'] == "MH") {
                               $option1 = "<input type=\"radio\" name=\"kethidupayah\" id=\"optionsRadios2\" value=\"MH\" checked>";
                               $option2 = "<input type=\"radio\" name=\"kethidupayah\" id=\"optionsRadios2\" value=\"MD\" >"; 
                              }
                              else if ($user['ket_hidup_ayah'] =="MD") {
                               $option1 = "<input type=\"radio\" name=\"kethidupayah\" id=\"optionsRadios2\" value=\"MH\">";
                               $option2 = "<input type=\"radio\" name=\"kethidupayah\" id=\"optionsRadios2\" value=\"MD\" checked>";
                              }
                              else{
                               $option1 = "<input type=\"radio\" name=\"kethidupayah\" id=\"optionsRadios2\" value=\"MH\" checked>";
                               $option2 = "<input type=\"radio\" name=\"kethidupayah\" id=\"optionsRadios2\" value=\"MD\" >";
                              }
                            ?>
                            <label><?php echo $option1;?>Masih Hidup </label>
                            <label><?php echo $option2;?>Meninggal Dunia</label>
                            </div>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>Ibu</p>
                          </div>
                          <div class="col-md-5">
                            <div class="radio">
                            <?php
                              if ($user['ket_hidup_ibu'] == "MH") {
                               $option1 = "<input type=\"radio\" name=\"kethidupibu\" id=\"optionsRadi\" value=\"MH\" checked>";
                               $option2 = "<input type=\"radio\" name=\"kethidupibu\" id=\"optionsRadi\" value=\"MD\" >"; 
                              }
                              else if ($user['ket_hidup_ibu'] =="MD") {
                               $option1 = "<input type=\"radio\" name=\"kethidupibu\" id=\"optionsRadi\" value=\"MH\">";
                               $option2 = "<input type=\"radio\" name=\"kethidupibu\" id=\"optionsRadi\" value=\"MD\" checked>";
                              }
                              else{
                               $option1 = "<input type=\"radio\" name=\"kethidupibu\" id=\"optionsRadi\" value=\"MH\" checked>";
                               $option2 = "<input type=\"radio\" name=\"kethidupibu\" id=\"optionsRadi\" value=\"MD\" >";
                              }
                            ?>
                            <label><?php echo $option1;?>Masih Hidup </label>
                            <label><?php echo $option2;?>Meninggal Dunia</label>
                            </div>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                            <p>No. Telepon</p>
                          </div>
                          <div class="col-md-4">
                            <input type="text" name="no_tlp_ortu" value="<?php echo $user['no_tlp_ortu'];?>" class="form-control">
                          </div>
                      </div>
                      </div>
                      <div class="form-group">
                      <div class="col-md-5">
                        <label>C. KETERANGAN WALI</label>
                      </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Nama Lengkap</p>
                          </div>
                          <div class="col-md-6">
                            <input type="text" name="nama_wali" value="<?php echo $user['nama_wali'];?>" class="form-control">
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Tempat, Tanggal Lahir</p>
                          </div>
                          <div class="col-md-3">
                            <input type="text" name="tmp_lahir_wali" value="<?php echo $user['tempat_lahir_wali'];?>" class="form-control">
                          </div>
                          <div class="col-md-3">
                            <input type="date" name="tgl_lahir_wali" value="<?php echo $user['tgl_lahir_wali'];?>" class="form-control">
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Alamat Lengkap</p>
                          </div>
                          <div class="col-md-9">
                            <input type="text" name="alamat_wali" value="<?php echo $user['alamat_wali'];?>" class="form-control">
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Jenis Kelamin</p>
                          </div>
                          <div class="col-md-5">
                          <div class="radio">
                            <?php
                              if ($user['jenis_kel_wali'] == "L") {
                               $option1 = "<input type=\"radio\" name=\"jk_wali\" id=\"optionsRadios5\" value=\"L\" checked>Laki-laki";
                               $option2 = "<input type=\"radio\" name=\"jk_wali\" id=\"optionsRadios5\" value=\"P\" >Perempuan"; 
                              }
                              else if ($user['jenis_kel_wali'] =="P") {
                              $option1 = "<input type=\"radio\" name=\"jk_wali\" id=\"optionsRadios5\" value=\"L\">Laki-laki";
                               $option2 = "<input type=\"radio\" name=\"jk_wali\" id=\"optionsRadios5\" value=\"P\" checked>Perempuan";
                              }
                              else{
                              $option1 = "<input type=\"radio\" name=\"jk_wali\" id=\"optionsRadios5\" value=\"L\" checked>Laki-laki";
                               $option2 = "<input type=\"radio\" name=\"jk_wali\" id=\"optionsRadios5\" value=\"P\" >Perempuan";
                              }
                            ?>
                            <label><?php echo $option1;?></label>
                            <label><?php echo $option2;?></label>
                          </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Agama</p>
                          </div>
                          <div class="col-md-3">
                            <select name="agama_wali" class="form-control">
                              <option value="<?php echo $user['agama_wali'];?>"><?php echo $user['agama_wali'];?></option>
                              <option value="Islam">Islam</option>
                              <option value="Kristen">Kristen</option>
                              <option value="Katolik">Katolik</option>
                              <option value="Hindu">Hindu</option>
                              <option value="Budha">Budha</option>
                            </select>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Pekerjaan</p>
                          </div>
                          <div class="col-md-3">
                            <input type="text" name="pekerjaan_wali" value="<?php echo $user['pekerjaan_wali'];?>" class="form-control">
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>Penghasilan</p>
                          </div>
                          <div class="col-md-3">
                            <input type="number" name="gaji_wali" value="<?php echo $user['penghasilan_wali'];?>"class="form-control">
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3">
                            <p>No. Telepon</p>
                          </div>
                          <div class="col-md-3">
                            <input type="text" name="no_tlp_wali" class="form-control" value="<?php echo $user['no_tlp_wali'];?>">
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-3"></div>
                          <div class="col-md-3">
                            <button class="btn" style="background-color:#006600; border-radius:0px; color:#fff"><i class="glyphicon glyphicon-th"></i> Simpan</button>
                          </div>
                        </div>
                      </div>
                      </div>
                      </div>
                  </div>  
                  </form>

				</div>
			</div>
	</div>
</section>
<section>

</section>
<div class="about">
	 <div class="container">
		 <div class="testimonals">
				
		   </div>
		   <div class="team">
			  
			 <div class="clearfix"> </div> 
		  </div>
	 </div>
</div>
<!-- /About -->
<!--copy-rights-->
<div class="copyright">
		<!-- container -->
		<div class="container">
			<div class="copyright-left">
			<p>MI Al-Huda © 2016 All rights reserved</p>
			</div>
			<div class="clearfix"> </div>
			
		</div>
		<!-- //container -->
	</div>
<!--/copy-rights-->
	</body>
</html>
