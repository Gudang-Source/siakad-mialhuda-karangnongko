<?php
session_start();
include('../check_login.php');
include('../settings/config.php');
?>
<!DOCTYPE html>
<html>
<head>
<title>Selamat Datang</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Education Tutorial Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--bootstrap-->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!--coustom css-->
<link href="../css/style.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="../css/menu-profil.css">
<!--script-->
<script src="../js/jquery-1.11.0.min.js"></script>
<!-- js -->
<script src="../js/bootstrap.js"></script>
<!-- /js -->
<script type="text/javascript" src="../js/move-top.js"></script>
<script type="text/javascript" src="../js/easing.js"></script>
</head>
	<body>
<!--header-->
		<div class="header" id="home">
			<nav class="navbar navbar-default">
				<div class="container">
					<div class="col-md-1" style="margin-right:30px;">
						<img style="margin-top:15px; height:95px;" src="../images/logo.png">
					</div>
					<div class="col-md-10">
						<label style="margin-top:25px; color:#fff; font-size:25px">Sistem Informasi Akademik</label><br>
						<label style="color:#fff; font-size:25px">MI AL-HUDA</label>
					</div>
				</div>
			</nav>
<!--/script-->
		   <div class="clearfix"> </div>
		</div>
<!-- Top Navigation -->
<!--header-->
<!-- About -->
<section class="box-profil">

	 <?php
	 	$user1 = $_SESSION['nip_nisn'];
   		$query = mysql_query("SELECT * FROM tbl_siswa1 INNER JOIN tbl_kelas ON tbl_kelas.id_kelas=tbl_siswa1.kelas INNER JOIN tbl_guru ON tbl_guru.nomer_pegawai = tbl_kelas.wali_kelas WHERE substr(tbl_siswa1.nis_lokal, -8)  = $user1");
      	$user  = mysql_fetch_array($query);
      	$nama = $user['nama_siswa'];
      	$nisn = $user['nis_lokal'];
      	$kelas =$user['kelas'];
      	$wali = $user['nama'];
      	$foto_profil = mysql_query("SELECT foto FROM tbl_siswa1 WHERE substr(nis_lokal, -8) = '$user1' ");
      	$foto = mysql_fetch_array($foto_profil);
    ?>

	<div class="container">
		<div class="about-info-grids" style="margin-top:70px;">
			 <div class="col-md-3 abt-profil">
			 	<?php
			 		if ($foto['foto'] == 'Belum Ada') {
			 			if ($user['jk_siswa'] == 'L') {
			 				$foto_tampil = '../../AdminKP/Admin/app/insert/foto/laki-laki.png';
			 				
			 			}
			 			elseif ($user['jk_siswa'] == 'P') {
			 				$foto_tampil = '../../AdminKP/Admin/app/insert/foto/perempuan.png';
			 			}
			 		}
			 		else{
			 			$foto_tampil = '../../AdminKP/Admin/app/insert/'.$foto['foto'].'';
			 		}
			 	?>
			 	 <div class="testi-profile">
				 	<center><img src="<?php echo $foto_tampil;?>" class="img-responsive" alt=""/></center><br>
				 	<p class="text-center"><?php echo $nama;?></p>
				 	<p class="text-center"><?php echo $nisn;?></p>
				 </div>
			 </div>
			
			 <div class="col-md-9">
			 		<div class="row"></div>
			 		<div class="row">
			 			<div class="alert alert-info alert-dismissible" role="alert" style="border-radius:0px">
  							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  							<strong>Assalamu'alaikum,</strong> <?php echo $nama; ?>
						</div>
			 		</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">Nama</div>
			 	 			<div class="col-md-10"> : <?php echo $nama; ?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Kelas</div>
			 	 			<div class="col-md-8"> : <?php echo $kelas; ?> </div>
			 	 		</div>
			 	 	</div>
			 	 	<div class="row">
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598; border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-2">NIS</div>
			 	 			<div class="col-md-10"> : <?php echo $nisn;?></div>
			 	 		</div>
			 	 		<div class="col-md-6" style="border: 2px solid #9A9598;  border-top:none; padding: 0.5em 0em 0.5em 0em">
			 	 			<div class="col-md-4">Wali Kelas</div>
			 	 			<div class="col-md-8"> : <?php echo $wali;?></div>
			 	 		</div>
			 	 	</div><br>
			 	 	<div class="row">	
						<ol class="breadcrumb" style="border-radius:0px;">
  							<li><a href="#" style="color: #4d4d4d; font-size:15px">Dashboard /</a></li>
  							<!--<li class="active">Akademik</li>-->
						</ol>
			 	 	</div>
				 <!--<h3>Vestibulum congue neque quis ex fringilla, in pellentesque massa gravida.</h3>-->
			 </div>
			 <div class="clearfix"> </div>
		 </div>
	</div>
</section>
<section class="box-profil">
	<div class="container"><br>
		<div class="col-md-3 abt-profil">
				 <div>
			 		<ul class="nav nav-pills nav-stacked">
  						<li role="presentation" style="background-color:#006600;"><a href="profil.php" style="background-color:#006600; color:#fff"><span class="glyphicon glyphicon-home">
                            </span> Dashboard</a></li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"><span class="glyphicon glyphicon-th">
                            </span> Data Pribadi Siswa</a>
                    		<div id="collapseTwo" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a style="color: #4d4d4d; font-size:14px" href="data_pribadi_siswa.php">Lihat Data Pribadi Siswa</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collapseTw"><span class="glyphicon glyphicon-th">
                            </span> Akademik</a>
                            <div id="collapseTw" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a href="data_guru.php" style="color: #4d4d4d; font-size:14px">Guru</a></div>
                        			<div style="color:#9A9598">-------------------------------</div>
                        			<div class="row"><a href="data_jadwal_pelajaran.php" style="color: #4d4d4d; font-size:14px">Jadwal Pelajaran</a></div>
                        			<div style="color:#9A9598">-------------------------------</div>
                        			<div class="row"><a href="nilai_kepribadian.php" style="color: #4d4d4d; font-size:14px">Nilai Kepribadian</a></div>
                        			<div style="color:#9A9598">-------------------------------</div>
                        			<div class="row"><a href="nilai_tahfid.php" style="color: #4d4d4d; font-size:14px">Nilai Tahfid / Doa</a></div>
                        			<div style="color:#9A9598">-------------------------------</div>
                        			<div class="row"><a href="nilai_semester.php" style="color: #4d4d4d; font-size:14px">Nilai Semester</a></div>
                        			<div style="color:#9A9598">-------------------------------</div>
                        			<div class="row"><a href="nilai_raport.php" style="color: #4d4d4d; font-size:14px">Nilai Raport</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li  role="presentation"><a style="background-color:white; color: #4d4d4d" data-toggle="collapse" data-parent="#accordion" href="#collap"><span class="glyphicon glyphicon-th">
                            </span> Ganti Password</a>
                            <div id="collap" class="panel-collapse collapse">
                        		<div class="panel-body">
                        			<div class="row"><a href="ubah_password.php" style="color: #4d4d4d; font-size:14px">Ganti Password</a></div>
                        		</div>
                    		</div>
  						</li>
  						<li role="presentation"><a style="background-color:white; color: #4d4d4d" href="<?php echo '../logout.php';?>"><span class="glyphicon glyphicon-log-out">
                            </span> Logout</a>
  						</li>
					</ul>
			 	</div>
			 </div>
	</div>
</section>
<section>

</section>
<div class="about">
	 <div class="container">
		 <div class="testimonals">
				
		   </div>
		   <div class="team">
			  
			 <div class="clearfix"> </div> 
		  </div>
	 </div>
</div>
<!-- /About -->
<!--copy-rights-->
<div class="copyright">
		<!-- container -->
		<div class="container">
			<div class="copyright-left">
			<p>MI Al-Huda © 2016 All rights reserved</p>
			</div>
			<div class="clearfix"> </div>
			
		</div>
		<!-- //container -->
	</div>
<!--/copy-rights-->
	</body>
</html>
